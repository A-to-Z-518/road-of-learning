<template>
  <div class = 'app'>
    <link href="https://how2j.cn/study/css/bootstrap/3.3.6/bootstrap.min.css" rel="stylesheet">
    <div :class = '{iframeleft:isiframeleft, interpretleft:isinterpretleft}' >
      <iframe :src = 'interprethref' width='100%' height = '100%'></iframe>
      <slot></slot>
    </div>
    <button @click = 'interpretbutton' class="btn btn-success interpret" title = '点击打开/关闭'>翻译</button>
  </div>
</template>

<script>
export default {
  el:'.app',
  data(){
    return{
      isinterpretleft:false,
      isiframeleft:true,
      interprethref:'https://fanyi.qq.com/',
    }
  },
  methods:{
    interpretbutton(){
      this.isinterpretleft = !this.isinterpretleft
      this.isiframeleft = !this.isiframeleft
    }
  }
}
</script>

<style>

</style>