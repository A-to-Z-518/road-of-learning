<template>
  <div class = 'app'>
    <a :href="moviehref" target = 'target' title = '电影免费看'>
      <img :src="movie" class = 'movie img-circle'></a>
    <a :href="musichref" target = 'target' title = '想听的全都有'>
      <img :src="music" class = 'music img-circle'>
    </a>
  </div>
</template>

<script>
export default {
  el:'.app',
  data(){
    return{
      moviehref:'http://www.gddyu.com/',
      movie:'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2779111061,4090643689&fm=26&gp=0.jpg',
      musichref:'https://m.music.migu.cn/v3',
      music:'https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1998485984,1669791014&fm=26&gp=0.jpg'
    }
  },
  created(){
    document.title = ('热爱')
  }
}
</script>

<style>

</style>