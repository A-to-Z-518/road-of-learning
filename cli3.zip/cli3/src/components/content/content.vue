<template>
  <div class = 'app'>
    <a :href="vuehref" target = 'target' title = 'Vue教程'>
      <img :src="vue" class = 'vue' alt=""></a>
    <a :href="javahref" target = 'target' title = 'Java教程'>
      <img :src="java" class = 'java' alt=""></a>
    <a :href = 'gethubhref' target = 'target' title = 'GetHub'>
      <img :src = 'gethub' class = 'gethub'></a>
    <a :href = 'universityhref' target = 'target' title = '教务系统'>
      <img :src="university" class = 'university'></a>
    <a :href="webpackhref" target = 'target' title = 'Webpack官网'>
      <img :src="webpack" class = 'webpack img-circle'></a>
    <a :href="vuejshref" target = 'target' title = 'Vue.js官网'>
      <img :src="vuejs" class = 'vuejs' alt=""></a>
    <a :href="wikihref" target = 'target' title = '维基百科'>
      <img :src="wiki" class = 'wiki'>
    </a>
  </div>
</template>

<script>
export default {
  el:'.app',
  data(){
    return{
      vue:'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1535572249,3122154764&fm=26&gp=0.jpg',
      vuehref:'https://www.bilibili.com/video/BV15741177Eh',
      java:'https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1016129677,2942713061&fm=26&gp=0.jpg',
      javahref:'https://how2j.cn/stage/12.html',
      gethub:'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=4141795614,1697102355&fm=26&gp=0.jpg',
      gethubhref:'https://github.com/',
      university:'https://dss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3590093780,1591211457&fm=26&gp=0.jpg',
      universityhref:'http://119.53.90.67/teachweb/(A(h8u6gt650wEkAAAAYjk3ZjQ3NDktOTRiOS00NTY5LThhYjYtOGMwMTQ5YzhhZmFm6bg0bjPu5p5aUbNype6V7iGG0z41))/ischool.aspx',
      webpackhref:'https://www.webpackjs.com/',
      webpack:'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=824382519,2067646973&fm=11&gp=0.jpg',
      vuejs:'https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2809052415,518307309&fm=26&gp=0.jpg',
      vuejshref:'https://cn.vuejs.org/',
      wiki:'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3540860630,2440244974&fm=26&gp=0.jpg',
      wikihref:'https://bk.tw.lvfukeji.com/wiki/Wikipedia:%E9%A6%96%E9%A1%B5'
    }
  },
  created(){
    document.title = ('努力')
  }
}
</script>

<style>

</style>