<template>
  <div class = 'app'>
    <a :href = 'alibabahref' target = 'target' title = '淘，我喜欢'>
      <img :src = 'alibaba' class = 'alibaba img-circle'></a>
    <a :href="xiaomihref" target = 'target' title = '为发烧而生'>
      <img :src="xiaomi" class = 'xiaomi'></a>
    <a :href="sonyhref" target = 'target' title = '用创意和科技的力量感动世界'>
      <img :src="sony" class = 'sony'></a>
    <a :href="razerhref" target = 'target' title = '始于玩家，赋予玩家'>
      <img :src="razer" class = 'razer img-circle'></a>
    <a :href="cherryhref" target = 'target' title = 'cherry,德系之美'>
      <img :src="cherry" class = 'cherry'>
    </a>
  </div>
</template>

<script>
export default {
  el:'.app',
  data(){
    return{
      alibabahref:'https://www.taobao.com/',
      alibaba:'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3040995321,1881779601&fm=26&gp=0.jpg',
      xiaomihref:'https://www.mi.com/',
      xiaomi:'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1720967367,570303970&fm=26&gp=0.jpg',
      sonyhref:'https://www.sony.com.cn/',
      sony:'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=859926579,3003632364&fm=26&gp=0.jpg',
      razerhref:'http://cn.razerzone.com/',
      razer:'https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=4175260368,2446663790&fm=26&gp=0.jpg',
      cherryhref:'https://www.cherry.cn/',
      cherry:'https://www.logoids.com/upload/image/201802/15174511139462324.jpg'
    }
  },
  created(){
    document.title = ('追求')
  }
}
</script>

<style>

</style>