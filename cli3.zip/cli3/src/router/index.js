import { createRouter, createWebHistory } from 'vue-router'
import Content from '../components/content/content.vue'
import Life from '../components/content/life.vue'
import Relax from '../components/content/relax.vue'

const routes = [
  {
    path:'',
    redirect:'/content'
  },
  {
    path:'/content',
    component:Content
  },
  {
    path:'/life',
    component:Life
  },
  {
    path:'/relax',
    component:Relax
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
