<template>
  <div class = 'app flex'>
    <div class = 'fixed'>
      <button @click = 'content' class = 'button btn btn-success'>study</button>
      <button @click = 'life' class = 'button btn btn-success'>life</button>
      <button @click = 'relax' class = 'button btn btn-success'>relax</button>
    </div>
    <router-view></router-view>
    <isbutton></isbutton>
  </div>
  
</template>

<script>
import isbutton from'./components/public/button.vue'
export default {
  el:'.app',
  components:{
    isbutton,
  },
  methods:{
    content(){
      this.$router.push('/content');
    },
    life(){
      this.$router.push('/life');
    },
    relax(){
      this.$router.push('/relax')
    }
  },
  
}
</script>

<style>
  @import "./assets/css/study.css";
  @import "./assets/css/relax.css";
  @import "./assets/css/life.css";
  
  .button{
    flex:1;
    margin:0 100px 0 100px;
  }
  .fixed{
    display:flex;
    position:fixed;
    left:0;
    right:0;
    bottom:40px;
  }
</style>
