import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import 'element-ui/lib/theme-chalk/index.css';

// cookie
import VueCookies from 'vue-cookies'
Vue.use(VueCookies)

Vue.config.productionTip = false
// 若是没有开启Devtools工具，在开发环境中开启，在生产环境中关闭
if (process.env.NODE_ENV == 'development') {
  Vue.config.devtools = true;
} else {
  Vue.config.devtools = false;
}

import mavonEditor from 'mavon-editor'
import 'mavon-editor/dist/css/index.css'
// use
Vue.use(mavonEditor)

import "@/plugins/element"
// import "@/icons/index.js";

// 导入自定义的组件
import "@/icons"

import axios from "axios"
// axios.defaults.baseURL = "http://192.168.1.102:50000"
axios.defaults.baseURL = "http://itvip666.com:10080"
axios.defaults.timeout = 5000
// 将axios挂载在Vue原型链上
Vue.prototype.$axios=axios

// 时间格式化
import * as custom from "@/util/time.js"
// 全局注册
Object.keys(custom).forEach(key => { Vue.filter(key, custom[key])})



import VueLoading from 'vue-loading-template'
Vue.use(VueLoading, /** options **/)

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

