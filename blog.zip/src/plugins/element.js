import Vue from 'vue'

import {
  Input,
  Button,Dropdown,DropdownMenu,DropdownItem,
  Avatar,
  Message,
  MessageBox,
  Pagination,Tag,
  Badge ,
  Form,FormItem,
  Dialog,Divider,Image,
  Container,Header,Main,Aside,
  Table,TableColumn,Upload,
  Switch,
  RadioGroup,Radio,Tabs,TabPane,Tooltip,
  Select,Option,
  CheckboxGroup,Checkbox
} from "element-ui"

Vue.use(CheckboxGroup)
Vue.use(Checkbox)

Vue.use(RadioGroup)
Vue.use(Radio)

Vue.use(Tooltip)

Vue.use(Tabs)
Vue.use(TabPane)

Vue.use(Upload)
Vue.use(Switch)

Vue.use(Container)
Vue.use(Header)
Vue.use(Main)
Vue.use(Aside)

Vue.use(Table)
Vue.use(TableColumn)

// 标记
Vue.use(Badge)
Vue.use(Tag)
Vue.use(Pagination)

Vue.use(Form) 
Vue.use(FormItem)

Vue.use(Image)

Vue.use(Divider)

Vue.use(Select)
Dialog.props.lockScroll.default=false
Vue.use(Dialog)
Vue.use(Option)

Vue.use(Avatar)

Vue.use(Dropdown)
Vue.use(DropdownMenu)
Vue.use(DropdownItem)

Vue.use(Input)
Vue.use(Button)

// 全局挂载Message组件
Vue.prototype.$message = Message
Vue.prototype.$confirm = MessageBox.confirm

