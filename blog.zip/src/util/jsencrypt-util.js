import { JSEncrypt } from 'jsencrypt'

/**
 * 根据RSA公钥加密数据，向后端获取公钥
 * @param {*} publicKey 公钥
 * @param {*} data 要加密的数据
 */
export function encryptedData(publicKey, data) {
  // 新建JSEncrypt对象
  let encryptor = new JSEncrypt();
  // 设置公钥
  encryptor.setPublicKey(publicKey);
  // 加密数据
  return encryptor.encrypt(data);
}