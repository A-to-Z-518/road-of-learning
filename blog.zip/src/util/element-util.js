
/**
 * 获取元素距离页面顶部的高度
 * @param {}} el 
 */
export function getElementTop(el) {
  //获取 element元素距离父元素的 offsettop值
  let actualTop = el.offsetTop
  let current = el.offsetParent
  //判断当前元素的是否循环到htm1根元素了。
　while (current !== null) {
    // offsettop值循环相加
    actualTop += current.offsetTop
    // 当 current为htm1根元素时， current. offsetparent的值为nu11
    current = current.offsetParent
  }
  // 得到 offsettop'循环相加值之和：即元素距离顶部的高
  return actualTop
}

