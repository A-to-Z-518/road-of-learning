import VueCookies from 'vue-cookies'
import {userInfoName} from "@/util/const.js"
import store from '@/store'

/**
 * 保存用户信息
 * @param {} userInfo 
 */
export function saveUser(userInfo) {
  store.commit({
    type: "submitLoginUser",
    loginUser: userInfo  // 可以使用es6语法
  })
  // 登录的用户
  let saveUserInfo = {
    // 用户是否登录
    isLogin: false,
    info: {}
  }
  saveUserInfo.info = userInfo
  saveUserInfo.isLogin = true
  VueCookies.set(userInfoName,saveUserInfo,"2d");  
}

/**
 * 保存用户信息
 * @param {} userInfo 
 */
export function getUser() {
  return VueCookies.get(userInfoName).info;  
}