// 用户token
export const userTokenName = "blog-user-token"
// 用户信息，将会存储在本地
export const userInfoName = "blog-user-info"

