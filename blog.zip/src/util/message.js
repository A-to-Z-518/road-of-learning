/**
 * 
 * @param {*} This 传入当前组件对象 
 */

export function success(This,msg) {
  This.$message({
    message: msg,
    center: true,
    offset: 70,
    customClass: 'message',
    type: 'success'
  })
}

export function error(This,msg) {
  This.$message({
    message: msg,
    center: true,
    offset: 70,
    customClass: 'message',
    type: 'error'
  })
}

export function warning(This,msg) {
  This.$message({
    message: msg,
    center: true,
    offset: 70,
    customClass: 'message',
    type: 'warning'
  })
}

/**
 * 信息
 * @param {*} This 
 * @param {*} msg 
 */
export function info(This,msg) {
  This.$message({
    message: msg,
    center: true,
    offset: 70,
    customClass: 'message',
    type: 'info'
  })
}

/**
 * 确定框
 */
export function confirm(This,message,title,config) {
  console.log("=========");
  if (config == undefined) {
    config = {}
  }
  config.lockScroll = false
  return This.$confirm(message,title,config)
}