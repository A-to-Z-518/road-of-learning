import request from "./request.js"

const headers= {
  "Content-Type": "application/json;charset=UTF-8" 
}

const baseUrl = "/blog-user";

 /**
  * 获取图片校验码
  * @param {s} data 
  */
 export function getValidCode() {
    console.log("请求验证码..");
    return request({
      url: baseUrl + "/user/valid/code",
      method: "get"
    })
 }
