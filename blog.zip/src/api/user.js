import request from "./request.js"
import router from '@/router'
import VueCookies from 'vue-cookies'
import {userTokenName} from "@/util/const.js"


import {saveUser,findUser} from "@/util/user"

const headers= {
  "Content-Type": "application/json;charset=UTF-8"
}



const baseUrl = "/blog-user";

 /**
  * 用户注册
  * @param {s} data 
  */
 export function register(obj) {
    console.log("用户注册..");
    return request({
      url: baseUrl + "/user/register",
      method: "post",
      headers,
      data: obj
    })
 }

  /**
  * 用户登录
  * @param {s} data 
  */
 export function login(obj) {

  console.log("登录..");
  let result = request({
    url: baseUrl + "/user/login",
    method: "post",
    headers,
    data: obj
  })
  
  result.then(res => {
    console.log("====================================login");
    if (res.code == 200) {
      // 将用户信息提交到vuex中
      saveUser(res.data.user)
      
    }
  })
  
  return result
}

/**
 * 获取用户的基本信息
  */
 export function getUserInfo(token) {
  console.log("获取用户的基本信息..");
  let result =  request({
    url: baseUrl + "/find/user",
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}


/**
 * 获取公钥
  */
 export function getPublicKey() {
  console.log("获取公钥..");
  let result =  request({
    url: baseUrl + "/user/pkey",
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
    }
  })
  return result
}


/**
 * 获取推荐的作者
 */
export function recommendUser() {
  console.log("获取推荐作者 api");
  let result =  request({
    url: baseUrl + "/recommend/user",
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
    }
  })
  return result
}

/**
 * 获取用户的信息
 */
export function updateUserProfile(blogUser) {
  let token = VueCookies.get(userTokenName)  
  console.log("更新用户信息 api");
  let result =  request({
    url: baseUrl + "/update/user/profile",
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    },
    data: blogUser
  })
  return result
}


/**
 * 获取作者的用户信息
 */
export function getAuthorUserInfo(userId) {
  let result =  request({
    url: baseUrl + "/author/info/" + userId,
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
    }
  })
  return result
}