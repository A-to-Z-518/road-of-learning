import request from "./request.js"
import VueCookies from 'vue-cookies'
import {userTokenName} from "@/util/const.js"
import router from '@/router'
/**
 * 标签接口
 */
const headers= {
  "Content-Type": "application/json;charset=UTF-8"
}



const baseUrl = "/blog-article";

 /**
  * 保存文章
  * @param {s} sort 
  */
 export function saveArticle(article) {
  let token = VueCookies.get(userTokenName)  
  console.log("保存文章..");
  let result = request({
    url: baseUrl + "/article/save",
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    },
    data: article
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}

  /**
  * 更新标签
  * @param {s} sort 
  */
 export function editUpdate(sort) {
  let token = VueCookies.get(userTokenName)  
  console.log("更新分类..");
  let result = request({
    url: baseUrl + "/sort/update",
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    },
    data: sort
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}

/**
 * 查询文章
  */
 export function findUserArticleByPage(pageCurrent,pageSize) {
  let token = VueCookies.get(userTokenName)  
  console.log(token);
  console.log("获取用户的全部文章.");
  let result = request({
    url: baseUrl + "/article/page?pageNum=" + pageCurrent + "&pageSize=" + pageSize ,
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}

/**
 * 查询全部文章,查找指定用户的文章
  */
 export function findAllArticleByPage(pageCurrent) {
  let token = VueCookies.get(userTokenName)  
  console.log(token);
  console.log("分页获取文章..");
  let result = request({
    url: baseUrl + "/article/page?pageNum=" + pageCurrent,
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}

/**
 * 查询全部文章
  */
 export function findHomeArticleByPage(pageCurrent) {
  let token = VueCookies.get(userTokenName)  
  console.log(token);
  console.log("分页获取文章..");
  return request({
    url: baseUrl + "/home/article/page?pageNum=" + pageCurrent,
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
}

/**
 * 通过id查询文章，这个用于页面的详情页面，
 * @param userId 当前用户id，登录为登录用户id，没有登录为空字符串
  */
 export function findArticleById(userId,id) {
  let token = VueCookies.get(userTokenName)  
  console.log("查询文章..");
  let result = request({
    url: baseUrl + "/article/" + id + "?userId=" + userId ,
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  console.log("=========================");
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}


/**
 * 通过id删除进行逻辑删除
  */
 export function logicDeleteArticleById(id) {
  let token = VueCookies.get(userTokenName)  
  console.log("逻辑删除文章..");
  let result = request({
    url: baseUrl + "/article/logic/delete/" + id,
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}

/**
 * 通过id删除进行彻底删除
  */
 export function deleteArticleById(id) {
  let token = VueCookies.get(userTokenName)  
  let result = request({
    url: baseUrl + "/article/delete/" + id,
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}



/**
 * 通过id删除进行逻辑删除
  */
 export function getLogicDeleteArticle(pageCurrent) {
  let token = VueCookies.get(userTokenName)  
  console.log(token);
  console.log("获取逻辑删除的文章..");
  let result = request({
    url: baseUrl + "/article/logic/delete?pageNum=" + pageCurrent,
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}



/**
 * 通过id删除进行逻辑删除
  */
 export function updateArticle(blogArticle) {
  let token = VueCookies.get(userTokenName)  
  console.log(token);
  console.log("获取逻辑删除的文章..");
  let result =  request({
    url: baseUrl + "/article/update",
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    },
    data: blogArticle
  })

  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}

/**
 * 收藏文章
  */
 export function collectArticle(articleId,token) {
  console.log("获取用户的基本信息..");
  let result = request({
    url: baseUrl + "/user/collect/article/" + articleId,
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })

  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}



/**
 * 用户点赞
 */
export function like(likedUserId,token, likedArticleId,likeStatus) {
  return request({
    url: baseUrl + "/user/like?likedArticleId=" + likedArticleId + "&likeStatus=" + likeStatus + "&likedUserId=" + likedUserId,
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
}


/**
 * 用户点赞
 */
export function likeStatus(token, likedArticleId) {
  return request({
    url: baseUrl + "/user/article/like/status?likedArticleId=" + likedArticleId ,
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
}



/**
 * 获取推荐的文章
 */
export function recommendArticle() {
  console.log("获取推荐文章 api");
  let result =  request({
    url: baseUrl + "/recommend/article",
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
    }
  })
  return result
}
