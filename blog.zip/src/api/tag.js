import request from "./request.js"
import VueCookies from 'vue-cookies'
import {userTokenName} from "@/util/const.js"
import router from '@/router'
/**
 * 标签接口
 */
const headers= {
  "Content-Type": "application/json;charset=UTF-8"
}



const baseUrl = "/blog-article";

 /**
  * 保存标签
  * @param {s} tag 
  */
 export function saveTag(tag) {
  let token = VueCookies.get(userTokenName)  
  console.log("保存标签..");
  let result = request({
    url: baseUrl + "/tag/save",
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    },
    data: tag
  })

  result.then(res => {
    console.log(res);
    if (res.code == 1004) router.push("/login")
  })
  return result
}

  /**
  * 更新标签
  * @param {s} tag 
  */
 export function editUpdate(tag) {
  let token = VueCookies.get(userTokenName)  
  console.log("更新标签..");
  let result = request({
    url: baseUrl + "/tag/update",
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    },
    data: tag
  })
  result.then(res => {
    console.log(res);
    if (res.code == 1004) router.push("/login")
  })
  return result
}

/**
 * 获取全部的标签
  */
 export function findAllTag() {
  let token = VueCookies.get(userTokenName)  
  console.log(token);
  console.log("获取全部的标签..");
  let result = request({
    url: baseUrl + "/tag/find/all/sg",
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  result.then(res => {
    console.log(res);
    if (res.code == 1004) router.push("/login")
  })
  return result
}


/**
 * 通过id删除标签
  */
 export function deleteById(id) {
  let token = VueCookies.get(userTokenName)  
  console.log("删除标签..");
  return request({
    url: baseUrl + "/tag/detele?id=" + id,
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
}


