import request from "./request.js"

/**
 * 搜索接口
 */


const baseUrl = "/blog-search";

 /**
  * 全局搜索文章
  * @param {s} sort 
  */
 export function searchAllArticle(SearchParam) {
  console.log("搜索文章..");
  return request({
    url: baseUrl + "/search/all/article",
    method: "get",
    params: SearchParam
  })
}


/**
 * 通过标签过滤
 * @param tagName 标签名
 * @param pageNum 第几页
 */
export function searchByTag(pageNum,tagName) {
  console.log("搜索文章..");
  return request({
    url: baseUrl + "/search/article/tag",
    method: "get",
    params: {
      pageNum,
      tagName
    }
  })
}

/**
 * 获取用户主页中的文章
 * 
 */
export function getAuthorArticle(userId,pageNum) {
  return request({
    url: baseUrl + "/search/user/article?userId=" + userId + "&pageNum=" + pageNum,
    method: "get"
  })
}

/**
 * 获取作者的最新推荐
 */
export function authorNewestArticle(userId) {
  return request({
    url: baseUrl + "/search/author/newest/article?userId=" + userId,
    method: "get"
  })
}