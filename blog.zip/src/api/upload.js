import request from "./request.js"
import VueCookies from 'vue-cookies'
import {userTokenName} from "@/util/const.js"
import router from '@/router'
const baseUrl = "/blog-file";

export function uploadOneImage(file) {
  console.log("上传图片");
  let token = VueCookies.get(userTokenName)  
  let result = request({
      url: baseUrl + "/image/upload",
      method: "post",
      headers: {
        "Content-Type": "application/json;charset=UTF-8",
        "blog-user-token": token
      },
      data: file
  }) 
  result.then(res => {
    console.log(res);
    if (res.code == 1004) router.push("/login")
  })
  return result
}
