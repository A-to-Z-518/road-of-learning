import request from "./request.js"
import VueCookies from 'vue-cookies'
import {userTokenName} from "@/util/const.js"
import router from '@/router'

const baseUrl = "/blog-user";

 /**
  * 保存收藏夹
  * @param {s} sort 
  */
 export function saveCollect(collect) {
  let token = VueCookies.get(userTokenName)  
  console.log("创建收藏夹..");
  let result = request({
    url: baseUrl + "/save/collect",
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    },
    data: collect
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}

 /**
  * 获取用户收藏夹集合
  * @param {s} sort 
  */
 export function getUserCollectMgtList() {
  let token = VueCookies.get(userTokenName)  
  console.log("获取用户收藏夹..");
  let result = request({
    url: baseUrl + "/find/collect",
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}

 /**
  * 获取用户收藏夹集合
  * @param {s} sort 
  */
 export function findUserCollectMgtList() {
  let token = VueCookies.get(userTokenName)  
  console.log("获取用户收藏夹..");
  let result = request({
    url: baseUrl + "/find/collect",
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  return result
}



/**
 * 删除收藏夹
 * @param collect 收藏夹对象
 */
export function deleteUserCollectMgt(collect) {
  let token = VueCookies.get(userTokenName)  
  console.log("删除用户收藏夹..");
  let result = request({
    url: baseUrl + "/delete/user/collect/mgt",
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    },
    data: collect
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}


/**
 * 删除收藏
 * @param collect 收藏夹对象
 */
export function deleteUserCollect(id) {
  let token = VueCookies.get(userTokenName)  
  console.log("删除用户收藏..");
  let result = request({
    url: baseUrl + "/delete/user/collect/" + id,
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}


/**
 * 获取收藏夹下的数据
 * @param id 收藏夹id
 * @param collectType 收藏的类型 文章还是问答
 */
export function getCollectData(id,collectType,pageNum,pageSize) {
  let token = VueCookies.get(userTokenName)  
  console.log("删除用户收藏夹..");
  let result = request({
    url: baseUrl + "/find/collect/content?id=" + id + "&collectType=" + collectType + "&pageNum=" + pageNum + "&pageSize=" + pageSize,
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  result.then(res => {
    if (res.code == 1004) router.push("/login")
  })
  return result
}

/**
 * 用户收藏文章
 * @param blogUserCollectRel 收藏的对象
 */
export function collectArticle(blogUserCollect) {
  let token = VueCookies.get(userTokenName)  
  console.log("用户收藏文章..");
  blogUserCollect.collectType = 'article'
  let result = request({
    url: baseUrl + "/user/collect",
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    },
    data: blogUserCollect
  })
  return result
}

/**
 * 用户收藏问答
 * @param blogUserCollectRel 收藏的对象
 */
export function collectQa(blogUserCollectRel) {
  let token = VueCookies.get(userTokenName)  
  console.log("用户收藏文章..");
  blogUserCollectRel.collectType = 'qa'
  let result = request({
    url: baseUrl + "/user/collect",
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    },
    data: blogUserCollectRel
  })
  return result
}


/**
 * 查询收藏
 * @param blogUserCollect 
 */
export function getUserArticleCollect(collectedId) {
  let token = VueCookies.get(userTokenName)  
  console.log("用户收藏..");
  let result = request({
    url: baseUrl + "/find/user/collect?collectedId=" + collectedId + "&collectType=article",
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    }
  })
  return result
}


/**
 * 更新收藏夹
 * @param blogUserCollect 
 */
export function updateUserCollectMgtApi(blogUserCollectMgt) {
  let token = VueCookies.get(userTokenName)  
  console.log("用户收藏..");
  let result = request({
    url: baseUrl + "/update/user/collect/mgt",
    method: "post",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      "blog-user-token": token
    },
    data: blogUserCollectMgt
  })
  return result
}


