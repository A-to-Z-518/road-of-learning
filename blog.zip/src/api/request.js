/**
 * @author 沈光阳
 * @version 1.0
 */

import axios from "axios"
import VueCookies from 'vue-cookies'
import router from '@/router'
/**
 * 发送请求
 * @param url url
 * @param params 参数 { 参数 }
 * @returns Promise
 */
export default function request(config) {
  // 1. 创建axios实例
  const instance = axios.create({
    timeout: 100000
  })

  // 2. 对发出请求进行拦截
  instance.interceptors.request.use(config => {
    //config.headers['Access-Control-Allow-Origin'] = '*'
    // console.log(config)
    // 使用情况下使用请求拦截呢？
    // 1. 比如config中的一些配置不符合服务器要求
    // 2. 比如每次发送网络请求时候，都希望在界面中显示一个请求的图标
    // 3. 某些网络请求(比如登录（token）)，必须携带一些特殊的信息
    // 这块如果传递的token是null，后台不会放行该
    // if (VueCookies.get('gyblog_token') == null) {
    //   config.headers.Authorization = "";
    // } else {
    //   config.headers.Authorization = VueCookies.get('gyblog_token');
    // }
    
    
   
    // 对请求拦截后，一定要将config返回，否则axios内部在发出请求的时候
    // 获取不到config
    return config
  },error => {
    console.log(error)
  })

  // 对服务器的响应进行拦截
  instance.interceptors.response.use(res => {
    // console.log(res)
    // 这块对数据进行处理
    // 同样必须将res返回，或者只返回一些其他属性
    // 如果你不进行返回，在Promise的then方法中获取不到数据
    // if (res.data.code == 1004) {
    //   console.log("去登录");
    //   router.push("/login")
    // }
    return res.data
  })
  // 3. 真正发出网络请求
  return instance(config)
}



