import request from "./request.js"



/**
 * 标签接口
 */
const headers= {
  "Content-Type": "application/json;charset=UTF-8"
}



const baseUrl = "/blog-article";


  /**
  * 查询侧边栏标签
  * @param {s} tag 
  */
 export function findAllNavTag() {
  return request({
    url: baseUrl + "/tag/find/nav",
    method: "get",
    headers: {
      "Content-Type": "application/json;charset=UTF-8"
    },
  })
}



