<template>
<!-- 
向上抛出事件 select-sort , 回调参数是选中的标签字符串，比如vue,springboot,java

 -->
<!-- 选择标签组价 -->
  <div class="tag-box a-h" ref="tag">
    <div class="a-h">
      <!-- 用户选择的标签 -->
      <a class="tag-btn a-text-center a-h" 
        v-for="(item,index) in selectTag" 
        :key="index"
        :class="{'repeat-tag': repeatTagName == item.name}"
        href="javascript:;" @click="tagEvent">
        {{item.name}}
        <span @click="deleteSelectTag(index)">✗</span>
      </a>
    </div>
    <div class="tag-dropdown a-h">
      <button type="button" v-if="selectTagNum !== 0" class="button blue " @click="addTag">+  添加标签</button>
      
      <div class="dropdown-menu" :class="{'show': isShow && selectTagNum !== 0}">
        <div class="header">
          <span>还可添加 {{selectTagNum}}个标签</span>
          <a href="javascript:;" @click="createTag">创建标签</a>
        </div>
        <!-- 搜索标签 -->
        <div class="in">
          <input type="text" v-model="keyword" value="" placeholder="搜索标签">
          
        </div>
        <!-- 当进行搜索的时候才会展示，用户搜索到的数据 -->
        <div class="search-list" v-if="keyword != ''">
          <ul>
            <li  v-for="(item,index) in result" :key="index">
              <a class="search-list-item" href="javascript:;" v-html="item.showName" @click="userSelectTag(item)"></a>
            </li>
          </ul>
        </div>

        <div v-else> 
          <!-- 标签管理分组 -->
          <div>
            <ul>
              <li v-for="(item,index) in tagGroup" :key="index" :class="{'activatTag': tagActiveIndex == index}">
                <a href="javascript:;" @click="tagActiveIndex = index" >{{item.name}}</a>
              </li>
            </ul>
          </div>
          <!-- 展示分组下的标签 -->
          <div class="tag-list" :class="{'active': tagActiveIndex == index}" 
            v-for="(item , index) in tagList" :key="index">

            <a href="javascript:;" v-for="(item1,index1) in item"
              :key="index1" class="tag-item" @click="userSelectTag(item1)">{{item1.name}}</a>
          </div>
        </div>
      </div>
    </div>
    
  </div>
</template>

<script>

export default {
  props: {
   
    // 标签组
    tagGroup: {
      type: Array,
      default: function() {
        return [
          
        ]
      }
    },
    // 标签list
    tagList: {
      type: Array,
      default: function() {
        return [
          []
        
        ]
      }
    }
  },
  created() {

  },
  data() {
    return {
      keyword: "",
      //用于搜索实时展示结果
      result: [],

      isShow: false,

      // 选择的标签
      selectTag: [],
     
      // 当前激活的标签管理下标
      tagActiveIndex: 0,
     
      // 允许选择的标签数量
      selectTagNum: 4,

      timer: null,
      // 重复选择的标签名字
      repeatTagName: ""
    }
  },
  watch: {
    selectTag() {
      setTimeout(() => {
        // 实时显示被选中的标签
        let tags = []
        this.selectTag.forEach(value => {
          tags.push(value.name)
        })
        this.$emit("selected-tag",tags.join(","))
      },50)
    },
    keyword() {
      if (this.timer) {
        clearTimeout(this.timer)
      }

      if (!this.keyword) {
        this.result = []
        return
      }
      this.timer = setTimeout(() => {
        const  list = []
        for(let i in this.tagList) {
          
          // forEach遍历的是数组中的对象
          this.tagList[i].forEach((value) => {
            
            if (value.name.toLowerCase().indexOf(this.keyword.toLowerCase()) != -1 ) {
              let obj = {name: "",showName: ""}
              obj.name = value.name
              let reg = new RegExp("(" + this.keyword + ")", "g");
              obj.showName = value.name.replace(reg, "<font color=red>$1</font>");
              list.push(obj)
            }
          });
        }
        this.result = list  
      },100)
    }
  },
  methods: {
    // 设置初始标签
    setInitSelectTag(initSelectTag) {
      console.log("初始化标签");
      let tagList = initSelectTag.split(",")
      tagList.forEach(value => {
        let tagObj = {name: value}
        this.selectTag.push(tagObj)
      })
      
    },
    // 创建标签
    createTag() {
      this.isShow = false
      this.$emit('create-tag')
    },
    tagEvent() {
      console.log("标签事件");
    },
    // 打开添加标签面板
    addTag() {
      this.isShow = !this.isShow
    },
    // 用户选择标签
    userSelectTag(selectTag) {
      let isRepeatTag = false

      // 查看用户是否已经选择了该标签，使用便利
      this.selectTag.forEach(value => {
        if(value.name == selectTag.name) {
          console.log("用户重复选择标签");
          isRepeatTag = true
          this.repeatTagName = selectTag.name
        }
        setTimeout(() => {
          this.repeatTagName = ""
        },500)
      })

      console.log(this.repeatTagName);

      if(isRepeatTag == true) {
        return
      }

      // 用户标签数量减一
      this.selectTagNum--;
      this.selectTag.push(selectTag)
    },
    // 删除选择的标签
    deleteSelectTag(index) {
      this.selectTagNum++;
      this.selectTag.splice(index,1)
    }
  }
}
</script>

<style lang="less" scoped>

a {
  text-decoration: none;
}

.activatTag {
  background-color: #6c757d;
}


.a-h {
  height: 2rem;
  line-height: 2rem;
}

.tag-item {
  border-radius: 0.25rem;
  margin-left: 5px;
  height: 1rem;
  line-height: 1rem;
  font-size: 0.9rem;
  font-weight: 600px;
  background-color: #cffffe;
  color: #00bcd4  ;
}

.tag-item:hover {
  background-color: #7fdbda;
  color: #318fb5;
}

ul li ,
ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}

// li横向显示
ul{
  display: flex;
  // display: inline;
  // 上下10 左右10px
  padding: 0px 10px;
}

li {
  border-radius: .25rem;
  margin: 5px !important;
  list-style: none;
  line-height: 2rem;
  color: black;
  cursor: pointer;
  transition: background-color 0.5s linear,color 0.51s linear;
  -webkit-transition: background-color 0.5s linear,color 0.51s linear;
  -moz-transition: background-color 0.5s linear,color 0.5s linear;
  -o-transition: background-color 0.5s linear,color 0.5s linear;	
}

li:hover{
  background-color: #dddddd;
  color: #00bcd4;
}

.search-list ul {
  display: block;
}



.tag-list {
  display: none;
  
  flex-wrap: wrap;
  padding-left: 0.5rem;
  padding-right: 0.5rem;
  a {
    padding: 5px 10px ;
  }
}

.active {
  display: flex;
}

.tag-btn:hover {
  background-color: #7fdbda;
  color: #318fb5;
}

.tag-btn{
  display: inline-block;
  font-weight: 400;
  color: #212529;
  text-align: center;
  vertical-align: middle;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  background-color: transparent;
  border: 1px solid transparent;
  padding: 0rem .75rem;
  font-size: 1rem;
  height: 2rem;
  line-height: 2rem;
  border-radius: .25rem;
  transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
  background-color: #cffffe;
  color: #00bcd4  ;
  margin-right: 5PX;
}


input {
  display: block;
  width: 100%;
  height: calc(1.2em + .75rem + 2px);
  padding: .375rem .75rem;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: .25rem;
  transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
}
input:focus{
  border-color: #66afe9;
  outline: 0;
  -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);
  box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6)
}

.in {
  padding-left: 0.8rem!important;
  padding-right: 2.4rem!important;
}

.search-list ul li,
.header{
  padding-left: 0.8rem!important;
  padding-right: 0.8rem!important;
}

.search-list {
  margin-top: 10px;
  font-weight: 600px;
  padding-left: 0rem!important;
  padding-right: 0rem!important;
  color: #212529;
}

.search-list-item {
  display: block;
  width: 100%;
}
.search-list-item:hover {
  color: #0095cc;
}


.a-text-center {
  
  text-align: center;
  height: 30px;
  line-height: 30px;
}
.tag-box {
  display: flex;
  height: 2rem;
  // margin: 10px;
}


.dropdown-menu{
  position: absolute;
  // height: 200px;
  // top: 100%; 
  // left: 0; 
  z-index: 6000;
  // 设置弹出层和背景层的display属性为none;让他们默认隐藏不显示;
  display: none;
  // float: left;
  width: 28rem;
  padding: .5rem 0.6rem;
  margin: .125rem 0 0;
  font-size: 1rem;
  color: #212529;
  text-align: left;
  list-style: none;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid rgba(0,0,0,.15);
  border-radius: .3rem;
}

.show {
  display:block;
}

.button {
	display: inline-block;
	zoom: 1; /* zoom and *display = ie7 hack for display:inline-block */
	*display: inline;
	vertical-align: baseline;
	// margin: 0 2px; 
	outline: none;
	cursor: pointer;
	text-align: center;
	text-decoration: none;
	font: 14px/100% Arial, Helvetica, sans-serif;
  padding: 0em 1em .55em;
  height: 2rem;
	text-shadow: 0 1px 1px rgba(0, 0, 0, 0.3);
	-webkit-border-radius: .5em; 
	-moz-border-radius: .5em;
  border-radius: .5em;
  font-size: 1rem;
  line-height: 2rem;
	-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);
	-moz-box-shadow: 0 1px 2px rgba(0,0,0,.2);
  box-shadow: 0 1px 2px rgba(0,0,0,.2);
  margin-bottom: 10px;
  // margin-left: 10px;
}
.button:hover {
	text-decoration: none;
}
.button:active {
	position: relative;
	top: 2px;
}


.header {
  display: flex;
  // 对里面子元素添加样式，其中 justify-content: space-between; 这行能够起到左右对齐方式。
  justify-content: space-between;
  margin-bottom: 10px;
}


span {
  font-family: "Microsoft soft";
}

/* blue */
.blue {
	color: #d9eef7;
	border: solid 1px #0076a3;
	background: #0095cd;
	background: -webkit-gradient(linear, left top, left bottom, from(#00adee), to(#0078a5));
	background: -moz-linear-gradient(top,  #00adee,  #0078a5);
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#00adee', endColorstr='#0078a5');
}
.blue:hover {
	background: #007ead;
	background: -webkit-gradient(linear, left top, left bottom, from(#0095cc), to(#00678e));
	background: -moz-linear-gradient(top,  #0095cc,  #00678e);
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#0095cc', endColorstr='#00678e');
}
.blue:active {
	color: #80bed6;
	background: -webkit-gradient(linear, left top, left bottom, from(#0078a5), to(#00adee));
	background: -moz-linear-gradient(top,  #0078a5,  #00adee);
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#0078a5', endColorstr='#00adee');
}

// 重复选择的标签样式
.repeat-tag {
  background-color: #f0a500;
  color: #cf7500;
}

</style>