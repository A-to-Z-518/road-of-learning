<template>
  <!-- 登录面板 -->
  <me-dialog :isHide="isHide" @clone="lrbClone" class="login-main">
    <login-item v-if="!isRegister" 
      @register-event="registerEvent" 
      @login="login" 
      :loginLoading="loginLoading"
      :errorMeg="errorMeg"></login-item>
    <register-item  v-else @login-event="loginEvent"></register-item> 
  </me-dialog>
</template>

<script>
import MeDialog from "@/components/common/box/MeDialog.vue"
import LoginItem from "@/components/common/login/LoginItem.vue"
import RegisterItem from "@/components/common/login/RegisterItem"
export default {
  props: {
    isHide: {
      type: Boolean,
      default: true
    },
    loginLoading: {
      type: Boolean,
      default: false
    },
    errorMeg: {
      type: String,
      default: ''
    },
  },
  components: {
    MeDialog,LoginItem,RegisterItem
  },
  data() {
    return {
      isRegister: false
    }
  },
  methods: {
    login(form) {
      this.$emit('login',form)
    },
    register(form) {

    },
    lrbClone() {
      this.$emit('clone')
    },
    registerEvent() {
      this.isRegister = true
    },
    loginEvent() {
      console.log("注册事件=========");
      this.isRegister = false
    }
  }
}
</script>

<style lang="less" scoped>

</style>