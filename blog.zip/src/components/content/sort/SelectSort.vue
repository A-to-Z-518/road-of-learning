<template>
<!-- 
向上抛出事件 select-sort , 回调参数是选中的分类字符串

 -->
  <div class="select-sort">
    <div class="a-h" v-if="selectSort !== null">
      <!-- 用户选择的标签 -->
      <a class="sort-btn a-text-center a-h">
        {{selectSort}}
      </a>
    </div>
    <div class="time">
      <!-- 分类组件 -->
      <button type="button" class="button blue" @click="addSort">+  添加分类</button>
      <div class="dropdown-menu" :class="{'show': isShow}">
        <div class="header">
          <span></span>
          <a href="javascript:;" @click="createSort">创建分类</a>
        </div>  
      
        <div class="sort-list">
          <a v-for="(item,index) in sortList" 
            :key="index" class="sort-item" 
            href="javascript:;" 
            @click="selectSortEvent(index)" >
            {{item}}
          </a>
        </div>
          
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    
    sortList: {
      type: Array,
      default: function() {
        return [
          "java",
          "springboot",
          "springcloud",
          "工具"
        ]
      }
    },
  },
  created() {
    

  },
  data() {
    return {
      // 选择的标签
      selectSort: 3,
      // 是否展示面板
      isShow: false,
      selectSort: null
    }
  },
  methods: {
    // 设置初始分类
    setInitSelectSort(initSelectSort) {
      this.selectSort = initSelectSort
    },

    // 创建分类
    createSort() {
      this.isShow = false
      this.$emit("create-sort")
    },
    // 选中标签事件
    selectSortEvent(index) {
      this.selectSort = this.sortList[index]
      this.$emit("select-sort",this.selectSort)
    },
    addSort() {
      this.isShow = !this.isShow
    }
  }
}
</script>

<style lang="less" scoped>


a {
  text-decoration: none;
  
}

.a-h {
  height: 2rem;
  line-height: 2rem;
}

.select-sort {
  display: flex;
  justify-content: center;
}

.a-text-center {
  text-align: center;
}

.sort-btn:hover {
  background-color: #7fdbda;
  color: #318fb5;
}


.sort-list {
  display: block;
  flex-wrap: wrap;
  padding-left: 0.5rem;
  padding-right: 0.5rem;
  a {
    padding: 5px 10px ;
  }
}

.sort-item {
  border-radius: 0.25rem;
  margin-left: 5px;
  height: 2rem;
  line-height: 2rem;
  font-size: 0.9rem;
  font-weight: 600px;
  background-color: #cffffe;
  color: #00bcd4  ;
}

.sort-item:hover {
  background-color: #7fdbda;
  color: #318fb5;
}

.sort-btn{
  display: inline-block;
  font-weight: 400;
  color: #212529;
  text-align: center;
  vertical-align: middle;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  background-color: transparent;
  border: 1px solid transparent;
  padding: 0rem .8rem;
  font-size: 1rem;
  height: 2rem;
  line-height: 2rem;
  border-radius: .25rem;
  transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
  background-color: #cffffe;
  color: #00bcd4  ;
  margin-right: 5PX;
}

.header{
  display: flex;
  // 对里面子元素添加样式，其中 justify-content: space-between; 这行能够起到左右对齐方式。
  justify-content: space-between;
  margin-bottom: 0px;
  padding-left: 0.8rem!important;
  padding-right: 0.8rem!important;
}


.dropdown-menu {
  position: absolute;
  // height: 200px;
  // top: 100%; 
  // left: 0; 
  z-index: 6000;
  // 设置弹出层和背景层的display属性为none;让他们默认隐藏不显示;
  display: none;
  // float: left;
  width: 28rem;
  padding: .5rem 0.6rem;
  margin: .125rem 0 0;
  font-size: 1rem;
  color: #212529;
  text-align: left;
  list-style: none;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid rgba(0,0,0,.15);
  border-radius: .3rem;
}

.show {
  display:block;
}

.button {
	display: inline-block;
	zoom: 1; /* zoom and *display = ie7 hack for display:inline-block */
	*display: inline;
	vertical-align: baseline;
	// margin: 0 2px; 
	outline: none;
	cursor: pointer;
	text-align: center;
	text-decoration: none;
	font: 14px/100% Arial, Helvetica, sans-serif;
  padding: 0em 1em .55em;
  height: 2rem;
	text-shadow: 0 1px 1px rgba(0, 0, 0, 0.3);
	-webkit-border-radius: .5em; 
	-moz-border-radius: .5em;
  border-radius: .5em;
  font-size: 1rem;
  line-height: 2rem;
	-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);
	-moz-box-shadow: 0 1px 2px rgba(0,0,0,.2);
  box-shadow: 0 1px 2px rgba(0,0,0,.2);
  margin-bottom: 10px;
  // margin-left: 10px;
}
.button:hover {
	text-decoration: none;
}
.button:active {
	position: relative;
	top: 2px;
}

/* blue */
.blue {
	color: #d9eef7;
	border: solid 1px #0076a3;
	background: #0095cd;
	background: -webkit-gradient(linear, left top, left bottom, from(#00adee), to(#0078a5));
	background: -moz-linear-gradient(top,  #00adee,  #0078a5);
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#00adee', endColorstr='#0078a5');
}
.blue:hover {
	background: #007ead;
	background: -webkit-gradient(linear, left top, left bottom, from(#0095cc), to(#00678e));
	background: -moz-linear-gradient(top,  #0095cc,  #00678e);
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#0095cc', endColorstr='#00678e');
}
.blue:active {
	color: #80bed6;
	background: -webkit-gradient(linear, left top, left bottom, from(#0078a5), to(#00adee));
	background: -moz-linear-gradient(top,  #0078a5,  #00adee);
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#0078a5', endColorstr='#00adee');
}

</style>