<template>
  <!-- <div  > -->
    <button @click="buttonEvent" class="btn"><slot></slot></button>
</template>

<script>
export default {
  methods: {
    buttonEvent() {
      this.$emit('buttonEvent')
    }
  }
}
</script>

<style lang="less" scoped>
.btn{
  display: block;
  height: 35px;/*设置按钮高度*/
  color:#1b262c;/*字体颜色*/
  background-color:#d7fffd;/*按钮背景颜色*/
  border-radius: 3px;/*让按钮变得圆滑一点*/
  border-width: 0;/*消去按钮丑的边框*/
  margin: 0;
  outline: none;/*取消轮廓*/
  font-family: KaiTi;/*字体设置为楷体*/
  font-size: 18px;/*设置字体大小*/
  text-align: center;/*字体居中*/
  cursor: pointer;/*设置鼠标箭头手势*/
  padding: 2px 10px;
  margin-right: 10px;
}
.btn:hover{/*鼠标移动时的颜色变化*/
  background-color: #2fc4b2;
}

</style>