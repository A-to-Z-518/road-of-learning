<template>
  <div>
    <!-- 验证码组件 -->
    <img :src="verifyCode" @click="getVerifyCodeEvent()" style="float:right;" alt="Loading...">
  </div>
</template>

<script>
import {getValidCode} from "@/api/valid-code.js"
export default {
  data() {
    return {
      verifyCode: ""
    }
  },
  methods: {
    validCode() {
      getValidCode().then(res => {
        let url = 'data:image/png;base64,' + res.data
        console.log(url);
        this.verifyCode = url
      })
    },
    getVerifyCodeEvent() {
      this.validCode()
    }
  },
  mounted() {
    this.validCode()
  }
}
</script>

<style>

</style>