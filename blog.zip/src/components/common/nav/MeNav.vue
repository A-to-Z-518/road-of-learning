<template>
  <div class="me-navbar" :style="{height:navHeight}">
    <div class="navbar" :style="{width: totalWidth + 'px'}">
      <div class="navbar-left" :style="{lineHeight: navHeight,width: leftWidth + 'px'}"> 
        <!-- 左侧 -->
        <slot name="left">
          <div class="left">左侧ert34523</div>
        </slot>
      </div>

      <!-- 右侧 -->
      <div class="navbar-right" :style="{lineHeight: navHeight,width: (totalWidth - leftWidth) + 'px'}"> 
        <slot name="right">
          <div class="right">右侧</div>
        </slot>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    // 导航栏默认高度
    navHeight: {
      type: String,
      default: "60px"
    },
    // 总宽度
    totalWidth: {
      type: Number,
      default: 1200
    },
    // 左侧宽度，右侧宽度会自动计算
    leftWidth: {
      type: Number,
      default: 850
    }
  },
  data() {
    return {
      
    }
  }
}
</script>
<style lang="less" scoped>

// 导航栏底层的最小宽度
@navMinWidth: 1200px;
// 导航栏宽度
@navWidth: 1200px;
@navLeftWidth: 900px;
@navRightWidth: 300px;
// 导航栏背景颜色
@navBackgroundColor: #fff;

.me-navbar {
  width: 100%;
  min-width: @navMinWidth;
  background-color: @navBackgroundColor;
}

.navbar {
  display: flex;
  height: 100%;
  width: @navWidth;
  margin: 0px auto;
  background-color: @navBackgroundColor;
}

.navbar-left {
  display: flex;
  width: @navLeftWidth;
}


.navbar-right {
  display: flex;
  flex-direction: row-reverse;
  // flex: 1;
  width: @navRightWidth;
}

.left {
  height: 100%;
  background-color: red;
}

.right {
  height: 100%;
  background-color:pink;
}
</style>