<template>
  <div class="navbar" :class="{'visible':isVisible}">
    <me-nav :leftWidth="900">
      <template v-slot:left>
        <me-nav-logo class="nav-item"></me-nav-logo>
        <me-nav-menu ref="meNavMenu" @active-index="activeIndex" :menuList="menuList" :defaultActiveMenuIndex="defaultActiveMenuIndex"></me-nav-menu>
        <me-nav-search :defaultSearchValue="defaultSearchValue" @search="goSearchPage"></me-nav-search>
      </template>
      <template v-slot:right>
        <me-nav-avatar v-if="user.isLogin" :userInfo="user.info" @login-out="loginOut"></me-nav-avatar>
        <me-nav-login  v-else :loginLink="loginLink"></me-nav-login>
        <me-nav-message class="nav-item"></me-nav-message>
        <me-nav-button class="nav-item" @buttomItemClick="buttomItemClick" :navButtonInfo="navButtonInfo"></me-nav-button>
      </template>
    </me-nav>

  </div>
</template>

<script>
import MeNav from "./MeNav"
import MeNavLogo from "./item/MeNavLogo"
import MeNavMenu from "./item/MeNavMenu"
import MeNavSearch from "./item/MeNavSearch"

// 右侧
import MeNavAvatar from "./item/MeNavAvatar"
import MeNavLogin from "./item/MeNavLogin"
import MeNavMessage from "./item/MeNavMessage"
import MeNavButton from "./item/MeNavButton"

import {userTokenName,userInfoName} from "@/util/const.js"
import {getUserInfo} from "@/api/user.js"
export default {
  props: {
    // 搜索框内默认值
    defaultSearchValue: {
      type: String,
      default: ""
    },
    menuList: {
      type: Array,
      default: function() {
        return [
          {name: "博客" , link: "/home"},
          {name: "问答" , link: "#"},
          {name: "学院" , link: "#"},
          {name: "在线工具" , link: "#"}
        ]
      }
    },
    // 是否展示
    isVisible: {
      type: Boolean,
      default: true
    },
    // 默认激活的菜单
    defaultActiveMenuIndex: {
      type: Number,
      default: -1
    }
  },
  components: {
    // 左侧
    MeNav,MeNavLogo,MeNavMenu,MeNavSearch,
    // 右侧
    MeNavAvatar,MeNavMessage,MeNavButton,MeNavLogin
  },
  created() {
    this.getUserInfo()
  },
  mounted() {
    // 设置头像
    // this.userInfo.avatar = this.$store.getters.getUserInfo().avatar
  },
  data() {
    return {
      // 用户信息
      user: {
        // 用户是否登录
        isLogin: false,
        info: {
          usernick: "哦，我的皇帝陛下",
          avatar: "https://up.enterdesk.com/edpic_source/1f/8d/80/1f8d800f610fd0f0201bd95cadcd9933.jpg"
        }
      }
      ,
      navButtonInfo: {
        name: "创作",
        link: "/article/write"
      },
      
      loginLink: "/login"
    }
  },
  methods: {
    /**
     * 获取用户信息
     */
    getUserInfo() {
      // 先从本地cookie获取用户的信息
      console.log("先从本地cookie获取用户的信息");
      let user = this.$cookies.get(userInfoName)
      console.log(user);
      if (user !== null) {
        this.user = user
        return
      }

      // 访问后台获取用户的基本信息
      let token = this.$cookies.get(userTokenName)  
      if(token == undefined || token == null || token == "") return
      console.log("用户cookie中获取到了token ");
      
      getUserInfo(token).then(res => {
        console.log(res);
        if (res.code !== 200) {
          return
        }
        this.user.isLogin = true
        this.user.info = res.data
        // 将用户信息存入到cookie中
        this.$cookies.set(userInfoName,this.user,"5d")
      })
    },
    goSearchPage(query) {
      // console.log("搜索的关键字 = " + query);
      this.$emit('search-query',query)
    },
    activeIndex(index) {
      this.$emit('active-index',index)
    },
    buttomItemClick(link) {
      console.log("触发事件");
      this.isVisible = true
      this.$router.push(link)
    },
    getActiveIndex() {
      return this.$refs.meNavMenu.activeMenuIndex
    },
    setActiveIndex(index) {
      this.$refs.meNavMenu.activeMenuIndex = index
    },
    /**
     * 登出事件
     */
    loginOut() {
      console.log("用户退出");
      this.user.isLogin = false
      this.user.info = {}

      // 移除cookie
      this.$cookies.remove(userTokenName)
      this.$cookies.remove(userInfoName)
      // 跳转到首页
      console.log("跳转到首页");
      this.$router.push("/home")
    }
  }
}
</script>

<style lang="less" scoped>

.nav-item {
  margin-right: 10px;
}





.navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  transition: all .2s;
  // 这他妈的是什么属性，不显示
  transform: translate3d(0,-100%,0);
}

// 必须在后面，我要覆盖 transform: translate3d(0,-100%,0);
.visible {
  transform: translateZ(0);
}


</style>