<template>
  <div @click="buttomItemClick(navButtonInfo.link)" class="me-nav-button">
    <el-button type="primary" size="medium" round >
        {{navButtonInfo.name}}
    </el-button>
  </div>
</template>

<script>
// 按钮组件
export default {
  props: {
    navButtonInfo: {
      type: Object,
      default: function() {
        return {
          name: "默认",
          link: "#"
        }
      }
    }
  },
  methods: {
    buttomItemClick(link) {
      this.$emit('buttomItemClick',link)
    }
  }
}
</script>

<style lang="less" scoped>
a {
  text-decoration: none;
}
a:hover {
  color: #000000;
}
</style>