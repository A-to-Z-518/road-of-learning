<template>
<!-- 导航栏logo -->
  <div class="logo">
    <img src="@/assets/logo.png" alt="">
  </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
.logo {
  position: relative;
  width: 150px;
  height: 100%;
  // background-color: aqua;
}

.logo img {
  width: 150px;
  height: 70%;
  position: absolute;  
  top: 0;  
  bottom: 0;  
  left: 0;  
  right: 0;  
  margin: auto;
}



</style>