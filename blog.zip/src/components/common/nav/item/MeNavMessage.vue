<template>
<!-- 这是一个消息组件，用于头部，比如公告或者私信 -->
  <el-dropdown class="me-nav-message" size="medium" placement="bottom" @command="handleCommand">
    <div><svg-icon icon-class="message" class="message-icon"></svg-icon></div>
    <!-- <img src="@/assets/img/message.png" alt=""> -->
    <el-badge :value="totalMessageCount" :max="99" class="item"></el-badge>
    <el-dropdown-menu slot="dropdown">
      <el-dropdown-item v-for="(item,index) in messageMenu" :key="index">
        <router-link tag="a" target="_blank" :to="item.link" >
          <span>{{item.name}}</span>
          <span class="count">{{item.count}}</span>
        </router-link>
        
      </el-dropdown-item>
    </el-dropdown-menu>
  </el-dropdown>
</template>

<script>
export default {
  props: {
    messageMenu: {
      type:Array,
      default: function() {
        return [
          {name: "公告",count: 2,link: "#"},
          {name: "私信",count: 20,link: "#"}
        ]
      }
    }
  },
  computed:{
    totalMessageCount() {
      let total = 0
      console.log(this.messageMenu);
      for (let item in this.messageMenu) {
        total += this.messageMenu[item].count
      }
      console.log(total);
      return total
    }
  },
  methods: {
    handleCommand(value) {

    }
  }
}
</script>

<style lang="less" scoped>
.me-nav-message {
  // position: relative;
  display: flex;
  align-items: center;
  height: 100%; 
  cursor: pointer;
}

.message-icon {

  width: 1.8em !important;
  height: 1.8em !important;
  vertical-align: -0.5em !important;
  
}
a {
  text-decoration: none;
}

span {
  display: inline-block;
}
.count {
  margin-left: 15px;
  color: #999;
}

.el-dropdown-menu {
  min-width: 100px;
}
</style>