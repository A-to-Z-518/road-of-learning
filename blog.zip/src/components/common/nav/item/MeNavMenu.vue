<template>
  <div class="me-nav-menu">
    <ul>
      <li v-for="(item,index) in menuList" :key="index" @click="activeItem(index,item.link)">
        <!-- <router-link :to="item.link" :class="{'active': index == activeMenuIndex}">{{item.name}}</router-link> -->
        <span :class="{'active': index == activeMenuIndex}">{{item.name}}</span>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "MeNavMenu",
  props: {
    menuList: {
      type: Array,
      default: function() {
        return [
          {name: "博客" , link: "#"},
          {name: "问答" , link: "#"},
          {name: "学院" , link: "#"},
          {name: "在线工具" , link: "#"},
          {name: "在线工具" , link: "#"},
          {name: "在线工具" , link: "#"},
          {name: "在线工具" , link: "#"},
        ]
      }
    },
    // 默认激活的菜单
    defaultActiveMenuIndex: {
      type: Number,
      default: -1
    }
  },
  data() {
    return {
      // 激活的下表
      activeMenuIndex: -1,
      // 将激活的index存入到浏览器中的名称
      storageName: "nav_active_index"
    }
  },
  created() {
    // 如果传入了默认值就将其存入到本地的 storage
    console.log("MeNavMenu组件已经被创建");
    let index = window.sessionStorage.getItem(this.storageName)
    if(index != null && index != "") this.activeMenuIndex = index
  },
  methods: {
    activeItem(index,link) {
      console.log("当前激活的下标: " + index);
      this.activeMenuIndex = index
      window.sessionStorage.setItem(this.storageName,index)
      this.$emit('active-index',index)
      this.$router.push(link)
    },
    getActiveIndex() {
      return this.activeMenuIndex
    },
    setActiveIndex(index) {
      this.activeMenuIndex = index
    }
  }
}
</script>

<style lang="less" scoped>


ul li ,
ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}

a {
  text-decoration: none;
}


.me-nav-menu ul li span {
  display: block;
  // 高度必须是 nav的高度
  height: 90%;
  // 上下10 左右10px
  padding: 0px 5px;
  color: #050505;
  cursor: pointer;
}

// li横向显示
.me-nav-menu ul{
  display: flex;
  // display: inline;
  // 上下10 左右10px
  padding: 0px 5px;
}

/* 当鼠标经过的时候显示颜色 */
a:hover {
  color: #00bcd4;
}
// 当鼠标经过的时候显示下边框
.me-nav-menu ul li a:hover {
  border-bottom: 2px solid #00bcd4;
  color: #00bcd4;
}

.active {
  border-bottom: 2px solid #00bcd4 !important;
  color: #00bcd4 !important;
}
</style>