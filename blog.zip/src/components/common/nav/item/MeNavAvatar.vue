<template>
  <!-- 头像区域 -->
  <div class="me-nav-avatar">
    <el-dropdown size="medium" placement="bottom" @command="handleCommand">
      <el-avatar size="large" :src="userInfo.avatar"></el-avatar>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item v-for="(item,index) in dropdownMenu" :key="index">
          <router-link tag="a" target="_blank" :to="item.link" >
            {{item.menuName}}
          </router-link>
        </el-dropdown-item>
        <el-dropdown-item >
          <span @click="loginOut">{{loginout.menuName}}</span>
        </el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
  </div>
</template>

<script>
export default {
  props: {
    // 用户信息
    userInfo: {
      type: Object,
      default: function() {
        return {
          usernick: "哦，我的皇帝陛下",
          avatar: "https://up.enterdesk.com/edpic_source/1f/8d/80/1f8d800f610fd0f0201bd95cadcd9933.jpg"
        }
      }
    },
    // 下拉菜单
    dropdownMenu: {
      type: Array,
      default: function() {
        return [
          {menuName: "关于我",link:"#"},
          {menuName: "个人中心",link:"/uc"},
          {menuName: "账号设置",link:"#"}
        ]
      }
    },
    // 退出
    loginout: {
      type: Object,
      default: function() {
        return {
          menuName: "退出",link:"#"
        }
      }
    }
  },
  data() {
    return {

    }
  },
  methods: {
    handleCommand(value) {

    },
    /**
     * 退出
     */
    loginOut() {
      this.$emit("login-out")
    }
  }
}
</script>

<style lang="less" scoped>
.me-nav-avatar {
  font-size: 14px;
  color: #666;
  cursor: pointer;
}


// 将图片和文字进行水平中心对齐
.me-nav-avatar .el-avatar {
  display: inline-block;
  vertical-align: middle;
}

a {
  text-decoration: none;
}

.el-dropdown-menu {
  min-width: 100px;
}
</style>