<template>
  <div class="me-nav-search">
    <!-- 搜索框 -->
    <el-input v-model="query" placeholder="请输入关键字" @keyup.enter.native="search"></el-input>
  </div>
</template>

<script>
// 事件 search 参数 搜索的关键字
export default {
  props: {
    // 搜索框内默认值
    defaultSearchValue: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      query: ""
    }
  },
  created() {
    this.query = this.defaultSearchValue
  },
  methods: {
    // 搜索
    search() {
      this.$emit("search",this.query)
    },
  }
}
</script>

<style lang="less" scoped>
.me-nav-search {
  flex: 1;
  // background-color:pink;
}

.me-nav-search {
  width: 100%;
  height: 100%;
}

.me-nav-search .el-input {
  height: 100%;
  line-height: 100%;
}
</style>