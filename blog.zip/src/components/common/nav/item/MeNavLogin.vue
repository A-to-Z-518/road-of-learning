<template>
<!-- 用户没有登录的情况下展示该组件 -->
  <div>
    <span>
      <router-link :to="loginLink">登录/注册</router-link>
    </span>
  </div>
</template>

<script>
export default {
  props: {
    // 登录的链接
    loginLink: {
      type: String,
      default: "#"
    }
  }
}
</script>

<style lang="less" scoped>
span {
  display: flex;
  cursor: pointer;
}
// span:hover {
//   color: red;
// }
a {
  text-decoration: none;
}
</style>