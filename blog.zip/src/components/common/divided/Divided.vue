<!--分割线-->
<template>
  <div class="line">
    <span></span>
  </div>
</template>

<script>
export default {

}
</script>
<style lang="less" scoped>
.line {
  height: 1px;
  border-top: 1px solid #ddd;
}
</style>