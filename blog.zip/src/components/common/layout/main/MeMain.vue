<template>
  <scroll  @scroll-event="scrollEvent" > 
    
    <div class="main-box">
      <!-- 左侧 必须设置宽度，否则当容器position: 'fixed' 中间会向左移动，达不到自己想要的效果-->
      <div class="main-left-box" v-if="leftBox.isNeed" ref="MainLeftBox" :style="{width: leftBox.width + 'px'}"> 
        <!-- 吸顶组件 -->
        <left-box-top v-if="isLeftTop" 
          ref="LeftBox" 
          :width="leftBox.width" 
          :leftBoxToLeftDis="leftBoxToLeftDistance"
          :suctionTop="suctionTop"
          :moveSuctionTop="moveSuctionTop"
          :isStartSuctionTop="isStartSuctionTop">
          <slot name="left"></slot>
        </left-box-top>

        <!-- 吸底组件 -->
        <left-box-bottom v-else 
          ref="LeftBox" 
          :width="leftBox.width"
          :topHeight="suctionBottom.topHeight"
          :leftBoxToLeftDistance="leftBoxToLeftDistance">
          <slot name="left"></slot>
        </left-box-bottom>
      </div>
      <!-- 中间容器 -->
      <div class="main-center-box" :style="{width: mainCenterBoxWidth + 'px'}">
        <div ref="MainCenter">
          <slot name="center"></slot>
        </div>
      </div>
      <!-- 右侧容器 -->
      <div class="main-right-box" v-if="rightBox.isNeed" :style="{width: rightBox.width + 'px'}"> 
        <right-box-top v-if="isRightTop" 
          :width="rightBox.width"
          ref="RightBox"
          :suctionTop="suctionTop"
          :isStartSuctionTop="isStartSuctionTop"
          :rightBoxToLeftDis="rightBoxToLeftDistance">
          <slot name="right"></slot>
        </right-box-top>
        <right-box-bottom v-else 
          :width="rightBox.width"
          ref="RightBox"
          :topHeight="suctionBottom.topHeight"
          :rightBoxToLeftDis="rightBoxToLeftDistance">
          <slot name="right"></slot>
        </right-box-bottom>
      </div>
    </div>
  </scroll>
</template>

<script>


import Scroll from "@/components/common/scroll/Scroll.vue"
import LeftBoxTop from "./child/LeftBoxTop"
import LeftBoxBottom from "./child/LeftBoxBottom"
import RightBoxTop from "./child/RightBoxTop"
import RightBoxBottom from "./child/RightBoxBottom"
export default {
  components: {
    LeftBoxTop,LeftBoxBottom,Scroll,
    RightBoxBottom,RightBoxTop
  },
  props: {
    // 左侧盒子
    leftBox: {
      type: Object,
      default: function() {
        return {
          // 是否需要
          isNeed: true,
          isFixed: true,
          width: 200 
        }
      }
    },
    // 右侧盒子
    rightBox: {
      type: Object,
      default: function() {
        return {
          // 是否需要
          isNeed: true,
          width: 200 
        }
      }
    },
    moveSuctionTop: {
      type: Number,
      default: 0
    },
    // 吸顶
    suctionTop: {
      type: Object,
      default: function() {
        return {
          // 吸顶后距离顶部的高度
          moveTopHeight: 0,
          // 是否由外部控制什么时候吸顶
          isExternalController: false,
        }
      }
    },
    // 是否开始吸顶,只有在 isExternalController 为true时候才生效
    isStartSuctionTop: {
      type: Boolean,
      default: false
    },
    // 吸底
    suctionBottom: {
      type: Object,
      default: function() {
        return {
          // 距离顶部的高度
          topHeight: 0,
         
        }
      }
    }
  },
 
  
  data() {
    return {

      isVisible: true,
      // 左侧是否吸顶
      isLeftTop: false,
      // 右侧是否吸顶
      isRightTop: false,
      // 左边盒子到左侧的距离
      leftBoxToLeftDistance: 0,
      // 右边到右侧的距离
      rightBoxToLeftDistance: 0,
      scrollLenth: 0,

      leftBoxHeight: '',
      // // 中间容器的宽度
      mainCenterBoxWidth: 0,
      isCenterBoxGtLeft: false,
      isCenterBoxGtRight: false,

      leftHeight: 0,
      rightHeight: 0,

      // // 判断是否有滚动条
      // isHasScrollbar: true

      
    }
  },
  mounted() {
    
  },
  
  methods: {
    /**
     * @param slotHeight 这是一个对象 {left: 0, center: 0, right: 0}
     */
    init(slotHeight) {
      
      // 左侧盒子高度
      if(this.leftBox.isNeed)this.leftHeight = this.$refs.LeftBox.$el.offsetHeight
      // 右侧盒子高度
      if(this.rightBox.isNeed) this.rightHeight = this.$refs.RightBox.$el.offsetHeight
      console.log("左侧盒子高度 = " + this.leftHeight + "        右侧盒子高度 = " + this.rightHeight);

      console.log("-------------->" + this.centerMinHeight);
      // 获取左边容器的左边距
      this.leftBoxToLeftDistance = (this.getMainCenterBoxPos().left - this.leftBox.width - 10).toFixed(1)/1 
      console.log("leftBoxToLeftDistance = " + this.leftBoxToLeftDistance);

      // 获取中间面板的宽度,如果传入的是组件就用$el获取组件高度，否则直接获取高度
      if(this.$refs.MainCenter.$el !== undefined) this.mainCenterBoxWidth = this.$refs.MainCenter.$el.offsetWidth
      else this.mainCenterBoxWidth = this.$refs.MainCenter.offsetWidth

      
      console.log("中间面板的宽度 = " + this.mainCenterBoxWidth);

      // 获取右边容器距离左边的距离
      this.rightBoxToLeftDistance = (this.getMainCenterBoxPos().left + this.mainCenterBoxWidth).toFixed(1)/1
      console.log("rightBoxToLeftDistance = " + this.rightBoxToLeftDistance);
      console.log("中间div距离左侧的距离: " + this.getMainCenterBoxPos().left);
      console.log("中间div宽度" + this.mainCenterBoxWidth);

      // 获取可视页面的高度
      let clientHeight = document.documentElement.clientHeight;

      // 左侧初始化
      if(this.leftBox.isNeed) this.leftInit(this.leftHeight,clientHeight)
      // 右侧
      if(this.rightBox.isNeed) this.rightInit(this.rightHeight,clientHeight)

      this.updateMainHeight()
      
   },

    scrollEvent(scroll) { 
      this.scrollLenth = scroll.toFixed(1)/1

      // console.log("this.getMainCenterBoxPos().left = " + this.getMainCenterBoxPos().left);
      this.leftBoxToLeftDistance = (this.getMainCenterBoxPos().left - this.leftBox.width - 10).toFixed(1)/1
      console.log("leftBoxToLeftDistance = " + this.leftBoxToLeftDistance);
      
      // 获取右边容器距离右边的距离
      console.log("中间div距离左侧的距离: " + this.getMainCenterBoxPos().left);
      console.log("中间div宽度" + this.mainCenterBoxWidth);
      this.rightBoxToLeftDistance = (this.getMainCenterBoxPos().left + this.mainCenterBoxWidth + 10).toFixed(1)/1

      // console.log("this.getMainCenterBoxPos().left + this.centerBox.width = " + this.rightBoxToLeftDistance);
      // 左侧判断是吸顶还是吸底
      if(this.leftBox.isNeed) {
        this.leftBoxScrollProcess()
      }
      
      //右侧 判断是吸顶还是吸底
      if(this.rightBox.isNeed) {
        this.rightBoxScrollProcess()
      }
      
      
      
    },
    // 获取MainCenterBox位置
    getMainCenterBoxPos() {
      return this.$refs.MainCenter.getBoundingClientRect()
    },

    /**
     * 左侧初始化
     */
    leftInit(leftHeight,clientHeight) {
      // 1. 判断左侧的高度是否大于可视页面的高度，决定是吸底还是吸顶(isLeftTop)
      // console.log(this.$refs.LeftBox);
      // console.log("左侧的高度 : " + mainLeftBoxHeight);
      this.isLeftTop = clientHeight > leftHeight
      // console.log("左侧是否需要吸顶 : " + this.isLeftTop);
    },
    /**
     * 右侧初始化
     */
    rightInit(rightHeight,clientHeight) {
      // 2. 判断右侧的高度是否大于可视页面的高度，决定是吸底还是吸顶(isRightTop)
      this.isRightTop = clientHeight > rightHeight
      // console.log("右侧是否需要吸顶 : " + this.isRightTop);
    },

    // 左侧盒子滚动处理
    leftBoxScrollProcess() {
      if(this.isLeftTop) {
        this.$refs.LeftBox.scrollEvent(this.scrollLenth,this.leftBoxToLeftDistance)
      } else if(this.isCenterBoxGtLeft){
        this.$refs.LeftBox.scrollEvent(this.scrollLenth,this.leftBoxToLeftDistance)
      }
    },

    rightBoxScrollProcess() {
      if(this.isRightTop) {
        this.$refs.RightBox.scrollEvent(this.scrollLenth,this.rightBoxToLeftDistance)
      } else if(this.isCenterBoxGtRight){
        this.$refs.RightBox.scrollEvent(this.scrollLenth,this.rightBoxToLeftDistance)
      }
    },
    /**
     * 判断main标签的高度是否大于fixed面板的高度，
     * 如果main高度更新了调用此方法 ref进行调用
     */
    updateMainHeight() {
      // 左侧盒子高度
      if(this.leftBox.isNeed)this.leftHeight = this.$refs.LeftBox.$el.offsetHeight
      // 右侧盒子高度
      if(this.rightBox.isNeed) this.rightHeight = this.$refs.RightBox.$el.offsetHeight

      console.log("左侧盒子高度 = " + this.leftHeight + "        右侧盒子高度 = " + this.rightHeight);

      // 判断main标签的高度是否大于fixed面板的高度
      let mainHeight = this.$refs.MainCenter.offsetHeight
      console.log("mainHeight = " + mainHeight);
      if (mainHeight >= this.leftHeight) 
        this.isCenterBoxGtLeft = true
      else
        this.isCenterBoxGtLeft = false
      
      if (mainHeight >= this.rightHeight) 
        this.isCenterBoxGtRight = true
      else
        this.isCenterBoxGtRight = false

      console.log("this.isCenterBoxGtLeft  this.isCenterBoxGtRight = " + this.isCenterBoxGtLeft + "  " + this.isCenterBoxGtRight);
    },

    /**
     * 判断是否有滚动条
     */
    // hasScrollbar() {
    //   return document.body.scrollHeight > (window.innerHeight || document.documentElement.clientHeight);
    // }
  }
}
</script>

<style lang="less" scoped>
@import "@/assets/less/style.less";
@import "@/assets/less/navbar.less";

.main-box {
  display: flex;
  
  // width: 1200px;
  // margin: 10px auto;
  // margin-top: 70px;
}

.main-left-box {
  margin-right: 10px;
  // background-color: red;
}
.main-center-box {
  flex: 1;
}

.main-right-box {
  margin-left: 10px;
  // background-color: pink;
}

.left-box {
}
</style>