<template>
  <div 
    ref="box"
    class="left-box-top" 
    id="id-left-box-top" 
    :style="{width: width + 'px',transition: 'all 0.5s' ,position: style.position,left: leftBoxToLeftDistance + 'px'}">
    <slot></slot>
  </div>
</template>

<script>
export default {
  props: {
    width: {
      type: Number,
      default: 200
    },
    // 吸顶
    suctionTop: {
      type: Object,
      default: function() {
        return {
          // 吸顶后距离顶部的高度
          moveTopHeight: 0,
          // 是否由外部控制什么时候吸顶
          isExternalController: false,
        }
      }
    },
    // 是否开始吸顶,只有在 isExternalController 为true时候才生效
    isStartSuctionTop: {
      type: Boolean,
      default: false
    },
    // 容器上移suctionTop高度后吸顶
    moveSuctionTop: {
      type: Number,
      default: 10
    },
    // 中间容器距离左边的位置
    leftBoxToLeftDis: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      // 样式
      style: {
        position:'fixed',
        left: 0
      },
      leftBoxToLeftDistance: 0
      
    }
  },
  mounted() {
    this.leftBoxToLeftDistance = this.leftBoxToLeftDis
    document.getElementById("id-left-box-top").style.position=null;
  },
  components: {
    
  },
  methods: {
    getoffsetHeight() {
      // console.log("左侧高度 ： " + this.$refs.box.offsetHeight);
      return this.$refs.box.offsetHeight
    },
    // 参数1: 滚动条滚动的距离，通过父组件ref进行调用
    // 参数2: 左侧盒子距离可视界面的左侧距离
    scrollEvent(scroll,leftBoxToLeftDistance) {
      console.log(scroll);
      // 设置左边盒子距离左侧的边距
      this.leftBoxToLeftDistance = leftBoxToLeftDistance

      console.log("组件自行控制吸顶");

      // 组件自行控制吸顶
      if(scroll > this.moveSuctionTop) {
        this.addStyle()
      } else {
        this.removeStyle()
      }


      // 横向滚动条，滚动距离
      // console.log(maincenterBoxToLeft);
    },
    // 添加样式
    addStyle() {
      document.getElementById("id-left-box-top").style.position=this.style.position;
      document.getElementById("id-left-box-top").style.top=70 + 'px';
    },

    // 移除样式
    removeStyle() {
      document.getElementById("id-left-box-top").style.position=null;
    },

    
  }
}
</script>

<style lang="less" scoped>
.left-box-top {
  width: 200px;
}
</style>