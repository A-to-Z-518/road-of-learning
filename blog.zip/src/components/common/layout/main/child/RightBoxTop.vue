<template>
  <div 
    ref="box"
    class="right-box-top" 
    id="id-right-box-top" 
    :style="{width: width + 'px',transition: 'all .5s',left: rightBoxToLeftDistance + 'px'}">
    <slot></slot>
  </div>
</template>

<script>
export default {
  props: {
    width: {
      type: Number,
      default: 280
    },
    // 吸顶
    suctionTop: {
      type: Object,
      default: function() {
        return {
          // 吸顶后距离顶部的高度
          moveTopHeight: 0,
          // 是否由外部控制什么时候吸顶
          isExternalController: false,
        }
      }
    },
    // 是否开始吸顶,只有在 isExternalController 为true时候才生效
    isStartSuctionTop: {
      type: Boolean,
      default: false
    },
    // 容器上移suctionTop高度后吸顶
    suctionTop: {
      type: Number,
      default: 10
    },
    // 吸顶后距离顶部距离
    top: {
      type: Number,
      default: 60
    },
    // 右边容器距离左边的位置
    rightBoxToLeftDis: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      // 样式
      style: {
        position:'fixed',
        Left: 0
      },
      // 右侧盒子到右边距
      rightBoxToRight: 0,
      rightBoxToLeftDistance: 0
    }
  },
  mounted() {
    // 右边框到界面的右侧边距
    this.rightBoxToLeftDistance = this.rightBoxToLeftDis
    // console.log("this.rightBoxToLeftDistance = " + this.rightBoxToLeftDistance);

    // 如果初始就是吸顶 设置样式为 fixed
    if (this.suctionTop.isExternalController && this.isStartSuctionTop) {
      document.getElementById("id-right-box-top").style.position=this.style.position;
    }
  },
  components: {
    
  },
  methods: {
    getoffsetHeight() {
      // console.log("右侧高度 ： " + this.$refs.box.offsetHeight);
      return this.$refs.box.offsetHeight
    },
    // 参数1: 滚动条滚动的距离，通过父组件ref进行调用
    // 参数2: main-center-box 容器距离左边的距离
    scrollEvent(scroll,rightBoxToLeftDistance) {
      console.log("右侧盒子--------------");
      // 设置右边盒子距离右侧的边距
      this.rightBoxToLeftDistance = rightBoxToLeftDistance

       // 由外部进行控制吸顶
      if(this.suctionTop.isExternalController) {
        console.log("this.isStartSuctionTop = " + this.isStartSuctionTop);
        if(this.isStartSuctionTop) this.addStyle()
        else this.removeStyle()
        console.log("由外部进行控制吸顶");
        return
      }

      console.log("我是子组件 吸顶" + scroll);
      console.log("右侧盒子需要上移的高度(吸顶)= " + this.suctionTop);
      if(scroll > this.suctionTop) {
        this.addStyle()
      } else {
        this.removeStyle()
      }


      // 横向滚动条，滚动距离
      // console.log(maincenterBoxToLeft);
    },
    // 添加样式
    addStyle() {
      document.getElementById("id-right-box-top").style.position=this.style.position;
      document.getElementById("id-right-box-top").style.top=this.suctionTop.moveTopHeight + 'px';
    },

    // 移除样式
    removeStyle() {
      document.getElementById("id-right-box-top").style.position=null;
    },


    
  }
}
</script>

<style lang="less" scoped>
.right-box-top {
  // background-color: #fff;
}
</style>