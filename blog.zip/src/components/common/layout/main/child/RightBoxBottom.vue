<template>
  <div class="left-box-buttom" 
    id="id-left-box-buttom"
    ref="box" 
    :style="{width: width + 'px',transition: 'all .5s',top: 'auto',left: rightBoxToLeftDistance + 'px',bottom: '10px'}">
    <slot></slot>
  </div>
</template>

<script>
// 属于 Sh 表示scroll hegiht  滚动条高度
export default {
  props: {
   
    // 组件的宽度
    width: {
      type: Number,
      default: 200
    },
    // 距离顶部的高度
    topHeight: {
      type: Number,
      default: 70
    },
    // 右侧器距离左边的位置
    rightBoxToLeftDis: {
      type: Number,
      required: true
    }
   
  },
  data() {
    return {
      // 样式
      style: {
        position:'fixed'
      },
      // 获取可是界面的高度
      clientHeight: 0,
      //发生吸底后，滚动条的高度
      suctionBottomSh: 0,
    }
  },
  created() {
    // 获取可视界面的高度
    this.clientHeight = document.documentElement.clientHeight;
    // console.log("this.clientHeight = " + this.clientHeight);
  },
  mounted() {

    //  (当前组件的高度 + 组件距离顶部的距离 ) - 可视界面的高度 = 需要下滑多少距离然后吸底(suctionBottomSh)
    // 1. 获取当前组件的高度
    this.suctionBottomSh = (this.$refs.box.offsetHeight + this.topHeight - this.clientHeight ).toFixed(1)/1
    // console.log("滚条条需要滚动的高度(吸底)  " + this.suctionBottomSh);
  },
  methods: {
    // 参数1是滚动条滚动的距离，通过父组件ref进行调用
    // 参数2: main-center-box 容器距离左边的距离
    scrollEvent(scroll,rightBoxToLeftDistance) {
      // 设置右边盒子距离左侧的边距
      this.rightBoxToLeftDistance = rightBoxToLeftDistance

      // console.log("我是子组件 吸底   " + scroll + "this.suctionBottomSh  " + this.suctionBottomSh);
      // 吸底与吸顶
      if(scroll > this.suctionBottomSh) {
        this.addStyle()
      } else {
        this.removeStyle()
      }
      
    },
    // 添加样式
    addStyle() {
      document.getElementById("id-left-box-buttom").style.position=this.style.position;
      // document.getElementById("id-left-box-buttom").style.marginBottom=null;
    },

    // 移除样式
    removeStyle() {
      document.getElementById("id-left-box-buttom").style.position=null;
    },
  }
}
</script>

<style lang="less" scoped>
.left-box-buttom {
  // height: 100%;
}
</style>