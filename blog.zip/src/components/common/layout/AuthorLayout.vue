<template>
  <div class="author-layout">
    <!-- 个人页面 -->
    <div class="author-layout-left">
      <slot name="author-layout-left"> </slot>
    </div>
    <div class="author-layout-right">
      <slot name="author-layout-right"> </slot>
    </div>
    
  </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
.author-layout {
  display: flex;
  margin: 10px auto;
  width: 1200px;

  .author-layout-left {
    width: 900px;
    // margin: 0px 10px;
    margin-right: 10px;
  }

  .author-layout-right {
    flex: 1;  
  }
}
</style>