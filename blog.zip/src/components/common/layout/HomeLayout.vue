<template>
  <div class="home-layout">
    <!-- 主页布局 -->
    <div class="home-layout-left">
      <slot name="home-layout-left"> </slot>
    </div>
    <div class="home-layout-center">
      <slot name="home-layout-center"> </slot>
    </div>
    <div class="home-layout-right">
      <slot name="home-layout-right"> </slot>
    </div>
    
  </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
.home-layout {
  display: flex;
  margin: 10px auto;
  width: 1200px;

  .home-layout-left {
    width: 150px;
  }

  .home-layout-center {
    width: 780px;
    margin: 0px 10px;
  }

  .home-layout-right {
    flex: 1;
  }
}
</style>