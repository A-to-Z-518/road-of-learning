<template>
  <div class="search-layout" :style="{'marginTop': layoutMarginTop + 'px'}">
    <!-- 搜索布局 -->
    <div class="search-layout-left">
      <div class="search-layout-left-item" :style="{'top': leftTop + 'px'}">
        <slot name="search-layout-left"> </slot>
      </div>
    </div>
    <div class="search-layout-center">
      <slot name="search-layout-center"> </slot>
    </div>
    <div class="search-layout-right">
      <slot name="search-layout-right"> </slot>
    </div>
    
  </div>
</template>

<script>

export default {

  props: {
    leftTop: {
      type: Number,
      default: 70
    },
    // 布局距离顶部的距离
    layoutMarginTop: {
      type: Number,
      default: 70
    }
  }
}
</script>

<style lang="less" scoped>
.search-layout {
  display: flex;
  margin: 10px auto;
  width: 1200px;

  .search-layout-left {
    width: 110px;

    .search-layout-left-item {
      position: fixed;
      width: 110px;
      top: 10px;
    }
  }

  .search-layout-center {
    width: 810px;
    margin: 0px 10px;
    height: 1200px;
  }

  .search-layout-right {
    flex: 1;
    height: 1200px;
  }
}
</style>