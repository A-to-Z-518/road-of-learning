import Clipboard from 'clipboard'

/**
 * 
 * @param {*} This 使用该js文件的组件对象
 */
export function initClipboard(This) {
  This.$nextTick(() => {
    This.clipboard = new Clipboard('.copy-btn')
    // 复制成功失败的提示
    This.clipboard.on('success', (e) => {
      This.$message({
        message: "复制成功",
        center: true,
        offset: 70,
        customClass: 'message',
        type: 'success'
      })
      clipboard.destroy()
    })
    This.clipboard.on('error', (e) => {
      This.$message({
        message: "复制失败",
        center: true,
        offset: 70,
        customClass: 'message',
        type: 'error'
      })
      clipboard.destroy()
    })
  })
}


export function clipboardDestroy(This) {
  This.clipboard.destroy()
}