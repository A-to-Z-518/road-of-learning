// 引入默认样式,这个必须引入，否则行号都不好使以及样式都不可用，
// 且必须在引入自定义样式前
import 'highlight.js/scss/default.scss'
import 'highlight.js/styles/vs2015.css'


// 插件
// import MarkdownItColors from "markdown-it-colors"
// 下标
import MarkdownItSub from "markdown-it-sub"
// 上标
import MarkdownItSup from "markdown-it-sup"
// 高亮
import MarkdownItMark from "markdown-it-mark"

/**
 * 渲染markdown
 * @param {*} data 
 */
export function renderMd(data) {
  const MarkdownIt = require('markdown-it')
  const hljs = require('highlight.js')
  // 所有的选项列表（默认情况下）
  let md = new MarkdownIt({
    html:         true,        // 在源码中启用 HTML 标签
    // langPrefix:   'language-',  // 给围栏代码块的 CSS 语言前缀。对于额外的高亮代码非常有用。
    linkify:      true,        // 将类似 URL 的文本自动转换为链接。

    // 启用一些语言中立的替换 + 引号美化
    typographer:  true,


    // 高亮函数，会返回转义的 HTML。
    // 如果源字符串未更改，且应该进行外部的转义，或许返回 ''
    // 如果结果以 <pre ... 开头，内部包装器则会跳过。
    highlight: function (str, lang) {
      console.log("Markdown.vue 代码高亮");
      // 当前时间加随机数生成唯一的id标识
      const codeIndex = parseInt(Date.now()) + Math.floor(Math.random() * 10000000)
      // 复制功能主要使用的是 clipboard.js
      let copyHtml = `<div class="copy-btn"  data-clipboard-action="copy" data-clipboard-target="#copy${codeIndex}">复制</div>`
      // const linesLength = str.split(/\n/).length - 1
      // 生成行号
      // let linesNum = '<span aria-hidden="true" class="line-numbers-rows">'
      // for (let index = 0; index < linesLength; index++) {
      //   linesNum = linesNum + '<span></span>'
      // }
      // linesNum += '</span>'

      console.log(copyHtml);

      // 此处判断是否有添加代码语言
      if (lang && hljs.getLanguage(lang)) {
        try {
          // 得到经过highlight.js之后的html代码
          const preCode = hljs.highlight(lang, str, true).value
          // 以换行进行分割
          const lines = preCode.split(/\n/).slice(0, -1)
          // 添加自定义行号
          let html = lines.map((item, index) => {
            return '<li><span class="line-num" data-line="' + (index + 1) + '"></span>' + item + '</li>'
          }).join('')
          html = '<ol>' + html + '</ol>' + copyHtml
          // 添加代码语言
          if (lines.length) {
            html += '<b class="name">' + lang + '</b>'
          }
          return '<pre style="white-space: pre-wrap; white-space: -moz-pre-wrap; white-space: -pre-wrap;white-space: -o-pre-wrap; word-wrap: break-word;" class="hljs"><code id="copy' + codeIndex + '">' +
            html +
            '</code></pre>'
        } catch (__) {}
      }
      // 未添加代码语言，此处与上面同理
      const preCode = md.utils.escapeHtml(str)
      const lines = preCode.split(/\n/).slice(0, -1)
      let html = lines.map((item, index) => {
        return '<li><span class="line-num" data-line="' + (index + 1) + '"></span>' + item + '</li>'
      }).join('')
      html = '<ol>' + html + '</ol>' + copyHtml
      return '<pre style="white-space: pre-wrap; white-space: -moz-pre-wrap; white-space: -pre-wrap;white-space: -o-pre-wrap; word-wrap: break-word;" class="hljs"><code id="copy' + codeIndex + '">' +
        html +
        '</code></pre>'
      }
    }).use(MarkdownItMark)
      .use(MarkdownItSub)
      .use(MarkdownItSup)
      .use(require('markdown-it-footnote'));

  return md.render(`${data}`);
}