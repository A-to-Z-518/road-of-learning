<template>
<!-- 

  使用方法

  在组件中直接调用 <article-show-layout :article="article"></article-show-layout>
 -->
  <div class="article-show">
    <!-- 主页布局 -->
    <div class="article-show-left" ref="leftRef">
      <div class="article-show-left-item" :style="{'left': leftStyle.left}">
        <!-- 中间头部 -->
        <slot name="left"></slot>
      </div>
    </div>
    <div class="article-show-center">
      <div class="article-show-center-item">
        <!-- 中间头部 -->
        <slot name="center-header"></slot>

        <div ref="articleContentRef" class="markdown-write-body" v-html="md">
        </div>

        <slot name="center-bottom"></slot>
      </div>
    </div>
    <!-- 必须在设置fixed div外层套一层div并设置宽度 -->
    <div style="width: 230px;" ref="rightTocRef"> 
      <div  class="article-show-right right"  id="article-show-right-id"
        :style="{'height': clientHeight,'left': rightStyle.left,top: tocTop + 'px',transition: 'all .2s',position: tocPosition}">
        <div class="toc" id="toc-id" ref="tocRef" :style="{}">
          <span class="mu-lu-title">目录</span>
          <ul v-for="(item,index) in tocH" :key="index">
            <el-tooltip class="item" effect="light" :content="item.text" placement="left-start" open-delay="500">
              <li data-attr="0">
                <a href="javascript:void(0);" 
                  :class="{'activeToc': currrentActiveIndex == index}" 
                  :style="{'marginLeft': item.styleMarginLeft}" 
                  @click="goH(item.id,index)">{{item.text}}</a>
              </li>
            </el-tooltip>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>


import {initClipboard,clipboardDestroy} from "./clipboard"
import {renderMd} from "./markdown-it"

// 引入 用于生成目录
import Catalog from 'progress-catalog'
import 'progress-catalog/src/progress-catalog.css'

export default {
  components: {
  },
  props: {
    // 要展示的文章
    article: {
      type: String,
      default: ""
    },
    // 目录吸顶距离
    tocTop: {
      type: Number,
      default: 70
    }
  },
  data() {
    return {
      tocPosition:"static",
      md: "",
      currrentActiveIndex: -1,
      clientHeight: "200px",
      tocHeight: "",
      rightStyle: {
        left: "0px"
      },
      leftStyle: {
        left: "0px"
      },
      tocH: []
    }
  },
  watch: {
    article: function(val) {
      this.$nextTick(() => {
        // 将markdown转为html
        this.md = renderMd(val)
        this.$nextTick(() => {
          console.log("开始构建目录");
          this.handleNavTree()
        })
      })
    }
  },
  destroyed () {//离开该页面需要移除这个监听的事件
    window.removeEventListener('scroll', this.handleScroll)
    clipboardDestroy(this)
  },

  mounted() {
    // 获取fixed外出div距离左侧距离
    this.rightStyle.left = this.$refs.rightTocRef.getBoundingClientRect().left.toFixed(1)/1 + "px"
    this.leftStyle.left = this.$refs.leftRef.getBoundingClientRect().left.toFixed(1)/1 + "px"
    // 初始化代码服务按钮
    initClipboard(this)

    window.addEventListener('scroll', this.handleScroll,false);

    // 获取可视页面的高度
    this.clientHeight = (document.documentElement.clientHeight) - 20 + "px";
    
  },
  methods: {
    // 为h标签添加id


    // 生成目录树
    handleNavTree() {
      
      console.log("构建目录");
      let hList = this.$refs.articleContentRef.querySelectorAll('h1,h2,h3,h4')
      console.log(hList);

      hList.forEach((value,index) => {
        // 为标签添加id属性
        value.setAttribute("id",index);

        let toc = {
          text: '',
          localName: '',
          id: '',
          styleMarginLeft: '1em'
        }
        // 获取标签名
        toc.localName = value.localName
        // 标签值
        toc.text = value.innerText
        // 标签id
        toc.id = index

        if (toc.localName == "h1") toc.styleMarginLeft = "0em"
        else if (toc.localName == "h2") toc.styleMarginLeft = "1em"
        else if (toc.localName == "h3") toc.styleMarginLeft = "2em"
        else if (toc.localName == "h4") toc.styleMarginLeft = "3em"
        else if (toc.localName == "h5") toc.styleMarginLeft = "4em"
        this.tocH.push(toc)
        
        
        this.tocPosition = "fixed"
      });

    },
    /**
     * 跳转标题
     */
    goH(id,index) {
      this.currrentActiveIndex = index
      document.getElementById(id).scrollIntoView()
      console.log(id);
      console.log(index);
    },

    handleScroll(scroll) {
      this.rightStyle.left = this.$refs.rightTocRef.getBoundingClientRect().left.toFixed(1)/1 + "px"
      this.leftStyle.left = this.$refs.leftRef.getBoundingClientRect().left.toFixed(1)/1 + "px"
    }
  }
}
</script>

<style lang="less">

// ====================== 以下是markdown样式

@import '~@/assets/css/github-markdown.css';

.markdown-write-body {
  box-sizing: border-box;
  min-width: 200px;
  max-width: 980px;
  margin: 0 auto;
  padding: 10px;
  
}

@media (max-width: 767px) {
  .markdown-write-body {
    padding: 15px;
  }
}


pre {
  height: 100% !important;
}

// 添加行号样式
pre.hljs {
  padding: 8px 2px;
  border-radius: 5px !important;
  position: relative;
  font-size: 14px !important;
  line-height: 22px !important;
  overflow-x:scroll !important;
  word-break: normal !important;
  ol {
    list-style: decimal;
    margin: 0;
    margin-left: 40px;
    padding: 0;
    li {
      list-style: decimal-leading-zero;
      position: relative;
      padding-left: 10px;
      .line-num {
        position: absolute;
        left: -40px;
        top: 0;
        width: 40px;
        height: 100%;
        border-right: 1px solid rgba(0, 0, 0, .66);
      }
    }
  }
  .line-numbers-rows {
    position: absolute;
    pointer-events: none;
    top: 12px;
    bottom: 12px;
    left: 0;
    font-size: 100%;
    width: 40px;
    text-align: center;
    letter-spacing: -1px;
    border-right: 1px solid rgba(0, 0, 0, .66);
    user-select: none;
    counter-reset: linenumber;
    span {
      pointer-events: none;
      display: block;
      counter-increment: linenumber;
      &:before {
        content: counter(linenumber);
        color: #999;
        display: block;
        text-align: center;
      }
    } 
  }

  b.name {
    position: absolute;
    top: 8px;
    right: 60px;
    z-index: 10;
    color: #999;
    pointer-events: none;
  }
  .copy-btn {
    position: absolute;
    border-radius: 3px !important;
    top: 3px;
    right: 4px;
    z-index: 10;
    color: #777;
    cursor: pointer;
    background-color: #fff;
    border: 0;
    border-radius: 2px;
  }
}



// ====================== 以上是markdown样式
.mu-lu-title {
  display: block;
  text-align: center;
  height: 20px;
  line-height:20px;
  font-weight: bold;
}

.toc ul li ,
.toc ul {
  padding-left: 5px;
  padding-top: 2px;
  margin: 0px;
  // 去掉点
  list-style: none;
}

.toc a {
  text-decoration: none;
}


.activeToc {
  color: #00bcd4;;
}

.toc a{
  overflow : hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 1;      /* 可以显示的行数，超出部分用...表示*/
  -webkit-box-orient: vertical;
}


.article-show {
  display: flex;
  margin: 10px auto;
  margin-top: 70px;
  width: 1200px;
  // overflow: scroll;

  .article-show-left {
    width: 150px;
    height: 100px;
    // background-color: #fff;
    
    .article-show-left-item {
      position: fixed;
      width: 150px;
      top: 10px;
    }
  }

  .article-show-center {
    width: 800px;
    // min-height: 50px;
    padding: 0px auto;
    // background-color:#ffffff;
    border-radius: 0.4em;
    margin-left: 10px;
    margin-bottom: 50px;
  }

  
}

.article-show-center-item {
  background-color: #fff;
}
/*定义滚动条高宽及背景 高宽分别对应横竖滚动条的尺寸*/  
*::-webkit-scrollbar {
  /*滚动条整体样式*/
  width: 8px;/*定义纵向滚动条宽度*/
  height: 8px;/*定义横向滚动条高度*/
}
/*定义滑块 内阴影+圆角*/  
*::-webkit-scrollbar-thumb {
  /*滚动条内部滑块*/
  border-radius: 8px;
  background-color: hsla(220, 4%, 58%, 0.3);
  transition: background-color 0.3s;
}

*::-webkit-scrollbar-thumb:hover {
  /*鼠标悬停滚动条内部滑块*/
  background: #bbb;
}

/*定义滚动条轨道 内阴影+圆角*/  
*::-webkit-scrollbar-track {
  /*滚动条内部轨道*/
  background: #ededed;
}

.article-show-right {
  // border:0.01rem solid black;
  width: 210px;
  // height: 500px;
  overflow: hidden;
  margin-left: 10px;
  // position:fixed;  
  top: 70px;
  // background-color: red !important;

  .toc {
    width: 230px;
    // overflow-y: auto;
    overflow-y: auto;
    overflow-x: hidden;
    height:100%;
    // background-color:pink;
    box-sizing: border-box;
    padding-bottom: 10px;
    
  }
  
}

</style>