<template>
<!-- 滚动监听组件，将需要监听的包裹起来 -->
  <div id="scrollBar">
    <slot></slot>
  </div>
</template>

<script>
export default {
  data() {
    return {
      i: 0,
      scrollBarDom: {}
    }
  },
  mounted() {
    this.scrollBarDom = document.getElementById('scrollBar');
    window.addEventListener('scroll', this.handleScroll,false);
    // window.addEventListener('scroll', this.handleScroll);
  },
  methods: {
    //滚动监听，头部固定
    handleScroll: function () {
      // 纵向滚动条
      let scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
      // 横向滚动条
      let scrollX = 0;
      // console.log("window.pageXOffset = " + window.pageXOffset);
      // 滚动条滑动事件
      this.$emit("scroll-event",scrollTop )
      this.i = scrollTop
    }
  },
  destroyed () {//离开该页面需要移除这个监听的事件
    window.removeEventListener('scroll', this.handleScroll)
  },
}
</script>

<style>

</style>