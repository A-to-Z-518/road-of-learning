<template>
<me-scroll-loading class="article-item article-list" :isLoading="false" :scollEnd="scollEnd" color="#d9adad" @onload="onload"> 
  <ul >
    <li v-for="(item,index) in articleList" :key="item.id" 
      :style="{marginBottom: articelSpacing + 'px'}">
      <div class="article" >
        <!-- 展示文章列表 -->
        <div class="article-center-right" :class="{'is-image': item.imageUrl !== null}">
          <router-link :to="`/article/details/` + item.id"  target="_blank" @click.native="showArticle">{{item.title}}</router-link>
          <div class="content ">
            <div class="twoline">{{item.contentText}}</div>
            <div class="article-bottom" >
              <!-- 头像 -->
              <avatar :url="item.userAvatar"></avatar>
              <!-- 用户昵称 -->
              <span><a href="#">{{item.usernick}}</a></span>
              <!-- 创建时间 -->
              <span>{{item.createTime | dateFilter}}</span>

              <!-- 点赞数量 -->
              <span class="article-bottom-right-item">点赞 {{item.likeCount}}</span>
              <!-- 访问量 -->
              <span class="article-bottom-right-item">浏览 {{item.viewCount}}</span>
            </div>
          </div>
        </div>
        
        <!-- 展示文章配图 -->
        <div v-if="item.imageUrl !== null && isImage && item.imageUrl !== '' ? true:false" 
            class="article-image">
          <img :src="item.imageUrl" alt="">
        </div>
      </div>
      <!-- 分割线 -->
      <divided v-if="isDivided && (index !== articleList.length -1)"></divided>
      
    </li>
  </ul>
  
    
  
</me-scroll-loading>
</template>

<script>
import MeScrollLoading from "@/components/common/loading/MeScrollLoading.vue"
import Avatar from "@/components/common/avatar/Avatar"
import Divided from "@/components/common/divided/Divided"
import {findAllArticleByPage} from "@/api/article.js"

export default {
  components: {
    Avatar,Divided,MeScrollLoading
  },
  props: {
    // 是否需要文章图片
    isImage: {
      type: Boolean,
      default: true
    },
    // 是否需要分割线
    isDivided: {
      type: Boolean,
      default: true
    },
    // 如果没有分割线则，两个文章div容器之间的距离
    articelSpacing: {
      type: String,
      default: "10"
    },
    // 是否滚动到底部
    scollEnd: {
      type: Boolean,
      default: false
    },
    // 第几页
    pageNum: {
      type: Number,
      default: 1
    },
    articleList: {
      type: Object,
      default: function() {
        return [
          {
            id: "1263012551591985152",
            title:"标题12313",
            contentText: " 摘要：针对于List的size比较大，使用多线程处理任务时，可以将List分割为一个一个比较小的任务单元进行处理。 例如集合大小：645，按照100分割，会将集合分割为6个size为100的集合和一个size为45的集合，方便配合多线程处理。 实现代码如下： 输出结果：",
            createTime: "2020-06-01",
            likes: 12312,
            views: 12312,
            usernick: "光阳",
            userAvatar: "https://s1.ax1x.com/2020/06/01/t87aeU.png",
            imageUrl: ""
          },
        ]
      }
    }
  },
  data() {
    return {
     
    }
  },
  created() {
    // this.findAllArticleByPage(this.pageNum)
  },
  data() {
    return {
      
    }
  },
  methods: {
    /**
     * 请求后台数据
     */
    onload() {
      console.log("获取数据");
      this.$emit("onload")
    },

    
    /**
     * 展示文章事件
     */
    showArticle() {
      console.log("跳转路由");
      
      this.$emit("show-article")
    },
    // 当前页
    handleCurrentChange(num) {

    },

  }
}
</script>

<style lang="less" scoped>
a {
  text-decoration: none;
}
ul li ,
ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}

li{
  list-style: none;
  line-height: 2rem;
  color: black;
  transition: background-color 0.5s linear,color 0.51s linear;
  -webkit-transition: background-color 0.5s linear,color 0.51s linear;
  -moz-transition: background-color 0.5s linear,color 0.5s linear;
  -o-transition: background-color 0.5s linear,color 0.5s linear;		
}
li:hover{
  background-color: #dddddd;
  color: #dddddd;
}


// 未访问链接 ,如 a:link {color:blue}
a:link {
  color: #404040;
}
// a:hover： 鼠标移到链接上时 ,如 a:hover {color:blue}
.article-item a:hover {
  color: #2D8CF0;
}
// 激活时(链接获得焦点时)链接的颜色 ,如 a:active{color:blue}
a:active {
  color: #2D8CF0;
}
//  已访问链接
a:visited {
  color: #404040;
}

.article-item {
  cursor: pointer;
}



.article {
  display: flex;
  // 对里面子元素添加样式，其中 justify-content: space-between; 这行能够起到左右对齐方式。
  justify-content: space-between;
  width: 800px;
  padding: 0px;
  height: 120px;
  margin: 10px auto;
}






.page {
  display: flex;
  margin: 10px auto;
  justify-content: center;
  margin-bottom: 50px;
}


.article-item a {
  // 去掉a标签的下划线
  text-decoration: none;
  padding-left: 5px;
  font-size: 20px;
  font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif
}

.article-center-right {
  padding-right: 0px;
}

.is-image {
  width: 615px;
}



// 文章内容
.content {
  display: flex;
  flex-wrap: wrap;
  padding-top: 5px;
  padding-left: 5px;
  font-size: 16px;
  font-weight: 300;
  font-family: inherit;
  line-height: 1.5em;
  color: #666;
  // background-color: pink;
}

.article-image ,
.article-image img{
  padding: auto 0px;
  width: 160px;
  height: 120px;
  margin-top: 0.18rem;
}




span {
  display: block;
  // width: 800px;
}

// 文章item底部
.article-bottom {
  display: flex;
  width: 800px;
  align-items: center;
  padding-top: 15px;
  font-size: 14px;
  color: #738a94;
}


.article-bottom span ,
.article-bottom span a{
  display: block;
  margin: auto 5px;
  font-size: 14px;
  cursor: pointer;
  font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif
}



.content .twoline{
  // display:block;
  // white-space: nowrap;
  max-width: 795px !important;
  
  // background-color: red;
  overflow : hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2 ;      /* 可以显示的行数，超出部分用...表示*/
  -webkit-box-orient: vertical;
}
</style>