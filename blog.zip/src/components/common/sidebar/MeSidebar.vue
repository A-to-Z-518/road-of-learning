<template>
  <div class="me-uc-sidebar">
    <el-divider class="me-divider"></el-divider>
    <div class="title font"><span class="font">{{options.title}}</span></div>
    <div >
      <div class="me-item" v-for="(item,index) in options.list" :key="index">
        <svg-icon icon-class="person" class="me-svg"></svg-icon>
        <router-link class="me-link" :to="item.to">
          {{item.name}}
        </router-link>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  props: {
    // options: {
    //    title: "标题",
    //    list: [{to: "",name: "标签管理"}]
    //  }
    options: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
    }
  }
}
</script>

<style lang="less" scoped>
@import "@/assets/less/font.less";

.me-uc-sidebar {
  padding: 15px;
  background-color: #ffffff;
}
.me-svg {
  padding-right: 5px;
  color: rgba(0,0,0,0.5);
}

a {
  // 去掉a标签的下划线
  text-decoration: none;
}


ul li {
  list-style: none;
  padding-bottom: 20px;
  
}


.me-link {
  color: rgba(0,0,0,0.5);
  font-size: 14px;
}
ul {
  padding: 0;
  margin: 0;
}
.me-divider {
  margin-bottom: 20px;
  margin-top: 0px;
}

// 鼠标移动在item上后变色
.me-item:hover a,
.me-item:hover .me-svg {
  color: #1a1a2e;
}


.me-item {
  padding-top: 20px;
  cursor: pointer;
}
</style>