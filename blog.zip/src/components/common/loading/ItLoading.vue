<template>
  <div class="it-loading" :class="{'it-loading-pointer': isLoading}">
    <transition name="loading">
      <div v-if="isLoading" class="transition">
        <div class="overlay"></div>
        <vue-loading type="spiningDubbles" color="#d9544e" :size="{ width: '50px', height: '50px' }" class="vue-loading">
        </vue-loading> 
      </div>
    </transition>
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'ItLoading',
  props: {
    isLoading: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<style lang="less" scoped>

.transition {
  
}

.overlay {
	position: absolute;
	width: 100%;
  height: 100%;
  
	top: 0;
	left: 0;
	z-index: 100;
  // opacity: 0;
  pointer-events: none;
  background: rgba(255, 255, 255, 0.6);
}

.it-loading {
  cursor: pointer;
  position: absolute;
}

.it-loading-pointer {
  pointer-events: none;
}
.vue-loading {
  position: absolute;
  cursor: pointer;
  top: 50%;
  left: 50%;
  z-index: 2000;
  -webkit-transform: translateX(-50%) translateY(-50%);
	-moz-transform: translateX(-50%) translateY(-50%);
	-ms-transform: translateX(-50%) translateY(-50%);
  transform: translateX(-50%) translateY(-50%);
}


//css
.loading-enter-active{//loading 是过渡名称 in,out是两个动画，动画写到进入和离开结束的class中
  animation:in 1s;
  -moz-animation: in 1s;	/* Firefox */
  -webkit-animation: in 1s;	/* Safari 和 Chrome */
  -o-animation: in 1s;	/* Opera */
}
.loading-leave-active{
  animation:out 1s;
  -moz-animation: out 1s;	/* Firefox */
  -webkit-animation: out 1s;	/* Safari 和 Chrome */
  -o-animation: out 1s;	/* Opera */
}
@keyframes  in {//in动画
  0% {
    // 初始透明度为 0
    opactity:0; 
  }
  50% {
    opactity:0.5;
  }
  100% {
    opactity:1;
  }
}
@keyframes  out {//out 动画
  0% {
    opactity:1;
  }
  50% {
    opactity:0.5;
  }
  100% {
    opactity:0; 
  }
}

</style>