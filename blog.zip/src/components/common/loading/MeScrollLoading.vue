<template>
  <!-- 滚动加载组件 -->
  <div id="wrap">
    <slot></slot>
    <div class="scroll-txt" :style="{color: color}" v-if="!scollEnd">加载中</div>
    <div class="scroll-txt" :style="{color: color}" v-if="scollEnd">没有更多数据啦！</div>
  </div>
</template>
 
<script>
export default {
  name: "MeScrollLoading",
  props: {
    // 是否需要滚动加载，如果为false，则滚动到底部时候，不会向上抛出事件 onload
    isLoading: {
      type: Boolean,
      default: false
    },
    // 是否滚动到底部
    scollEnd: {
      type: Boolean,
      default: false
    },
    // 底部文字颜色
    color: {
      type: String,
      default: "#fff"
    }
  },
 
  data() {
    return {
      time: "",
      firstTime: true
    };
  },
  mounted() {
    const time = new Date().getTime();
    this.time = time;
    window.addEventListener("scroll", this.scrollFn,false);
  },
  beforeDestroy() {
    window.removeEventListener("scroll", this.scrollFn);
  },
  methods: {
    scrollFn() {
      if (!this.scollEnd) {
       
        if (
          document.querySelector("#wrap").offsetHeight -
            window.pageYOffset -
            window.screen.height < 100
        ) {
          let curTime = Date.parse(new Date());
          if (curTime - this.time >= 1000 || this.firstTime) {
            // 时间差>=1秒直接执行
            this.firstTime = false;
            !this.isLoading && this.handle();
            // this.handle();
            this.time = curTime;
          }
        }
      }
      
    },
    handle() {
      console.log("滚动到底部了");
      this.$emit("onload");
    }
  }
};
</script>
<style lang="less" scoped>
.scroll-txt {
  text-align: center;
  padding: 10px;
  // color: #ec0101;
}
</style>