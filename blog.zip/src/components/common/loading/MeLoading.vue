<template>
<!-- 加载中组件 -->
  <div class="loader">
    <slot></slot>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="css" scoped>
.loader {
  opacity: 0.5;
  cursor: default;
  pointer-events: none;
}

.loader:before {
  content: '';
  z-index: 9999px;
  display: inline-block;  
  width: 2em;
  height: 2em;
  margin: 0px auto;
  color: red;
  border: 3px solid red;
  border-radius: 50%;
  vertical-align: -10%;
  clip-path: polygon(0% 0%, 100% 0%, 100% 30%, 0% 30%);
  animation: rotate 1s linear infinite;
}

@keyframes rotate {
  from {
    transform: rotatez(0deg);
  }

  to {
    transform: rotatez(360deg);
  }
}
</style>