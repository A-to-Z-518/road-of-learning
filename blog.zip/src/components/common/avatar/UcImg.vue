<template>
  <div>
    <div class="uc-img" @mouseenter="display = 'block'" @mouseleave="display = 'none'">
      <img :src="imgLink" alt="">
      <span class="show img-tip semi-circle" :style="{'display': display}" @click="uploadImageVisible = true">{{tip}}</span>
    </div>
    <el-dialog
      :title="tip"
      :visible.sync="uploadImageVisible"
      width="30%"
      :before-close="handleClose">
      <el-upload
        style="margin: 0px 25px"
        class="upload-demo"
        :http-request="upLoad"
        :on-preview="handlePreview"
        :on-remove="handleRemove"
        :before-remove="beforeRemove"
        :on-change="onChange"
        :before-upload="beforeUpload"
        :limit="1"
        drag
        action="https://jsonplaceholder.typicode.com/posts/">
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
        <div class="el-upload__tip" slot="tip">只能上传jpg/png文件，且不超过500kb</div>
      </el-upload>
      <span slot="footer" class="dialog-footer">
        <el-button @click="uploadImageVisible = false">取 消</el-button>
        <el-button type="primary" @click="uploadImageVisible = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
// 上传文件的api
import {uploadOneImage} from "@/api/upload"
export default {
  props: {
    tip: {
      type: String,
      default: '上传图片'
    },
    imgLink: {
      type: String,
      default: ''
    },
  },
  data() {
    return {
      imageLike: '',
      display: 'none',
      // 上传图片面板
      uploadImageVisible: false
    }
  },
  methods: {
    onChange(file, fileList) {
      // this.$refs.upload.clearFiles()
    },
    beforeUpload(file) {
      this.$emit("beforeUpload",file)
    },
    handleExceed(files, fileList) {
      this.$message.warning(`请先移除已选中的图片，再上传`);
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${ file.name }？`);
    },
    handleClose() {
      this.uploadImageVisible = false
    },
    // 上传图片
    upLoad(file) {
      const formData = new FormData();
      formData.append('file', file.file);
      console.log(file);
      console.log(formData);
      uploadOneImage(formData).then((res) => {
        console.log(res);

        if (res.code === 200) {
          console.log('上传成功');
          this.$message({
            message: res.msg,
            center: true,
            offset: 70,
            customClass: 'message',
            type: 'success'
          })
        } else {
          this.$message({
            message: res.msg,
            center: true,
            offset: 70,
            customClass: 'message',
            type: 'error'
          })
        }
        this.$emit("handleSuccess",res.data)
      });
    }
  }
}
</script>

<style lang="less" scoped>
.uc-img,
.uc-img img {
  width: 60px;
  height: 60px;
  border-radius: 50%;
}

.uc-img {
  position:relative;
  z-index:10;
  margin:0 auto; 
  cursor: pointer;
  margin-right: 20px;
}


// 画半圆
.semi-circle {
  position:absolute;
  top:50%;
  width: 60px;
  height: 30px;
  background-color:rgba(255, 255, 255, 0.7);
  border-radius:0 0 50px 50px; /* 左上、右上、右下、左下 */
}

.img-tip {
  width:100%;
  position:absolute;
  z-index:20;
  top:50%; 
  text-align:center;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
}
</style>