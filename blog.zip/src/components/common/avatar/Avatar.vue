<template>
  <div>
    <img class="circleImg" :src="url" :style="{width: width,height: height}"/>
  </div>
</template>

<script>
export default {
  props: {
    // 头像链接
    url: {
      type: String,
      default: ""
    },
    width: {
      type: String,
      default: "24px"
    },
    height: {
      type: String,
      default: "24px"
    },
  }
}
</script>

<style lang="less" scoped>
.circleImg{
  border-radius: 50%;
  object-fit: cover;
  overflow: hidden;
  display: block;
}
</style>