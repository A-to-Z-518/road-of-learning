<template>
<!-- 弹出的顶层盒子，比如点击一个按钮弹出登录面板 -->
  <div  >
    
    <div class="md-modal md-effect-1" :class="{'md-show': !isHide}">
      <div class="md-content">
        <div class="lrb-header">
          <div class="clone" @click="hideClike" >✘</div>
            <span class="title">{{title}}</span>
        </div>
        <div :class="{'line': whetherShowLine}"></div>
        <div class="lr"><slot></slot></div>
      </div>
    </div>
    <div class="md-overlay"></div>
  </div>
</template>

<script>
export default {
  
  props: {
    // 是否展示线
    whetherShowLine: {
      type: Boolean,
      default: true
    },
    title: {
      type: String,
      default: '登录与注册'
    },
    isHide: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      hide: true
    }
  },
  watch: {
   isHide: function() {
     console.log("=====================================");
     this.hide = this.isHide
   } 
  },
  methods: {
    hideClike() {
      console.log("==============");
      this.$emit('clone')
    }
  }
}
</script>

<style lang="less" scoped>
.hide{
  display: none;
}

.md-overlay {
	position: fixed;
	width: 100%;
	height: 100%;
	visibility: hidden;
	top: 0;
	left: 0;
	z-index: 100;
	opacity: 0;
	background: rgba(128, 126, 125, 0.3);
	-webkit-transition: all 0.3s;
	-moz-transition: all 0.3s;
	transition: all 0.3s;
}

.md-effect-1 .md-content {
	-webkit-transform: scale(0.7);
	-moz-transform: scale(0.7);
	-ms-transform: scale(0.7);
	transform: scale(0.7);
	opacity: 0;
	-webkit-transition: all 0.3s;
	-moz-transition: all 0.3s;
	transition: all 0.3s;
}

.md-modal {
	position: fixed;
	top: 50%;
	left: 50%;
	width: 50%;
	max-width: 450px;
  min-width: 300px;
	height: auto;
	z-index: 110;
	visibility: hidden;
	-webkit-backface-visibility: hidden;
	-moz-backface-visibility: hidden;
	backface-visibility: hidden;
	-webkit-transform: translateX(-50%) translateY(-50%);
	-moz-transform: translateX(-50%) translateY(-50%);
	-ms-transform: translateX(-50%) translateY(-50%);
  transform: translateX(-50%) translateY(-50%);
}
.md-show {
	visibility: visible;
}
.md-show ~ .md-overlay {
	opacity: 1;
	visibility: visible;
}

.md-show.md-effect-1 .md-content {
	-webkit-transform: scale(1);
	-moz-transform: scale(1);
	-ms-transform: scale(1);
	transform: scale(1);
	opacity: 1;
}

.md-content {
  background-color: #fff;
  border-radius: 1rem;
}

.lrb-header {
  display: flex;
  flex-direction: row-reverse;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  height: 40px;
  margin: 0px 10px;
  // background-color: pink;

}

.clone {
  cursor: pointer;
  width: 20px;
  height: 40px;
  line-height: 40px;
  font-size: 28px;
  margin-right: 20px;
}

.title {
  line-height: 40px;
  font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
  font-size: 20px;
  color: #000000;
}

.lr {
  padding: 10px;
}

.line {
  height: 1px;
  margin: 5px 10px;
  border: none;
  background: rgba(255, 255, 255, 0.6);
  border-top: solid #ACC0D8 0.95px;
}
</style>