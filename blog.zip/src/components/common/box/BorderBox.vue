<template>
<!-- 
  这是一个带有标题的面板，标题左侧有边框
 -->
  <div>
    <!-- 标题 -->
    <span v-if="isActiveTitle" class="title">{{title}}</span>
    <!-- 数据 -->
    <div>
      <slot> 
        <h2>你可以插入数据</h2>
      </slot>
    </div>
  </div>
</template>

<script>

export default {
  props: {
    title: {
      type: String
    },
    // 是否激活标题
    isActiveTitle: {
      type: Boolean,
      default: true
    }
  }
}
</script>

<style lang="less" scoped>
// 文章列表右侧部分 标题栏
.title {
  padding-left: 10px;
  font-weight: 549;
  color: #3f3f44;
  border-left: 4px solid #66B1FF;
}
</style>