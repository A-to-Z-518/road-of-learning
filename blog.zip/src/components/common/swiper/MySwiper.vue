<template>
  <div>
    <swiper v-if="this.bannerList != null && this.bannerList.length > 0" ref="mySwiper" class="swiper" :options="swiperOptions">
      <swiper-slide v-for="(item,index) in bannerList" :key="index">
        <div>
          <img :src="item.imageUrl" alt="">
        </div>
      </swiper-slide>
      <div class="swiper-pagination" slot="pagination"></div>
      <div class="swiper-button-prev" slot="button-prev"></div>
      <div class="swiper-button-next" slot="button-next"></div>
    </swiper>
  </div>
</template>

<script>
import { Swiper, SwiperSlide } from 'vue-awesome-swiper'
import 'swiper/css/swiper.css'

export default {
  name: 'swiper-example-autoplay',
  title: 'Autoplay',
  components: {
    Swiper,
    SwiperSlide
  },
  props: {
    bannerList: {
      type: Array,
    }
  },
  data() {
    return {
      // 轮播图配置
      swiperOptions: {
        initialSlide :0,
        observeParents:true,
        observer:true,
        loop: true,
        speed: 900,
        autoplay: {
          delay: 2500,
          disableOnInteraction: false
        },
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      }
    }
  },
  computed: {
    swiper() {
      if (this.bannerList != null && this.bannerList.length > 0) return this.$refs.mySwiper.$swiper
      return ""
    }
  },
  mounted() {
    // this.swiper.init()
    console.log('Current Swiper instance object', this.swiper)
  }
}
</script>

<style lang="scss" scoped>
.swiper {
  height: 400px;
  width: 100%;
  margin-bottom: 20px;

  .swiper-slide {
    height: 400px;
    background-color: #ffffff;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    font-weight: bold;
  }
}

.swiper-slide img ,
.swiper-slide div{
  width: 100%;
  height: 400px;
}

</style>