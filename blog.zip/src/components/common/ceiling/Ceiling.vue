<template>
<!-- 吸顶组件 -->
<div 
  class="pride_tab_fixed" 
  ref="pride_tab_fixed"
  :style="{backgroundColor: backgroundColor}">
  <div 
    class="w" 
    :class="titleFixed == true ? 'isFixed' :''"
    :style="{top: top + 'px',width: centerWidth + 'px',backgroundColor: backgroundColor}"
  >
    <slot>无数据</slot>
  </div>
  <!-- 用于显示吸顶后的底层颜色，因为position: fixed; 脱离了文档流， -->
  <!-- 当吸顶的时候，该div就会显示，也是position: fixed; 宽度为100%,背景色是白色 -->
  <div class="pride_tab_fixed_bottom"
   :class="titleFixed == true ? 'isFixedBottom' :''"
   :style="{top: top + 'px',backgroundColor: backgroundColor}"
  > </div>
</div>

</template>

<script>

export default {
  props: {
    // 吸顶位置，0表示在可视区的最顶端
    top: {
      type: Number,
      default: 0
    },
    // 中间的宽度，相对页面是居中的宽度
    centerWidth:  {
      type: Number,
      default: 1200
    },
    // 背景颜色
    backgroundColor: {
      type: String, 
      default: "#ffffff"
    }
  },
  data() {
    return {
      titleFixed: false,
      i: 0,
    }
  },
  mounted() {
    this.titleFixed = false;

    this.IntersectionObserverFun()
  },
  methods: {
    // 吸顶优化方案
    IntersectionObserverFun: function() {
      let _ = require('lodash');
      let self = this;
      let ele = self.$refs.pride_tab_fixed;
      if( !IntersectionObserver ){
        let observer = new IntersectionObserver(function(){
            let offsetTop = ele.getBoundingClientRect().top;
            self.titleFixed = offsetTop < 0;
        }, {
            threshold: [1]
        });
        // 父元素的类名
        observer.observe(document.getElementsByClassName('pride_tab_fixed')[0]);
      } else {
        window.addEventListener('scroll', _.throttle(function(){
            let offsetTop = ele.getBoundingClientRect().top;

            if (this.i - offsetTop < 0 ) {
              console.log("向上滚动");
              self.titleFixed = false
            } else {
              console.log("向下滚动");
              self.titleFixed = true
            }
            this.i = offsetTop
            
            // self.titleFixed = offsetTop < 0;
        }, 50));
      }
    }

  }
}
</script>

<style lang="less" scoped>

// 主干部分
.w {
  // 如果想要块级元素水平居中，需要满足两点
  //  1. 设置宽度
  //  2. 左右外边距设置成 auto
  width: 1200px;
  // 上下为0 左右居中
  margin: 0 auto;
}


.pride_tab_fixed {
  display: flex;
  width: 100%;
  min-width: 1200px;
  margin-top: 2px;
}
.isFixed ,
.isFixedBottom{
  position: fixed;
  // 吸顶位置，0表示在可视区的最顶端
  top: 0px;
  margin:0 auto;
  left:0;
  right:0;
  width: 1200px;
  z-index: 9999;
}

.isFixedBottom {
  left:0;
  right:0;
  width: 100%;
  z-index: 9000;
}


.pride_tab_fixed_bottom {
  height: 50px;
  line-height: 50px;
  background-color: #ffffff;
}

</style>