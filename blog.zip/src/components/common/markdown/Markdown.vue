<template>
  <article class="markdown-write-body" v-html="md" ref="article" ></article>
</template>

<script>
import Clipboard from 'clipboard'


// 引入默认样式,这个必须引入，否则行号都不好使以及样式都不可用，
// 且必须在引入自定义样式前
import 'highlight.js/scss/default.scss'
import 'highlight.js/styles/vs2015.css'


// 插件
// import MarkdownItColors from "markdown-it-colors"
// 下标
import MarkdownItSub from "markdown-it-sub"
// 上标
import MarkdownItSup from "markdown-it-sup"
// 高亮
import MarkdownItMark from "markdown-it-mark"

export default {
  data() {
    return {
      md: ''
    }
  },


  mounted() {

    this.$nextTick(() => {
      this.clipboard = new Clipboard('.copy-btn')
      // 复制成功失败的提示
      this.clipboard.on('success', (e) => {
        this.$message({
          message: "复制成功",
          center: true,
          offset: 70,
          customClass: 'message',
          type: 'success'
        })
        clipboard.destroy()
      })
      this.clipboard.on('error', (e) => {
        this.$message({
          message: "复制失败",
          center: true,
          offset: 70,
          customClass: 'message',
          type: 'error'
        })
        clipboard.destroy()
      })
    })

  },
  destroyed () {
    this.clipboard.destroy()
  },
  methods: {
    /**
     * 渲染markdown
     */
    renderMarkdown(data) {
      const MarkdownIt = require('markdown-it')
      const hljs = require('highlight.js')
      // 所有的选项列表（默认情况下）
      let md = new MarkdownIt({
        html:         true,        // 在源码中启用 HTML 标签
        // langPrefix:   'language-',  // 给围栏代码块的 CSS 语言前缀。对于额外的高亮代码非常有用。
        linkify:      true,        // 将类似 URL 的文本自动转换为链接。

        // 启用一些语言中立的替换 + 引号美化
        typographer:  true,


        // 高亮函数，会返回转义的 HTML。
        // 如果源字符串未更改，且应该进行外部的转义，或许返回 ''
        // 如果结果以 <pre ... 开头，内部包装器则会跳过。
        highlight: function (str, lang) {
          console.log("Markdown.vue 代码高亮");
          // 当前时间加随机数生成唯一的id标识
          const codeIndex = parseInt(Date.now()) + Math.floor(Math.random() * 10000000)
          // 复制功能主要使用的是 clipboard.js
          let copyHtml = `<div class="copy-btn"  data-clipboard-action="copy" data-clipboard-target="#copy${codeIndex}">复制</div>`
          // const linesLength = str.split(/\n/).length - 1
          // 生成行号
          // let linesNum = '<span aria-hidden="true" class="line-numbers-rows">'
          // for (let index = 0; index < linesLength; index++) {
          //   linesNum = linesNum + '<span></span>'
          // }
          // linesNum += '</span>'

          console.log(copyHtml);

          // 此处判断是否有添加代码语言
          if (lang && hljs.getLanguage(lang)) {
            try {
              // 得到经过highlight.js之后的html代码
              const preCode = hljs.highlight(lang, str, true).value
              // 以换行进行分割
              const lines = preCode.split(/\n/).slice(0, -1)
              // 添加自定义行号
              let html = lines.map((item, index) => {
                return '<li><span class="line-num" data-line="' + (index + 1) + '"></span>' + item + '</li>'
              }).join('')
              html = '<ol>' + html + '</ol>' + copyHtml
              // 添加代码语言
              if (lines.length) {
                html += '<b class="name">' + lang + '</b>'
              }
              return '<pre class="hljs"><code id="copy' + codeIndex + '">' +
                html +
                '</code></pre>'
            } catch (__) {}
          }
          // 未添加代码语言，此处与上面同理
          const preCode = md.utils.escapeHtml(str)
          const lines = preCode.split(/\n/).slice(0, -1)
          let html = lines.map((item, index) => {
            return '<li><span class="line-num" data-line="' + (index + 1) + '"></span>' + item + '</li>'
          }).join('')
          html = '<ol>' + html + '</ol>' + copyHtml
          return '<pre class="hljs"><code id="copy' + codeIndex + '">' +
            html +
            '</code></pre>'
          }
        }).use(MarkdownItMark)
          .use(MarkdownItSub)
          .use(MarkdownItSup)
          .use(require('markdown-it-footnote'));

      
      this.md = md.render(`@[toc]${data}`);
          
    }
  }
}
</script>



<style lang="scss" >
// 这块不能加 scoped 否则不好使


@import '~@/assets/css/github-markdown.css';

.markdown-write-body {
  box-sizing: border-box;
  min-width: 200px;
  max-width: 980px;
  margin: 0 auto;
  padding: 10px;
}

@media (max-width: 767px) {
  .markdown-write-body {
    padding: 15px;
  }
}


pre {
  height: 100% !important;
}

// 添加行号样式
pre.hljs {
  padding: 8px 2px;
  border-radius: 5px !important;
  position: relative;
  font-size: 14px !important;
  line-height: 22px !important;
  overflow: hidden !important;
  word-break: normal !important;
  ol {
    list-style: decimal;
    margin: 0;
    margin-left: 40px;
    padding: 0;
    li {
      list-style: decimal-leading-zero;
      position: relative;
      padding-left: 10px;
      .line-num {
        position: absolute;
        left: -40px;
        top: 0;
        width: 40px;
        height: 100%;
        border-right: 1px solid rgba(0, 0, 0, .66);
      }
    }
  }
  .line-numbers-rows {
    position: absolute;
    pointer-events: none;
    top: 12px;
    bottom: 12px;
    left: 0;
    font-size: 100%;
    width: 40px;
    text-align: center;
    letter-spacing: -1px;
    border-right: 1px solid rgba(0, 0, 0, .66);
    user-select: none;
    counter-reset: linenumber;
    span {
      pointer-events: none;
      display: block;
      counter-increment: linenumber;
      &:before {
        content: counter(linenumber);
        color: #999;
        display: block;
        text-align: center;
      }
    } 
  }

  b.name {
    position: absolute;
    top: 8px;
    right: 60px;
    z-index: 10;
    color: #999;
    pointer-events: none;
  }
  .copy-btn {
    position: absolute;
    border-radius: 3px !important;
    top: 3px;
    right: 4px;
    z-index: 10;
    color: #777;
    cursor: pointer;
    background-color: #fff;
    border: 0;
    border-radius: 2px;
  }
}

</style>