<template>
<div class="m-login">
  <span class="error" v-if="errorMeg != ''">{{errorMeg}}</span>
  <el-form ref="form" :model="form" label-width="0px">
    <el-form-item>
      <el-input v-model="form.username" placeholder="用户名/邮箱/手机号"></el-input>
    </el-form-item>

    <el-form-item>
      <el-input v-model="form.password" show-password placeholder="密码"></el-input>
    </el-form-item>
    
    <el-form-item>
      
      <el-button type="primary" @click="onLogin" :loading="loginLoading">
        登录
      </el-button>
      
    </el-form-item>
    

    
  </el-form>
  
  <div class="m-login-1">
    <div class="tis" v-if="!isUsernameAndPwd">用户名或者密码错误</div>
    <div class="m-pwd-reg">
      <a href="#">忘记密码 </a> &emsp; 
      <span @click="registerEvent">新用户注册</span>
    </div>  
  </div>


  <el-divider>第三方账号登录</el-divider>

  <div class="m-social-image">
    <div></div><div></div>
    <el-image
      style="width: 40px; height: 40px"
      :src="social.weibo.imageUrl"
      fit="cover">
    </el-image>

    <el-image
      style="width: 40px; height: 40px"
      :src="social.weixin.imageUrl"
      fit="cover">
    </el-image>

    <el-image
      style="width: 40px; height: 40px"
      :src="social.qq.imageUrl"
      fit="cover">
    </el-image>
    <div></div><div></div>
  </div>
  

</div>
</template>

<script>
// import {userTokenName,userInfoName} from "@/util/const.js"
// import MeLoading from "@/components/common/loading/MeLoading.vue"
export default {
  components: {
    
  },
  props: {
    errorMeg: {
      type: String,
      default: ''
    },
    loginLoading: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      // 社交
      social: {
        weibo: {
          imageUrl: require("@/assets/img/weibo.png"),
        },
        weixin: {
          imageUrl: require("@/assets/img/weixin.png"),
        },
        qq: {
          imageUrl: require("@/assets/img/qq.png"),
        }
      },
      form: {
        username: '',
        password: '',
        // 用户登录时候向后端获取公钥，同时会返回一个code,登录提交的时候需要带上code,这样后端才会从缓存中获取到私钥
        code: '' 
        
      },
      // 用户名或者密码是否正确
      isUsernameAndPwd: true
    }
  },
  created() {
    // 设置过期时间为5天
    this.$cookies.config('5d')
  },
  methods: {
    onLogin() {
      
      this.$emit('login',this.form)
      
    },
    registerEvent() {
      console.log("注册事件");
      this.$emit("register-event")
    }
  }
}
</script>

<style lang="less" scoped>


.m-login {

  display: flex;
  flex-wrap: wrap;
  align-content: flex-start;  

  height: 100%;
  width: 400px;
  background-color: #ffffff;
  z-index: 10px;
  margin: 0 auto;
  margin-bottom: 20px;
}

.el-form {
  width: 400px;
}


.el-divider {
  top: 30px;
  margin: 40px;
}
.el-button {
  width: 100%;
}

.tis {
  color: red;
  margin-left: 40px;
}
.m-login-1 {
  display: flex;
  width: 400px;
}
.m-pwd-reg {
  margin-left: auto;
  margin-right: 5px;
  a {
    // 去掉a标签的下划线
    text-decoration: none;
  }
}

span {
  cursor: pointer;
}

span:hover {
  color: #00bcd4;
}

.el-image {
  cursor: pointer;
  border-radius: 4px;
}

.m-social-image {
  padding-top: 20px;
  height: 40px;
  width: 400px;
  display: flex;
  justify-content: space-around;
}

.error {
  color: red;
  margin-bottom: 10px;
}
</style>