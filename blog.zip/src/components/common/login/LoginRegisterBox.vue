<template>
<!-- 登录注册盒子 -->
  <div :class="{'hide': isHide}">
    <div class="login-register-box-beijing" ></div>
    <div class="login-register-box">
      <div class="lrb-header">
        <div class="clone" @click="hideClike" >✘</div>
        <span class="title">登录与注册</span>
      </div>
      <div class="line"></div>
      <div class="lr"><slot></slot></div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    isHide: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      hide: true
    }
  },
  watch: {
   isHide: function() {
     console.log("=====================================");
     this.hide = this.isHide
   } 
  },
  methods: {
    hideClike() {
      console.log("==============");
      this.$emit('clone')
    }
  }
}
</script>

<style lang="less" scoped>
.hide{
  display: none;
}
.login-register-box{
  display: flex;
  flex-wrap: wrap;
  align-content: flex-start;
  font-display: row;
  border-radius: 10px;
  background-color: white;
  position: fixed;
  width: 450px;
  height: 500px;
  top:35%;
  left: 50%;
  z-index: 10001;
  margin-top: -150px;
  margin-left: -200px;
}
.login-register-box-beijing{
  position: fixed;
  top:0;
  bottom: 0;
  left:0;
  right: 0;
  background: rgba(0,0,0,.5);
  z-index: 10000;
}

.lrb-header {
  display: flex;
  flex-direction: row-reverse;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  height: 40px;
  margin: 0px 10px;
  // background-color: pink;

}
.clone {
  cursor: pointer;
  width: 20px;
  height: 40px;
  line-height: 40px;
  font-size: 28px;
}

.title {
  line-height: 40px;
  font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
  font-size: 20px;
  color: #000000;
}

.lr {
  width: 100%;
  // background-color: red;
  margin: 10px 10px;
}

.line {
  width: 100%;
  height: 1px;
  margin: 5px 10px;
  border: none;
  background: rgba(255, 255, 255, 0.6);
  border-top: solid #ACC0D8 0.95px;
}
</style>