<template>
  <div>
    注册组件
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>