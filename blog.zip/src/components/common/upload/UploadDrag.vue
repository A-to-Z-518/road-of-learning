<template>
<!-- 拖拽上传 -->
  <el-upload
    class="upload-demo"
    ref="upload"
    drag
    action="https://jsonplaceholder.typicode.com/posts/"
    :http-request="upLoad"
    :show-file-list="true"
    :on-preview="handlePreview"
    :on-remove="handleRemove"
    :before-remove="beforeRemove"
    :on-change="onChange"
    :before-upload="beforeUpload"
    multiple
    :limit="1"
    :on-exceed="handleExceed"
    >
    <i class="el-icon-upload"></i>
    <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
    <div class="el-upload__tip" slot="tip">只能上传jpg/png文件，且不超过500kb</div>
  </el-upload>
</template>

<script>
import {warning,confirm} from "@/util/message"
export default {
  data() {
    return {
    }
  },
  methods: {
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
    },
    handleExceed(files, fileList) {
      console.log("-----------------");
      warning(this,`请先移除已选中的图片，再上传`);
    },
    beforeRemove(file, fileList) {
      return confirm(this,`确定移除 ${ file.name }？`);
    },
    onChange(file, fileList) {
      // this.$refs.upload.clearFiles()
    },
    beforeUpload(file) {
      
      this.$emit("beforeUpload",file)
    },
    /**
     * 向上抛出上传事件
     */
    upLoad(file) {
      console.log("上传图片");
      const formData = new FormData();
      formData.append('file', file.file);
      console.log(file);
      console.log(formData);
      this.$emit('upload',formData)
    }
  }
}
</script>

<style lang="less" scoped>
.upload-demo {
  width: 360px;
  height: 180px;
}
</style>