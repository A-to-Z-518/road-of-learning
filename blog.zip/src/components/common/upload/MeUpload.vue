<template>
  <el-upload
    ref="upload"
    class="avatar-uploader"
    action="https://jsonplaceholder.typicode.com/posts/"
    :http-request="upLoad"
    list-type="picture-card"
    :show-file-list="false"
    :limit="1"
    :on-preview="handlePictureCardPreview"
    :on-remove="handleRemove"
    :before-upload="beforeAvatarUpload">
    <img v-if="imageLink" :src="imageLink" class="avatar">
    <!-- 必须把文字放在图片后面才能通过css文字显示在图片上边 -->
    <span class="upload-show-text" >{{text}}</span> 
  </el-upload>
</template>

<script>
// 上传文件的api
import {uploadOneImage} from "@/api/upload"
export default {
  props: {
    // 显示文字
    text: {
      type:String,
      default: "修改图像"
    }
  },
  data() {
    return {
      imageLink: "https://cdn.pixabay.com/photo/2020/09/06/07/37/car-5548242__340.jpg"
    }
  },
  methods: {
    beforeAvatarUpload(file) {
      this.$emit("beforeUpload",file)
    },
    // 移除图片
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    changeFile(file,fileList) {
      console.log("文件改变");
    },
    // 上传图片
    upLoad(file) {
      const formData = new FormData();
      formData.append('file', file.file);
      console.log(file);
      console.log(formData);
      uploadOneImage(formData).then((res) => {
        console.log(res);

        if (res.code === 200) {
          this.imageLink = res.data
          console.log('上传成功');
          this.$message({
            message: res.msg,
            center: true,
            offset: 70,
            customClass: 'message',
            type: 'success'
          })
        } else {
          this.$message({
            message: res.msg,
            center: true,
            offset: 70,
            customClass: 'message',
            type: 'error'
          })
        }
        this.$emit("handleAvatarSuccess",this.imageLink)
      });
    }
  }
}
</script>

<style lang="less" scoped>
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  width: 120px;
  height: 120px;
  border-radius: 6px;
  cursor: pointer;
  position: relative !important;
  overflow: hidden !important;/* 这句是最主要的 可以使img显示在div的下面 */
}

.avatar-uploader {
  cursor: pointer;
}

.avatar {
  position: relative; 
  width: 120px;
  height: 120px;
  display: block;
}


img {
  display: block;
}


.upload-show-text { 
  width: 120px;
  height: 120px;
  line-height: 120px;
  text-align: center;
  margin: 0px !important;
  position: absolute; bottom: 0; left: 0;
  display: block;
}


.el-upload .el-upload--picture-card {
  width: 120px !important;
  height: 120px !important;
  line-height: 120px !important;
}
</style>