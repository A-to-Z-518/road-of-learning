<template>
  <div class="search-layout" :style="{'marginTop': layoutMarginTop + 'px'}">
    <!-- 搜索布局 -->
    <div class="search-layout-left">
      <div class="search-layout-left-item">
        <slot name="search-layout-left"> </slot>
      </div>
    </div>
    <div class="search-layout-center">
      <slot name="search-layout-center"> </slot>
    </div>
    <div class="search-layout-right">
      <slot name="search-layout-right"> </slot>
    </div>
    
  </div>
</template>

<script>
export default {
  props: {
    leftTop: {
      type: Number,
      default: 10
    },
    // 布局距离顶部的距离
    layoutMarginTop: {
      type: Number,
      default: 10
    }
  }
}
</script>

<style lang="less" scoped>
.search-layout {
  display: flex;
  margin: 10px auto;
  width: 1200px;

  .search-layout-left {
    width: 150px;
    background-color: pink;

    .search-layout-left-item {
      position: fixed;
      width: 150px;
      top: 10px;
    }
  }

  .search-layout-center {
    width: 780px;
    margin: 0px 10px;
    height: 1200px;
    background-color: pink;
  }

  .search-layout-right {
    flex: 1;
    height: 1200px;
    background-color: pink;
  }
}
</style>