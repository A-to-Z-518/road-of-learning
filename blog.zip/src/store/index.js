import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {

    // 用户id,这个id可以是任意一个用户的id
    userId: "",
    // 回调url，当用户跳转到登录页面的时候记录该值，登录之后回到这个地址页面
    callbackUrl: "",
    
    // 登录的用户
    userInfo: {
      // 用户是否登录
      isLogin: false,
      info: {

      }
      // avatar: "",
      // username: "",
      // usernick: ""
    }
  },
  mutations: {
    submitUserId(state,userId) {
      state.userId = userId
    },
    submitLoginUser(state,userInfo) {
      console.log("提交登录用户信息");
      console.log(userInfo.loginUser);
      state.userInfo.info = userInfo.loginUser
      state.userInfo.isLogin = true
    },
    submitCallbackUrl(state , submitCallbackUrl) {
      console.log("提交登陆成功后的回调地址: " + submitCallbackUrl.callbackUrl);
      state.callbackUrl = submitCallbackUrl.callbackUrl
    },
    submitIsLogin(state , isLogin) {
      state.isLogin = isLogin
    },
  },
  actions: {
  },
  modules: {
  },
  getters: {
    getUserId(state) {
      return state.userId
    },
    getUserInfo(state) {
      return state.loginUser
    },
    getCallbackUrl(state) {
      return state.callbackUrl
    }
  }
})
