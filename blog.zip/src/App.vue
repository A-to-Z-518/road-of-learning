<template>
  <div id="app"> 
    <router-view :class="{'view': isVisible}" v-if="isRouterAlive"></router-view>
  </div>
</template>

<script>
import Scroll from "@/components/common/scroll/Scroll.vue"
import Navbar from "@/components/common/nav/Navbar"
import Ceiling from "@/components/common/ceiling/Ceiling.vue"
export default {
  components: {
    Navbar,Ceiling,Scroll
  },
  data() {
    return {
      // true 显示导航栏 false不显示导航栏
      isVisible: false,
      isRouterAlive: true
    }
  },
  provide () {
    return {
      reload: this.reload
    }
  },
  methods: {
    reload () {
      this.isRouterAlive = false
      this.$nextTick(function () {
        this.isRouterAlive = true
      })
    },
    upEvent(scrollTop ) {
      this.isVisible = true
      console.log("正在向上滑动 打开………………………………" + scrollTop );
    },
    downEvent(scrollTop ) {
      this.isVisible = false

      console.log("正在向下滑动 关闭————————————" + scrollTop );
    }
  }
}
</script>
<style lang="less" scoped>
@import "~@/assets/css/base.css";

// .visible {
//   position: fixed;
//   top: 0px;
// }
.message {
  z-index: 20010 !important;
}

.test {
  position: flex !important ;
  z-index: 9000;
  padding: 100px;
}

#app {
  width: 100%;
  height: 100%;
  margin-right: 5px;
}

*::-webkit-scrollbar {
  /*滚动条整体样式*/
  width: 8px;/*定义纵向滚动条宽度*/
  height: 8px;/*定义横向滚动条高度*/
}

*::-webkit-scrollbar-thumb {
  /*滚动条内部滑块*/
  border-radius: 8px;
  background-color: hsla(220, 4%, 58%, 0.3);
  transition: background-color 0.3s;
}

*::-webkit-scrollbar-thumb:hover {
  /*鼠标悬停滚动条内部滑块*/
  background: #bbb;
}

*::-webkit-scrollbar-track {
  /*滚动条内部轨道*/
  background: #ededed;
}


</style>
