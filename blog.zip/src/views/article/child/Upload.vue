<template>
  <el-upload
    class="upload-demo"
    ref="upload"
    action="https://jsonplaceholder.typicode.com/posts/"
    :http-request="upLoad"
    :on-preview="handlePreview"
    :on-remove="handleRemove"
    :before-remove="beforeRemove"
    :on-change="onChange"
    :before-upload="beforeUpload"
    multiple
    :limit="1"
    :on-exceed="handleExceed"
    >
    <el-button size="small" type="primary">点击上传配图</el-button>
    <!-- <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div> -->
  </el-upload>
</template>

<script>
// 上传文件的api
import {uploadOneImage} from "@/api/upload"

export default {
    data() {
      return {
        
      };
    },
    methods: {
      handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      handlePreview(file) {
        console.log(file);
      },
      handleExceed(files, fileList) {
        this.$message.warning(`请先移除已选中的图片，再上传`);
      },
      beforeRemove(file, fileList) {
        return this.$confirm(`确定移除 ${ file.name }？`);
      },
      onChange(file, fileList) {
        // this.$refs.upload.clearFiles()
      },
      beforeUpload(file) {
        this.$emit("beforeUpload",file)
      },
      upLoad(file) {
        console.log("上传图片");
        const formData = new FormData();
        formData.append('file', file.file);
        console.log(file);
        console.log(formData);
        uploadOneImage(formData).then((res) => {
          console.log(res);

          if (res.code === 200) {
            this.imageLink = res.data
            console.log('上传成功');
            this.$message({
              message: res.msg,
              center: true,
              offset: 70,
              customClass: 'message',
              type: 'success'
            })
          } else {
            this.$message({
              message: res.msg,
              center: true,
              offset: 70,
              customClass: 'message',
              type: 'error'
            })
          }
          this.$emit("handleSuccess",this.imageLink)
        });
      }
    }
  }
</script>

<style lang="less" scoped>

</style>