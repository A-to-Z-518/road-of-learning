<template>

  <div class="article-write">
    <el-form :model="articleSubmit" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
      <el-form-item prop="title" label-width="0px">
        <el-input v-model="articleSubmit.title" placeholder="请输入标题">
          <el-select v-model="articleSubmit.articleType" slot="prepend" placeholder="类型">
            <el-option label="原创" value="原创"></el-option>
            <el-option label="转载" value="转载"></el-option>
            <el-option label="翻译" value="翻译"></el-option>
          </el-select>
        </el-input>
      </el-form-item>

      <el-form-item prop="tags" label-width="0px">
        <select-tags 
          :tagGroup="tagGroup" 
          :tagList="tagLists" class="select-tags" 
          @selected-tag="selectedTag" @create-tag="createTag"
          ref="tag"></select-tags>
      </el-form-item>

      
      <div class="article-form-switch">
        <el-form-item prop="sortName" label-width="0px" >
          <select-sort class="select-sort" 
            ref="sort"
            :sortList="sortList" @select-sort="selectSort" 
            @create-sort="createSort"></select-sort>
        </el-form-item>
        
        <!-- 是否公开 -->
        <span>
          公开
          <el-switch v-model="articleSubmit.isPublic"></el-switch>
        </span>
        
        <span class="article-form-switch-span">
          置顶
          <el-switch v-model="articleSubmit.isTop"></el-switch>
        </span>
      </div>

       

      <el-form-item prop="contentMd" label-width="0px">
        <mavon-editor style="height: 800px" ref="md" 
          v-model="articleSubmit.contentMd" :ishljs = "true" 
          @imgAdd="handleEditorImgAdd"
          @imgDel="handleEditorImgDel"
          :toolbars="toolbars"
          @save="saveMavon"/>
      </el-form-item>

      
      <!-- 上传图片 -->
      <el-form-item label-width="0px"  prop="imageUrl">  
        <upload @handleSuccess="handleSuccess" @beforeUpload="beforeUpload"></upload>
      </el-form-item>


      <el-form-item class="footer-button">
        <el-button type="primary" @click="submitArticleFrom('ruleForm')" :loading="isLoading">提交</el-button>
        <el-button @click="resetArticleFrom('ruleForm')">重置</el-button>
      </el-form-item>
    </el-form>

    <el-dialog
      :title="title"
      :visible.sync="dialogVisible"
      width="600px"
      :before-close="handleClose">
      <el-form :model="createForm" :rules="createFormRules" ref="createFormRef" label-width="100px" class="demo-ruleForm">
        <el-form-item label="名称" label-width="60px" prop="name">
          <el-input v-model="createForm.name"></el-input>
        </el-form-item>

        <el-form-item label="描述" label-width="60px" prop="description">
          <el-input type="textarea" v-model="createForm.description"></el-input>
        </el-form-item>
        
      </el-form>
        
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="createFormClick('createFormRef')">提交</el-button>
        <!-- <el-button @click="createForm('createForm')">重置</el-button> -->
      </span>
    </el-dialog>
  </div>
</template>

<script>
import SelectTags from "@/components/content/tag/SelectTags.vue"
import SelectSort from "@/components/content/sort/SelectSort.vue"

import {success,error} from "@/util/message.js"

import Upload from "./child/Upload"

import {findAllSort,saveSort} from "@/api/sort"
import {findAllTag,saveTag} from "@/api/tag"

import {saveArticle,findArticleById,updateArticle} from "@/api/article.js"
// 上传文件的api
import {uploadOneImage} from "@/api/upload"
export default {
  components: {
    Upload,SelectTags,SelectSort
  },
  data() {
    return {
      isLoading: false,
      // 是否是编辑状态
      isEdit: false,
      // 是否正在上传图片
      isUpload: false,
      // 是否弹出层
      dialogVisible: false,
      articleSubmit: {
        title: "",
        contentMd: "",
        html: "",
        userId: "",
        sortName: null,
        tags: "",
        isPublic: true,
        isTop: "",
        articleType: "原创",
        imageUrl: ""
      },
      createForm: {
        name: "",
        description: ""
      },
      // 分类
      sortList: [
      ],
      // 弹出层标题
      title: "",
      // 创建标签还是创建分类 false 创建分类标志， true 创建标签标志
      isCreateTag: false,
      // 标签,
      tagLists: [
      ],
      // 标签组
      tagGroup: [],
      rules: {
        title: [
          { required: true, message: '请输入标题', trigger: 'blur' }
        ],
        contentMd: [
          { required: true, message: '请输入文章内容', trigger: 'blur' }
        ],
        sortName: [
           { required: true, message: '请选择分类', trigger: 'blur' }
        ],
        tags: [
          { required: true, message: '请选择标签', trigger: 'blur' }
        ],
        articleType: [
          { required: true, message: '请选择文章类型', trigger: 'blur' }
        ]
      },
      createFormRules: {
        name: [
          { required: true, message: '请输入名称', trigger: 'blur' }
        ],
        description: [
          { required: true, message: '请输入描述', trigger: 'blur' }
        ],
      },
      toolbars: {
        bold: true, // 粗体
        italic: true, // 斜体
        header: true, // 标题
        underline: true, // 下划线
        strikethrough: true, // 中划线
        mark: true, // 标记
        superscript: true, // 上角标
        subscript: true, // 下角标
        quote: true, // 引用
        ol: true, // 有序列表
        ul: true, // 无序列表
        link: true, // 链接
        imagelink: true, // 图片链接
        code: true, // code
        table: true, // 表格
        fullscreen: true, // 全屏编辑
        readmodel: true, // 沉浸式阅读
        htmlcode: true, // 展示html源码
        help: true, // 帮助
        /* 1.3.5 */
        undo: true, // 上一步
        redo: true, // 下一步
        trash: true, // 清空
        save: false, // 保存（触发events中的save事件）
        /* 1.4.2 */
        navigation: true, // 导航目录
        /* 2.1.8 */
        alignleft: true, // 左对齐
        aligncenter: true, // 居中
        alignright: true, // 右对齐
        /* 2.2.1 */
        subfield: true, // 单双栏模式
        preview: true, // 预览
      }
    }
  },
  created() {
    let me = this;

    // 获取文章id
    let articleId = this.$route.params.id
    if (articleId != undefined) {
      this.isEdit = true
      
      // 获取文章
      findArticleById("",articleId).then(res => {
        console.log(res);
        if (res.code != 200) {
          error(me,res.msg)
        } else {
          this.articleSubmit = res.data
          // 初始化分类和标签
          this.$refs['sort'].setInitSelectSort(this.articleSubmit.sortName)
          console.log(this.articleSubmit.tags);
          console.log(res.data);
          this.$refs['tag'].setInitSelectTag(this.articleSubmit.tags)
        }
      })
    }
    
    console.log("发送并发请求");
    let This = this
    this.$axios.all([findAllSort(),findAllTag()])
      .then(this.$axios.spread(function(allSort,allTag) {
        console.log(allSort);
        console.log("并发请求发送完成");
        if (allSort.code !== 200) {
          error(me,allSort.msg)
          return 
        } else if ( allTag.code !== 200 ) {
          error(me,allTag.msg)
          return
        }
        allSort.data.forEach(value => {
          me.sortList.push(value.name)
        })

        me.tagLists = allTag.data.tagLists
        me.tagGroup = allTag.data.tagSg
        
      }))
  },
  methods: {
    // 创建分类
    createSort() {
      this.isCreateTag = false
      console.log("创建分类");
      this.title = "创建分类"
      this.dialogVisible = true
    },
    // 创建标签
    createTag() {
      this.isCreateTag = true
      console.log("创建标签");
      this.title = "创建标签"
      this.dialogVisible = true
    },
    // 被选中的分类
    selectSort(sortName) {
      this.articleSubmit.sortName = sortName
    },
    // 被选中的标签
    selectedTag(tags) {
      this.articleSubmit.tags = tags
    },

    handleEditorImgAdd(pos, $file) {
      // 第一步.将图片上传到服务器.
      let formdata = new FormData();
      // 这个是对应到后台接口的参数名
      formdata.append('file', $file);
      uploadOneImage(formdata).then((res) => {
        console.log(res);
        
        if (res.code === 200) {
          // 第二步.将返回的url替换到文本原位置![...](0) -> ![...](url)  这里是必须要有的
          console.log('上传成功');
          this.$message({
            message: res.msg,
            center: true,
            offset: 70,
            customClass: 'message',
            type: 'success'
          })

          let url = res.data
          let name = $file.name
          if (name.includes('-')) {
              name = name.replace(/-/g, '')
          }

          let content = this.articleSubmit.contentMd
          // 第二步.将返回的url替换到文本原位置![...](0) -> ![...](url)  这里是必须要有的
          if (content.includes(name)) {
              let oStr = `(${pos})`
              let nStr = `(${url})`
              let index = content.indexOf(oStr)
              let str = content.replace(oStr, '')
              let insertStr = (soure, start, newStr) => {
                  return soure.slice(0, start) + newStr + soure.slice(start)
              }
              this.articleSubmit.contentMd = insertStr(str, index, nStr)
          }
        } else {
          this.$message({
            message: res.msg,
            center: true,
            offset: 70,
            customClass: 'message',
            type: 'error'
          })
        }
      });
    },
    /**
     * 富文本保存的方法
     */
    saveMavon(value,render) {
      console.log("this is render"+render);
      console.log("this is value"+value);
    },

    beforeUpload(file) {
      this.isUpload = true
    },
    handleSuccess(imageUrl) {
      console.log("图片上传成功");
      this.isUpload = false
      this.articleSubmit.imageUrl = imageUrl
      console.log(imageUrl);
    },
    submitArticleFrom(formName) {
      
      this.$refs[formName].validate((valid) => {
          if (valid) {
            if(this.isUpload) {
              this.$message.warning(`请等待图片上传完，再提交`);
            return
          }
          // 得到相应的html / 文件
          this.articleSubmit.html = this.$refs.md.d_render

          this.isLoading = true
          if (this.isEdit) {
            updateArticle(this.articleSubmit).then(res => {
              this.isLoading = false
              if (res.code == 200) success(this,res.msg)
              else error(this,res.msg)
            })
          } else {
            saveArticle(this.articleSubmit).then(res => {
              this.isLoading = false
              if (res.code == 200) success(this,res.msg)
              else error(this,res.msg)
            })
          }
          
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },

    /**
     * 弹出框提交
     */
    createFormClick(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          // 验证通过关闭窗口
          this.dialogVisible = false
          // 提交表单
          console.log(this.articleSubmit);
          // 创建数据
          if (this.isCreateTag == false) {
            this.createSortFrom()
          } else {
            // 创建标签
            this.createTagFrom()
          }
        } else {
          this.$message.warning("请填入必选项");
          return false;
        }
      });
    },

    // 创建标签
    createTagFrom() {
      // 创建标签
      saveTag(this.createForm).then(res => {
        console.log(res);
        if (res.code == 200) {
          let arry = []
          arry.push(res.data)
          // 将数据插入到数组中
          this.tagLists.push(arry)
          success(this,res.msg)
        } else {
          error(this,res.msg)
        }
      })
    },

    createSortFrom() {
      // 创建分类
      saveSort(this.createForm).then(res => {
        console.log(res);
        if (res.code == 200) {
          // 将数据插入到数组中
          this.sortList.push(res.data.name)
          success(this,res.msg)
        } else {
          error(this,res.msg)
        }
      })
    },


    /**
     * 重置表单
     */
    dialogResetArticleFrom1(formName) {

    },


    selectSortAndTag() {

    },
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done();
        })
        .catch(_ => {});
    }
  }
}
</script>

<style lang="less" scoped>
.select-tags {
  // margin-top: 0px;
  // margin-bottom: 10px;
}

.el-select{
    width: 80px;
  }

.article-write {
  width: 1200px;
  margin: 10px auto;
  padding: 20px 20px 20px 0px;
}

.el-switch {
  margin: 0px !important;
}
.footer-button {
  display: flex;
  flex-direction: row-reverse;
}

.article-form-switch {
  display: flex
}

span {
  font-size: 16px;
}

.article-form-switch span{
  margin: 5px 0px 10px 20px;
}

.article-form-switch-span {
  padding: 0px 10px 0px 20px;
}

</style>