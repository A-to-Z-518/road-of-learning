<template>
  <div class="uc">
    <navbar @search-query="searchQuery"></navbar>
    <el-container >
        <el-header>
          <uc-header :userInfo="userInfo"></uc-header>
        </el-header>
        <el-container>
          <el-aside width="200px">
            <me-sidebar :options="item" v-for="(item,index) in sidebarList" :key="index"></me-sidebar>
          </el-aside>
          <el-container > 
            <el-main>
              <router-view></router-view>
            </el-main>
          </el-container>
        </el-container>
    </el-container>
  </div>
</template>

<script>
import Navbar from "@/components/common/nav/Navbar"
import MeSidebar from "@/components/common/sidebar/MeSidebar"
import UcHeader from "./header/UcHeader"

import {getUser} from "@/util/user"
export default {
  components: {
    MeSidebar,Navbar,UcHeader
  },
  data() {
    return {
      // 用户信息
      userInfo: {

      },
      sidebarList: [
        {
          title: "消息中心",
          list: [
            {to: "",name: "我的消息"},
            {to: "",name: "系统消息"}
          ]
        },
        {
          title: "基本设置",
          list: [
            {to: "/uc/profile",name: "个人资料"},
            {to: "",name: "修改密码"},
            {to: "",name: "第三方账号绑定"}
          ]
        },
        {
          title: "博客管理",
          list: [
            {to: "/uc/collect",name: "我的收藏"},
            {to: "/uc/sort",name: "分类管理"},
            {to: "/uc/article",name: "博文管理"}
          ]
        }
        
      ]
    }
  },
  created() {
    // 获取用户信息
    // ucProfile().then(res => {
    //   if (res.code == 200) this.userInfo = res.data
    // })
    let userInfo = getUser()
    this.$store.commit({
      type: "submitLoginUser",
      loginUser: userInfo  // 可以使用es6语法
    })
  },
  methods: {
    searchQuery() {

    }
  }
}
</script>

<style lang="less" scoped>

.uc {
  // margin-left: 160px;
  // margin-right: 160px;
  width: 1200px;
  margin: 10px auto;
  margin-top: 70px;
}
.el-header {
  border-radius: 10px;
  background-color: #ffffff;
  color: #333;
  margin-bottom: 10px;
}


.el-aside {
  color: #333;
  border-radius: 10px;
}
  
.el-main {
  background-color: #ffffff;
  border-radius: 10px;
  color: #333;
  width: 1000px;
  margin-left: 10px;
  padding: 0px ;
}

.el-header {
  height: 80px !important;
  background-image: url("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1601605244653&di=bc15d491b0c34a37ec4913180422485e&imgtype=0&src=http%3A%2F%2Fbpic.588ku.com%2Fback_pic%2F04%2F56%2F41%2F915865ca67671de.jpg");
}

</style>