<template>
  <div class="sort-edit">
    <div class="return" @click="returnPage">
      < 返回分类专栏
    </div>
    <el-form 
      class="sort-edit-form"
      :model="sort" 
      :rules="rules" 
      ref="ruleForm" 
      label-width="100px">
      <el-form-item label="分类名称" prop="name">
        <el-input v-model="sort.name"></el-input>
      </el-form-item>
      <el-form-item label="分类简介" prop="description">
        <el-input
          type="textarea"
          :rows="2"
          placeholder="请对该分类进行概述"
          v-model="sort.description">
        </el-input>
      </el-form-item>

      <el-form-item label="分类图片" prop="imageLink">
        <me-upload @handleAvatarSuccess="handleAvatarSuccess" @beforeUpload="beforeUpload"></me-upload>
      </el-form-item>

      <el-form-item>
        <el-button 
          style="width: 100px" 
          type="primary" :loading="isSubmit" 
          @click="onSubmitSort('ruleForm')">提交</el-button>
      </el-form-item>

    </el-form>
      
  </div>
</template>

<script>
import MeUpload from "@/components/common/upload/MeUpload.vue"
import {saveSort,editUpdate} from "@/api/sort"
export default {
  components: {
    MeUpload
  },
  data() {
    return {
      // 是否正在上传
      isUplaod: false,
      // 是否是编辑
      isEdit: false,
      // 是否提交
      isSubmit: false,
      // 提交编辑后的分类
      sort: {
        name: "",
        description: "",
        imageLink: "https://cdn.pixabay.com/photo/2020/09/06/07/37/car-5548242__340.jpg"
      },
      rules: {
        name: [
          { required: true, message: '请输入分类名称', trigger: 'blur' }
        ],
        description: [
          { required: true, message: '请输入分类简介', trigger: 'blur' }
        ],
        imageLink: [
          { required: true, message: '请输入选择图片', trigger: 'blur' } 
        ]
      }
    }
  },
  created() {
    console.log(this.$route.query);
    // 如果有值传过来就说明是编辑
    if (this.$route.query.name == null) {
      this.isEdit = false
    } else {
      this.tag = this.$route.query  
      this.isEdit = true
    }
  },
  methods: {
    // 提交编辑的分类
    onSubmitSort(formName) {
      if (this.isUplaod) {
        this.$message({
          message: "请耐心等待图片上传完成，再提交...",
          center: true,
          offset: 70,
          customClass: 'message',
          type: 'error'
        })
        return
      }
      this.$refs[formName].validate((valid) => {
        if (valid) { 
          // 要根据isEdit判断是否是编辑
          if(this.isEdit) this.edit()
          else this.save()
          console.log("分类提交成功");
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    // 返回上一个页面
    returnPage() {
      this.$router.go(-1)
    },
    /**
     * 编辑
     */
    edit() {
      this.isSubmit = true
      console.log("编辑提交");
      editUpdate(this.tag).then(res => {
        // 保存失败
        if (res.code !== 200) {
          this.$message({
            message: res.msg,
            center: true,
            offset: 70,
            customClass: 'message',
            type: 'error'
          })
          
        } else {
          this.$message({
            message: res.msg,
            center: true,
            offset: 70,
            customClass: 'message',
            type: 'success'
          })
        }
        this.isSubmit = false
        return
      })
    },
    /**
     * 保存
     */
    save() {
      this.isSubmit = true
      console.log("保存提交");
      saveSort(this.sort).then(res => {
        console.log("保存成功");
        // 保存失败
        if (res.code !== 200) {
          this.$message({
            message: res.msg,
            center: true,
            offset: 70,
            customClass: 'message',
            type: 'error'
          })
          
        } else {
          this.$message({
            message: res.msg,
            center: true,
            offset: 70,
            customClass: 'message',
            type: 'success'
          })
        }
        this.isSubmit = false
        return
      })
    },
    // 返回上一个页面
    returnPage() {
      this.$router.go(-1)
    },
    /**
     * 上传成功时候的回调函数
     */
    handleAvatarSuccess(imageLink) {
      console.log(imageLink)  ;
      this.sort.imageLink = imageLink
      this.isUplaod = false
    },
    /**
     * 上传之前的回调函数
     */
    beforeUpload(file) {
      console.log("=========");
      this.isUplaod = true
    }
    
  }
}
</script>

<style lang="less">

@import "~@/assets/less/upload.less";

.sort-edit {
  // padding-top: 20px;
  padding: 10px;
}

.sort-edit-form {
  width: 500px;
}

.return {
  color: rgba(0, 0, 0, 0.5);
  cursor: pointer;
  padding: 0px 20px 20px 15px ;
}

</style>