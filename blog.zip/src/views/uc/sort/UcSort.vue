<template>
  <div class="uc-sort">
    <router-link to="/uc/sort/edit" >
      <el-button type="primary" plain>添加分类</el-button>
    </router-link>
    
    <el-table
      :data="sortList"
      style="width: 100%">
      <!-- 其实是显示图片 -->
      <el-table-column
        prop="imageLink"
        label="名称"
        width="70">
        <template slot-scope="scope"> 
          <el-image 
            style="width: 70px; height: 70px;padding: 2px 3px 2px 0px"
            :src="scope.row.imageLink">
          </el-image>
          
        </template>
      </el-table-column>
      <!-- 显示名称 -->
      <el-table-column
        prop="name"
        width="180">
        <template slot-scope="scope"> 
          <span class="sortList-name">{{scope.row.name}} </span>
        </template>
        
      </el-table-column>

      <!-- 显示操作 -->
      <el-table-column label="操作">
        <template slot-scope="scope">
          <router-link :to="{path: '/uc/sort/edit',query: scope.row}" >
            <span class="sortList-caozuo">编辑</span> 
          </router-link>
        <span class="sortList-caozuo" @click="deleteSort( scope.row.id , scope.$index)">删除</span>
        </template>
      </el-table-column>

      <!-- 显示文字数量 -->

      <el-table-column label="文章数">
        <template slot-scope="scope">
          {{scope.row.articleCount}}
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import {findAllSort,deleteById} from "@/api/sort"
export default {
  data() {
    return {
      sortList: []
    }
  },
  created() {
    // 查询全部的分类
    this.findAllSort()
  },
  methods: {
    /**
     * 删除分类
     */
    deleteSort(id,index) {
      console.log(id);
      this.$confirm('此操作将删除该分类, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.deleteById(id)
        this.sortList.splice(index,1)
        this.$message({
          type: 'success',
          message: '删除成功!',
          offset: 60
        });
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除',
          offset: 60
        });          
      });
    },
    deleteById(id) {
      deleteById(id).then(res => {
        if (res.code == 200) {
          this.tagList.splice(index,1)
          this.$message({
            type: 'success',
            message: res.msg,
            offset: 60
          });
        } else {
          this.$message({
            type: 'error',
            message: res.msg,
            offset: 60
          });
        }
      })
    },
    /**
     * 查询全部的分类
     */
    findAllSort() {
      console.log("获取全部分类");
      findAllSort().then(res => {
        // 获取失败
        if (res.code !== 200) {
          this.$message({
            message: res.msg,
            center: true,
            offset: 70,
            customClass: 'message',
            type: 'error'
          })
          return
        }
        this.sortList = res.data
      }) 
    }
  }
}
</script>

<style lang="less" scoped>

.sortList-name {
  font-size: 16px;
  font-family: Microsoft YaHei;
}

.sortList-caozuo {
  color: red;
  padding: 0px 10px 0px 0px;
  cursor: pointer;
}

.uc-sort {
  padding: 10px;
}

a {
  text-decoration: none;
}

</style>