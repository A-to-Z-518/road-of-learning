<template>
  <div class="article">
    <!-- 标签项 -->
    <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="全部" name="first" ></el-tab-pane>
      <el-tab-pane label="公开" name="second"></el-tab-pane>
      <el-tab-pane label="私密" name="third"></el-tab-pane>
      <el-tab-pane label="草稿箱" name="fourth"></el-tab-pane>
      <el-tab-pane label="回收站" name="fifth"></el-tab-pane>
    </el-tabs>


    <!-- 筛选 -->
    <el-form :inline="true" :model="filterArticle" class="demo-form-inline">
      <el-form-item>
        <span style="font-size: 16px">筛选: </span>
      </el-form-item>

      <el-form-item>
        <el-col :span="24">
          <el-date-picker size="medium" type="date" placeholder="选择日期" v-model="filterArticle.date" style="width: 100%;"></el-date-picker>
        </el-col>
      </el-form-item>
      
      <el-form-item>
        <el-select size="medium" style="width: 150px" v-model="filterArticle.articleType" placeholder="文章类型">
          <el-option label="不限" value="不限"></el-option>
          <el-option label="原创" value="原创"></el-option>
          <el-option label="转载" value="转载"></el-option>
          <el-option label="翻译" value="翻译"></el-option>
        </el-select>
      </el-form-item>

      <el-form-item>
        <el-select size="medium" style="width: 150px" v-model="filterArticle.sort" placeholder="分类类型">
          <el-option label="不限" value="不限"></el-option>
          <el-option label="java" value="java"></el-option>
          <el-option label="springboot" value="springboot"></el-option>
          <el-option label="前端" value="前端"></el-option>
        </el-select>
      </el-form-item>

      <el-form-item>
        <el-input style="width: 250px" size="medium" v-model="filterArticle.query" placeholder="请输入关键字进行搜索..."></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary"  style="width:100px" size="medium" @click="filterArticleSubmit">搜索</el-button>
      </el-form-item>
    </el-form>

    <!-- 文章列表 -->
    <div class="me-article-item" v-for="item in pageInfo.data" :key="item.id">
      <p class="me-article-title">
        <!-- <span @click="goLink(item.id)"> {{item.title}}</span> -->
        <router-link tag="a" target="_blank" :to="{path:'/article/details/' + item.id}">{{item.title}}</router-link>
      </p>

      <div class="article-list-item-info">
        <div class="me-article-info-left">
          <span class="article-item-time">{{item.createTime | dateFilter}}</span>
          <span class="article-item-readComment">
            <svg-icon icon-class="reading" class="me-svg"></svg-icon>
            {{item.viewCount}}
          </span>
          <span class="article-item-readComment">
            <svg-icon icon-class="comment" class="me-svg"></svg-icon>
            {{item.commentCount}}
          </span>
          <span class="article-item-readComment">
            <svg-icon icon-class="like" class="me-svg"></svg-icon>
            {{item.likeCount}}
          </span>
        </div>
        <div class="me-article-info-right">

          <span class="article-info-delete" @click="deleteArticle(item.id)">删除</span>
        </div>
      </div>
      
    </div>


    <!-- 分页 -->
    <el-pagination
      v-if="pageInfo.total > 5"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageInfo.pageNum"
      :page-sizes="[5, 10, 15, 20]"
      :page-size="pageInfo.pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="pageInfo.total">
    </el-pagination>
  </div>
</template>

<script>
import {
  findUserArticleByPage,
  logicDeleteArticleById,
  getLogicDeleteArticle,
  deleteArticleById} from "@/api/article"
import {success,error,info} from "@/util/message.js"
export default {
  data() {
    return {
      // 当前选项卡
      currentTabPane: "全部",
      // 过滤
      filterArticle: {
        query: "",
        articleType: "",
        sort: ""
      },
      activeName: 'first',


      pageInfo: {
        // 第几页
        pageNum: 1,
        // 每页大小
        pageSize: 10,
        // 总数
        total: 10,
        // 文章列表
        data: [
          
        ]
      }
    }
  },
  created() {
    this.findArticleByPage()
  },
  methods: {
   
    findArticleByPage() {
      console.log(this.pageInfo);
      findUserArticleByPage(this.pageInfo.pageNum,this.pageInfo.pageSize).then(res => {
        if (res.code == 200) {
          console.log(res);
          this.pageInfo.total = res.data.total
          this.pageInfo.data = res.data.list
        }
      })
    },
    // 过滤文章 表单提交
    filterArticleSubmit() {

    },

    /**
     * 标签头切换所触发的方法
     */
    handleClick(tab, event) {
      // 防止用户多次点击同一个选项卡，多次访问后台，造成不必要的服务器压力
      if (this.currentTabPane == tab.label) return

      this.currentTabPane = tab.label
      if (tab.label == "回收站") this.handleClickRecycleBin()
      else if(tab.label == "全部") this.handleClickAll()
    },

    /**
     * 回收站
     */
    handleClickRecycleBin() {
      getLogicDeleteArticle(this.pageInfo.pageNum).then(res => {
        console.log(res);
        if (res.code != 200) error(this,res.msg)
        else {
          this.pageInfo.data = res.data.list
          this.pageInfo.total = res.data.total
        }
      })
    },  
    /**
     * 全部
     */
    handleClickAll() {
      this.findArticleByPage()
    },

    /**
     * 公开
     */

    /**
     * 私密
     */

    /**
     * 页大小发生改变
     */
    handleSizeChange(val) {
      this.pageInfo.pageSize = val
      this.findArticleByPage(this.pageInfo)
      // console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      this.pageInfo.pageNum = val
      if(this.currentTabPane == "全部") this.findArticleByPage()
      else if(this.currentTabPane == "回收站") this.handleClickRecycleBin();
      
      // console.log(`当前页: ${val}`);
    },

    /**
     * 删除文章
     */
    deleteArticle(id) {
      console.log(id);
      this.$confirm('此操作将删除该文章, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        if(this.currentTabPane == "全部") this.logicDeleteArticleById(id)
        else if (this.currentTabPane == "回收站") this.deleteArticleById(id)
        
      }).catch(() => {
        info(this,"已取消删除")
      });
    },

    // 真正的删除
    deleteArticleById(id) {
      deleteArticleById(id).then(res => {
        this.apiCommonResult(id,res)
      })
    },

    // 逻辑删除
    logicDeleteArticleById(id) {
      logicDeleteArticleById(id).then(res => {
        this.apiCommonResult(id,res)
      })
    },

    /**
     * api公共结果处理
     */
    apiCommonResult(id,res) {
      let This = this
      if(res.code != 200) error(this,res.msg) 
      else {
        This.pageInfo.total--
        success(This,res.msg)
        // 删除数组中的元素
        for(let index = 0; index < This.pageInfo.data.length;index++) {
          console.log(index);
          if(This.pageInfo.data[index].id == id) {
            This.pageInfo.data.splice(index,1)
          }
        }
        
      }
    }
  }
}
</script>

<style lang="less" scoped>

.article {
  padding: 10px;
}

.me-article-item {
}


.me-article-title {
  font-size: 18px;
  color: #4d4d4d;
  margin-bottom: 1px;
}

.el-pagination {
  padding: 20px 20px 10px 0px;
}

.article-list-item-info{
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  flex-wrap: nowrap;

  height: 12.8px;
  border-bottom: 1px dotted #ddd;
  padding: 1rem 0 1rem 0;
  color: #999;
  font-size: 12px;
}
.article-item-time {
  margin: 0 50px 0px 0px;
}
.article-item-readComment {
  margin: 0 0 15px 15px;
}

a {
  text-decoration: none;
}

a:link {
  color: #4d4d4d;
}

a:hover {
  color: red;
}
.me-svg {
  width: 1.1em !important;
  height: 1.1em !important;
}

.span {
  font-family: PingFang SC,Hiragino Sans GB,Arial,Microsoft YaHei,Verdana,Roboto,Noto,Helvetica Neue,sans-serif !important;
}
.article-list-item-info .me-article-info-right span {
  cursor: pointer;
}

.article-info-delete {
  color: red;
}

.me-article-item {
  display: flex;
  flex-direction: column;
}


</style>