<template>
  <div class="uc-profile">
    <div class="uc-userInfo-h">
      <span class="uc-userInfo-h-left">个人账号</span>
      <span v-if="!isEditUserInfo" class="uc-userInfo-h-right" @click="editUserInfo">修改信息</span>
      <span v-else class="uc-userInfo-h-right" @click="saveUserInfo">保存信息</span>
    </div>
    <div class="up-user-info" v-if="!isEditUserInfo">
      <div class="up-user-info-item">
        <span class="up-user-info-item-t">昵称</span>
        <span class="up-user-info-item-t1">{{userInfoForm.usernick}}</span>
      </div>
      <div class="up-user-info-item">
        <span class="up-user-info-item-t">简介</span>
        <span class="up-user-info-item-t1">{{userInfoForm.introduction}}</span>
      </div>

      <div class="up-user-info-item">
        <span class="up-user-info-item-t">姓名</span>
        <span class="up-user-info-item-t1">
          {{userInfoForm.name}}
        </span>
      </div>

      <div class="up-user-info-item">
        <span class="up-user-info-item-t">性别</span>
        <span class="up-user-info-item-t1">
          {{userInfoForm.gender}}
        </span>
      </div>
    </div>

    <!-- 编辑 -->
    <el-form  v-else ref="userInfoFormRef" :model="userInfoForm" label-width="80px">
      <el-form-item label="昵称">
        <el-input v-model="userInfoForm.usernick"></el-input>
      </el-form-item>
      
      <el-form-item label="简介">
        <el-input type="textarea" v-model="userInfoForm.introduction"></el-input>
      </el-form-item>
      <el-form-item label="姓名">
        <el-input v-model="userInfoForm.name"></el-input>
      </el-form-item>
      <el-form-item label="性别">
        <el-radio-group v-model="userInfoForm.gender">
          <el-radio label="男"></el-radio>
          <el-radio label="女"></el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>
    

    <div class="uc-userInfo-h uc-background">
      <span class="uc-userInfo-h-left">主页背景图片</span>
      <span v-if="!isEditBackgrounp" class="uc-userInfo-h-right" @click="editBackgrounp">修改背景</span>
      <span v-else class="uc-userInfo-h-right" @click="saveBackgrounp">保存背景</span>
    </div>
    <!-- 图片展示 -->
    <div v-if="!isEditBackgrounp && userInfoForm.backgroundImage != null" class="uc-bc-img">
      <img :src="userInfoForm.backgroundImage" alt="">
    </div>
    
    <span v-if="userInfoForm.backgroundImage == null && !isEditBackgrounp" class="no-img-tip"> 还没有背景图片快去上传吧</span>
    
    <!-- <a-spin :spinning="spinning" class="upload-spin"> -->
    <it-loading :isLoading="isLoading"> 
      <upload-drag v-if="isEditBackgrounp" @upload="upload">  
      </upload-drag>
    </it-loading>
    

    <!-- </a-spin> -->
    
    
  </div>
</template>

<script>
import ItLoading from "@/components/common/loading/ItLoading.vue"
import {saveUser} from "@/util/user"
import {updateUserProfile} from "@/api/user"
import {success,error} from "@/util/message"
import UploadDrag from "@/components/common/upload/UploadDrag.vue"
import {uploadOneImage} from "@/api/upload"
export default {
  components: {
    UploadDrag,ItLoading
  },
  // props: {
  //   userInfo: {
  //     type: Object,
  //     default: function() {
  //       return {
  //         usernick: "随遇而安",
  //         name: '沈光阳',
  //         gender: '男',
  //         introduction: "我是一名博客开发者，从事本行已有90来年，如果你有需要随时为你服务，爱你哦我是一名博客开发者，从事本行已有90来年，如果你有需要随时为你服务，爱你哦",
  //       }
  //     }
  //   }
  // },
  created() {
    this.userInfoForm = this.$store.state.userInfo.info
  },
  data() {
    return {
      isLoading: false,
      isEditUserInfo: false,
      isEditBackgrounp: false,
      isUploadImage: false,
      userInfoForm: {}
    }
  },
  methods: {
    /**
     * 上传图片
     */
    upload(fileData) {
      this.isUploadImage = false
      console.log(fileData);
      this.isLoading = true
      uploadOneImage(fileData).then((res) => {
        this.isUploadImage = true
        if (res.code === 200) {
          console.log('上传成功');
          success(this,res.msg)
        } else {
          error(this,res.msg)
        }
        this.isLoading = false
        this.userInfoForm.backgroundImage = res.data
      });
    },
    /**
     * 编辑用户info
     */
    editUserInfo() {
      this.isEditUserInfo = true
    },
    /**
     * 保存用户信息
     */
    saveUserInfo() {
      this.isEditUserInfo = false
      this.updateUser()
    },
    /**
     * 更新用户
     */
    updateUser() {
      saveUser(this.userInfoForm)
      updateUserProfile(this.userInfoForm).then(res => {
        if (res.code == 200) {
          success(this,"用户信息更新成功")
        } else {
          error(this,res.msg)
        }
      })
    },
    /**
     * 编辑背景图片
     */
    editBackgrounp() {
      this.isEditBackgrounp = true
    },
    /**
     * 保存背景图片
     */
    saveBackgrounp() {
      console.log("保存背景图片");
      this.isEditBackgrounp = false
      if (!this.isUploadImage) {
        return
      } 
      this.isUploadImage = false
      this.updateUser()
    }
  }
}
</script>

<style lang="less" scoped>
.uc-profile {
  width: 960px;
  margin: 10px;
}
.up-user-info {
  display: flex;
  flex-wrap: wrap;
  margin-left: 20px;
  color: #666;
  width: 100%;
}

.up-user-info-item {
  display: flex;
  width: 100%;
  max-width: 900px;
  margin-bottom: 10px;
}

.up-user-info-item-t1 {
  display: block;
  flex: 1;
}


// item左侧标题
.up-user-info-item-t {
  display: block;
  // width: 45px !important;
  width: 50px;
}

.span {
  display: block;
}

// 头部
.uc-userInfo-h {
  display: flex;
  justify-content: space-between;
}

.uc-userInfo-h-left {
  font-size: 18px;
  font-weight: 800px;
  color: #212121;
  margin-bottom: 10px;
}
.uc-userInfo-h-right {
  cursor: pointer;
  color: red;
}

.uc-background {
  margin-top: 20px;
}

.uc-bc-img ,
.uc-bc-img img{
  width: 970px;
  height: 400px;
  border-radius: 10px;
}
.no-img-tip {
  font-size: 18px;
  color: #fca652;
}

.upload-spin {
  height: 180px;
  width: 360px;
}
</style>