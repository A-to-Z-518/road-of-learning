<template>
  <div class="uc-header">
    <!-- 头像 -->
    <uc-img :imgLink="$store.state.userInfo.info.avatar" @handleSuccess="handleSuccess"></uc-img>
    <!-- 用户简介 -->
    <span>
      {{$store.state.userInfo.info.introduction}}
    </span>

    <!-- <el-dialog
      title="上传图片"
      :visible.sync="uploadImageVisible"
      width="30%"
      :before-close="handleClose">
      <el-upload
        style="margin: 0px 25px"
        class="upload-demo"
        drag
        action="https://jsonplaceholder.typicode.com/posts/">
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
        <div class="el-upload__tip" slot="tip">只能上传jpg/png文件，且不超过500kb</div>
      </el-upload>
      <span slot="footer" class="dialog-footer">
        <el-button @click="uploadImageVisible = false">取 消</el-button>
        <el-button type="primary" @click="uploadImageVisible = false">确 定</el-button>
      </span>
    </el-dialog> -->
  </div>
</template>

<script>
import UcImg from "@/components/common/avatar/UcImg.vue"
import {saveUser,getUser} from "@/util/user"
import {updateUserProfile} from "@/api/user"
export default {
  components: {
    UcImg
  },
  data() {
    return {
      display: 'none',
      // userInfo: {
      //   introduction: '我是一名博客开发者，从事本行已有90来年，如果你有需要随时为你服务，爱你哦我是一名博客开发者，从事本行已有90来年，如果你有需要随时为你服务，爱你哦',
      //   avatar: 'http://m.imeitou.com/uploads/allimg/2020090113/3vtkvbrnutl.jpg'
      
      // }
    }
  },
  created() {
    // this.userInfo = this.$store.state.userInfo.info

  },
  methods: {

    handleSuccess(imageLink) {
      // 先获取到用户信息，然后重新写入到cookie和vuex中
      console.log(imageLink);
      let userInfo = getUser()
      console.log(userInfo);
      userInfo.avatar = imageLink
      saveUser(userInfo)
      updateUserProfile(userInfo).then(res => {
        if (res.code != 200) console.log("更新用户信息失败");
      })
    }
  }
}
</script>

<style lang="less" scoped>
.uc-header {
  display: flex;
  align-items: center;
  height: 80px;
}



</style>