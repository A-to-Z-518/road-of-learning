<template>
<div class="uc-collect">
  <div class="uc-collect-left">
    <ul>
      <li>
        <a href="javascript:;" class="uc-create-collect-item font" @click="createCollect">
          <svg-icon icon-class="new-folder" class="svg"></svg-icon> 新建收藏夹
        </a>
      </li>
      <li v-for="(item,index) in collectMgtList" :key="index" 
        class="uc-collect-left-item" :class="{'active-uc-collect-item': activeCollectIndex == index}"
        @click="activeCollectItem(item,index)">
        <a href="javascript:;" class="font">
          <svg-icon icon-class="collect" class="svg"></svg-icon> {{item.name}}
        </a>
      </li>
    </ul>
  </div>
  <!-- 右侧 -->
  <div class="uc-collect-right">
    <!-- 头部 -->
    <div class="co-right-header">
      <div class="co-right-header-up">
        <div v-if="whetherShowCollectName" class="collect-h">
          {{userCollectMgt.name}}
          <span @click="editCollectName" class="svg-icon"><svg-icon iconClass="edit" ></svg-icon></span>
        </div>
        <!-- 编辑名称 -->
        <div v-else class="co-edit collect-h">
          <el-input
            class="collect-input"
            size="small"
            placeholder="请输入修改的名字"
            v-model="userCollectMgt.name">
          </el-input>
          <span class="edit-collect cancel circle font-center" @click="whetherShowCollectName = true">X</span>
          <span class="edit-collect sure circle font-center" @click="sureEditName">√</span>
        </div>
      </div>
      <!-- 头部的底部 -->
      <div class="co-right-header-down">
        <div class="collect-dec" v-if="whetherShoweditCollectDec">
          {{userCollectMgt.description}}
          <span @click="editCollectDec" class="svg-icon"><svg-icon iconClass="edit" ></svg-icon></span>
        </div>
        <!-- 编辑描述 -->
        <div class="edit-co-dec" v-else>
          <el-input
            class="collect-input"
            size="small"
            placeholder="请输入描述"
            v-model="userCollectMgt.description">
          </el-input>
          <span class="edit-collect cancel circle font-center" @click="whetherShoweditCollectDec = true">X</span>
          <span class="edit-collect sure circle font-center" @click="sureEditDec">√</span>
        </div>
          <!-- 描述一栏的右侧 -->
          <div class="collect-dec-right">
            <ul>
              <li><a @click="deleteUserCollectMgt(userCollectMgt.name)" class="dec-right-item" href="javascript:;">删除收藏夹</a></li>
            </ul>
          </div>
      </div>
      <!-- 删除收藏夹弹框 -->
      <el-dialog
        title="删除收藏夹"
        :visible.sync="deleteVisible"
        width="30%"
        :before-close="handleClose">
        <el-radio v-model="deleteCollectWay" label="1"> 
          <el-select v-model="moveToCollectName" placeholder="移动到其他收藏夹" :filterable="true">
            <el-option
              v-for="(item) in moveOtherCollectMgtList"
              :key="item.id"
              :label="item.name"
              :value="item.name">
            </el-option>
          </el-select>
        </el-radio>
        <el-radio v-model="deleteCollectWay" label="2"><span style="color: #999">删除收藏夹(收藏内容将全被删除)</span></el-radio>
        <span slot="footer" class="dialog-footer">
          <el-button @click="cancelDeleteCollectSubmit">取 消</el-button>
          <el-button type="primary" @click="deleteCollectSumbit" :loading="deleteCollectLoading">确 定</el-button>
        </span>
      </el-dialog>
    </div>
    <!-- 收藏夹列表 -->
    <div class="co-right-list">
      <!-- 标签项 -->
      <el-tabs v-model="collectType" @tab-click="handleClick">
        <el-tab-pane label="全部" name="all" ></el-tab-pane>
        <el-tab-pane label="博客" name="article"></el-tab-pane>
        <el-tab-pane label="问答" name="qa"></el-tab-pane>
      </el-tabs>
      <ul>
        <li class="collect-list-item" v-for="(item,index) in userCollectRelList" :key="index">
          <a href="javascript:;">{{item.collectedName}}</a> 
          <span @click="cancelCollect(item.id,index)" class="svg-icon"><svg-icon iconClass="uc-collect" ></svg-icon></span>
        </li>
      </ul>
      
      <!-- 分页 -->
      <el-pagination
        v-if="pageInfo.total > 20 "
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pageInfo.pageNum"
        :page-sizes="[20, 30, 40, 50]"
        :page-size="pageInfo.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="pageInfo.total">
      </el-pagination>
    </div>
  </div>
  
  <!-- 创建收藏夹 -->
  <me-dialog :isHide="isHide" @clone="clone" title="创建收藏夹" :whetherShowLine="false">
    <el-form ref="createCollectRef" :model="createCollectform" :rules="createCollectRules" label-width="0px">
      <!-- 收藏夹名称 -->   
      <span class="create-co">名称</span>
      <el-form-item  prop="name" label-width="0px">
        <el-input class="font" v-model="createCollectform.name"></el-input>
      </el-form-item>
      <!-- 收藏夹描述 -->
      <span class="create-co">描述</span>
      <el-form-item >
        <el-input class="font " v-model="createCollectform.description" type="textarea" placeholder="简单介绍一下收藏夹吧!可以选填哦"></el-input>
      </el-form-item>
      <!-- 是否公开 -->
      <el-form-item> 
        <el-radio-group v-model="createCollectform.whetherPublic" size="medium">
          <el-radio label="1">公开 所有人可见</el-radio> 
          <el-radio label="0">
            私密 其他人将没有权限查看你的收藏夹
              <span style="color: red">(请谨慎操作)</span>
          </el-radio>
        </el-radio-group>
      </el-form-item>

        <el-form-item class="submit-btn">
          <el-button type="primary" @click="createCollectSubmit" :loading="createCollectLoading">创建</el-button>
          <el-button>重置</el-button>
      </el-form-item>
    </el-form>

  </me-dialog>
</div>
  
</template>

<script>
// api
import {saveCollect, getUserCollectMgtList,deleteUserCollectMgt,getCollectData,
      deleteUserCollect,updateUserCollectMgtApi} from "@/api/collect.js"
import MeDialog from "@/components/common/box/MeDialog.vue"
import {error,success,confirm} from "@/util/message"
export default {
  components: {
    MeDialog
  },
  
  created() {
    // 获取收藏夹列表
    this.getUserCollectMgtList()
  },
  mounted() {

    
  },
  data() {
    return {
      // 是否重新加载页面 用于获取收藏夹集合中的第一个收藏夹内容
      whetherLoadPage: true, 


      pageInfo: {
        pageNum: 1,
        pageSize: 20,
        total: 20
      },
      collectType: 'article',

      // 提交删除收藏夹加载中
      deleteCollectLoading: false,
      // 移动到的收藏夹名称
      moveToCollectName: '',
      // 是否展示收藏夹名字
      whetherShowCollectName: true,
      // 是否展示收藏夹的描述
      whetherShoweditCollectDec: true,
      // 收藏夹
      userCollectMgt: {
        //展示收藏夹的描述
        description: '',
        // 展示的收藏夹名字
        name: '',
        // 移动到其他收藏夹
        blogUserCollectMgt: {},
        //删除标签方式
        deleteCollectWay: "1",
      },
      deleteVisible: false,

      //删除标签方式
      deleteCollectWay: "1",

      // 收藏的数据
      userCollectRelList: [],
      // 激活的收藏item下标
      activeCollectIndex: 0,
      // 创建收藏夹加载中
      createCollectLoading: false,
      // 用于删除收藏夹展示的收藏夹 跟 collectMgtList 唯一区别就是没有当前要删除的收藏夹
      moveOtherCollectMgtList:[],
      // 收藏夹集合
      collectMgtList: [],
      // 创建收藏夹表单
      createCollectform: {
        name: "",
        description: "",
        whetherPublic: "1"
      },
      isHide: true,
      createCollectRules: {
        name: [
          { required: true, message: '请输入收藏夹名称', trigger: 'blur' },
          { min: 3, max:205, message: '长度在 3 到 20 个字符', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    /**
     * 页的大小改变所触发的事件
     */
    handleSizeChange(size) {

    },
    /**
     * 切换页
     */
    handleCurrentChange(current) {

    },

    /**
     * 标签切换事件
     */
    handleClick() {
      console.log(this.collectType);
    },
    /**
     * 取消收藏
     */
    cancelCollect(id,index) {
      confirm(this,'此操作将永久删除该收藏, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteUserCollect(id).then(res => {
          if (res.code == 200) {
            this.userCollectRelList.splice(index,1)
            success(this,"删除成功!")
          } else {
            error(this,res.msg)
          }
        })
      }).catch(() => {
        info(this,'已取消删除')    
      });
    },
    /**
     * 编辑收藏夹名字
     */
    editCollectName() {
      console.log("编辑editCollectName");
      this.whetherShowCollectName = false
    },
    /**
     * 编辑描述
     */
    editCollectDec() {
      this.whetherShoweditCollectDec = false
    },
    /**
     * 删除收藏夹
     */
    deleteUserCollectMgt() {
      console.log("删除收藏夹");
      this.moveOtherCollectMgtList = []
      // 去掉当前展示的收藏夹
      this.collectMgtList.forEach(value => {
        if(value.name !== this.userCollectMgt.name) {
          console.log(value.name);
          console.log(this.userCollectMgt.name);
          this.moveOtherCollectMgtList.push(value)
        }
      })
      this.deleteVisible = true
    },
    /**
     * 提交删除收藏夹
     */
    deleteCollectSumbit() {
      // 通过遍历获取到要移动到收藏夹对象
      let This = this
      this.deleteCollectLoading = true
      this.userCollectMgt.deleteCollectWay = this.deleteCollectWay
      this.collectMgtList.forEach(collectMgt => {
        if (collectMgt.name == this.moveToCollectName) {
          This.userCollectMgt.blogUserCollectMgt = collectMgt
        }
      }) 
      deleteUserCollectMgt(this.userCollectMgt).then(res => {
        this.deleteVisible = false
        this.deleteCollectLoading = false
        if (res.code == 200) {
          success(this,res.msg)
          // 删除数组中元素
          for(let index = 0; index < this.collectMgtList.length;index++) {
            if(this.collectMgtList[index].id == This.userCollectMgt.id) {
              this.collectMgtList.splice(index,1)
              // 将收藏夹集合的删除位置的下一个元素赋值给collect
              this.userCollectMgt = this.collectMgtList[index]
              // 获取收藏夹的数据
              this.activeCollectItem(this.collectMgtList[index],index)  
              break
            }
          }

        }
        else error(this,res.msg)
        
      })
      
    },

    /**
     * 取消收藏夹的删除
     */
    cancelDeleteCollectSubmit() {
      this.deleteVisible = false
      this.moveOtherCollectMgtList = []
    },
    /**
     * 确定编辑收藏夹名字
     */
    sureEditName() {
      this.whetherShowCollectName = true
      this.updateUserCollectMgtApi()
    },
    /**
     * 确定编辑描述
     */
    sureEditDec() {
      this.whetherShoweditCollectDec = true
      this.updateUserCollectMgtApi()
    },
    /**
     * 编辑收藏夹api
     */
    updateUserCollectMgtApi() {
      updateUserCollectMgtApi(this.userCollectMgt).then(res => {
        if (res.code != 200) error(this,res.msg)
      })
    },
    handleClose(done) {
      confirm(this,'确认关闭？','提示',{
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(_ => {
          this.moveOtherCollectMgtList =[]
          done();
        })
        .catch(_ => {});
    },

    /**
     * 获取收藏夹列表
     */
    getUserCollectMgtList() {
       getUserCollectMgtList().then(res=> {
         if (res.code != 200) {
           error(res.msg);
           return;
         } 
         this.collectMgtList = res.data
         // 将收藏夹集合中的第一个元素赋值给 colllect
         this.$nextTick(() => {
           this.userCollectMgt = this.collectMgtList[0]
           // 获取收藏夹内容，之后被执行一次用于获取收藏夹集合中的第一个收藏夹数据
            console.log("初始化页面获取收藏夹内容");
            if (this.whetherLoadPage) { 
              this.whetherLoadPage = false
              this.activeCollectItem(this.userCollectMgt,0)
            }
         })
       })
    },
    // 创建收藏夹
    createCollect() {
      this.isHide = false
    },
    /**
     * 关闭创建文件夹面板
     */
    clone() {
      this.isHide = true
    },
    /**
     * 创建收藏夹
     */
    createCollectSubmit() {
      this.createCollectLoading = true
      saveCollect(this.createCollectform).then(res => {
        if(res.code != 200) {
          error(this,res.msg)
        } else {
          success(this,res.msg)
          this.collectMgtList.push(this.createCollectform)
          this.createCollectform = {}
        }
         this.createCollectLoading = false
      })
    },
    /**
     * 激活的收藏夹事件
     */
    activeCollectItem(item,index) {
      console.log("获取收藏夹 " + item.name + "的数据");
      this.userCollectMgt = item
      this.activeCollectIndex = index
      // 获取该收藏下的数据
      getCollectData(item.id , this.collectType , this.pageInfo.pageNum , this.pageInfo.pageSize).then(res => {
        if (res.code != 200) {
          error(this,res.msg)
          return
        }
        this.pageInfo.total = res.data.total
        this.userCollectRelList = res.data.list
      })
    }
  }
}
</script>

<style lang="less" scoped>

@import "@/assets/less/font.less";

.uc-collect-left ul li ,
.uc-collect-left ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}

.uc-collect-left ul li a {
  text-decoration: none;
}

.uc-collect-left-item ,
.uc-create-collect-item{
  display: block;
  height: 65px;
  line-height: 65px;
  padding: 5px;
  padding-left: 5px;
  border-bottom: 1.5px solid #ededed;
  border-left: 4px solid #ffffff;
}

.uc-collect-left-item:hover {
  border-left: 4px solid #32e0c4;
  background-color: #f6f6f6;
}

.active-uc-collect-item {
  border-left: 4px solid #32e0c4;
  background-color: #f6f6f6;
}

.uc-collect {
  display: flex;
}
.uc-collect-left {
  height: 100%;
  width: 200px;
  border-right: 2px solid #e8e8e8;
  margin-right: 2px;
  // background-color: pink;
}

.uc-collect-right {
  flex: 1;
}


.el-form {
  margin-left: 10px;
  margin-right: 10px;
  // width: 420px;
}
.el-radio {
  display: block;
  margin-bottom: 20px;
}
.submit-btn {
  display: flex;
  flex-direction: row-reverse;
}


// 以下是头部样式
.co-right-list ul li ,
.co-right-list ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}

.el-input {
  // width: 360px !important;
  font-size: 14px;
}

// 创建收藏夹的属性样式
.create-co {
  display: block;
  padding-top: 10px;
  padding-bottom: 10px;
}

.collect-h {
  height: 25px;
}

.me-dialog {
  height: 500px !important;
}


.el-radio {
  margin-bottom: 20px;
}
// 收藏的编辑
.co-edit {
  display: flex;
  height: 25px;
  align-items: center;
}
.edit-collect {
  margin-left: 10px;
}

// 文字居中
.font-center {
  text-align: center;
  line-height: 30px;
}

// 画圆
.circle  {
  display: block;
  width: 30px !important;
  height: 30px !important;
  border-radius: 50%;
}

.sure {
  cursor: pointer;
  background-color: #61d4b3;
}

.cancel {
  cursor: pointer;
  background-color: #f64b3c;
}

// 编辑描述
.edit-co-dec {
  // width: 100%;
  display: flex;
}

.collect-input {
  width: 350px;
}

.dec-right-item {
  color: #e97171;
  text-decoration: none;
}
.dec-right-item:hover {
  color: #ff414d;
}

.co-right-header {
  margin: 5px;
  margin-top: 10px;
  flex-wrap: wrap;
  display: flex;
  padding-bottom: 20px;
  border-bottom: 1.5px solid #e8e8e8;
}
.co-right-header-up {
  margin-bottom: 20px;
  width: 100%;
}

.svg-icon {
  color: #999;
  cursor: pointer;
}
// .svg-icon:hover {
//   background-color: #ffffff;
// }

.co-right-header-down {
  display: flex;
  height: 25px;
  width: 100%;
  justify-content: space-between;
}
.collect-dec {
  height: 25px;
}
.collect-dec-right {
  display: flex;
}


//=================================== 收藏夹列表
.collect-dec-right ul li,
.collect-dec-right ul,
.co-right-list ul li ,
.co-right-list ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}


.co-right-list ul li a {
  color: #666;
  text-decoration: none;
}
.svg-icon {
  padding-right: 10px;
}
.collect-list-item {
  display: flex;
  justify-content: space-between;
  padding: 5px;
  font-size: 16px;
  height: 30px;
  line-height: 30px;
  border-radius: 5px;
  padding-left: 10px !important;
  margin-bottom: 10px !important;
  
  cursor: pointer;
  border: 1.5px solid #e8e8e8;
}
.collect-list-item:hover {
  box-shadow: 0px 8px 5px #e8e8e8;
}
.co-right-list {
  margin: 5px;
  margin-right: 5px;
  margin-top: 10px;
}

</style>