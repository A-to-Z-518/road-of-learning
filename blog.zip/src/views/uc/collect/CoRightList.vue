<template>
  
</template>

<script>
import {success,info,confirm} from "@/util/message"
export default {
  props: {
    /**
     * 收藏夹集合
     */
    collectList: {
      type: Array,
      default: function() {
        return [
          {id: '123',name: '标题1'},
          {id: '12233',name: '标题2'},
          {id: '12223',name: '标题3'},
          {id: '122323',name: '标题4'},
          {id: '14423',name: '标题5'},
          {id: '1213',name: '标6'},
        ]
      }
    }
  },
  data() {
    return {
      pageInfo: {
        pageNum: 1,
        pageSize: 20,
        total: 20
      },
      activeName: 'first',
    }
  },
  methods: {
    
  }
}
</script>

<style lang="less" scoped>
ul li ,
ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}


a {
  color: #666;
  text-decoration: none;
}

.svg-icon {
  padding-right: 10px;
}
.collect-list-item {
  display: flex;
  justify-content: space-between;
  padding: 5px;
  font-size: 16px;
  border-radius: 5px;
  margin-bottom: 10px;
  
  cursor: pointer;
  border: 1.5px solid #e8e8e8;
}
.collect-list-item:hover {
  box-shadow: 0px 8px 5px #e8e8e8;
}
.co-right-list {
  margin: 5px;
  margin-right: 5px;
  margin-top: 10px;
}
</style>