<template>
  <div class="home">
    <!-- 头部 -->
    <navbar :isVisible="isVisible" @search-query="searchQuery"></navbar>

    <home-layout>
      <template v-slot:home-layout-left> 
        <tag :tagList="tagList" ref="left" @select-tag="selectTag"></tag>
      </template>

      <!-- 中间 -->
      <template v-slot:home-layout-center> 
        <home-center
          :articleList="articleList" 
          :scollEnd="scollEnd" 
          :pageNum="pageNum"
          @onload="onload"
        ></home-center>
      </template>
      <!-- 右侧 -->
      <template v-slot:home-layout-right> 
        <home-right ref="right"></home-right>
      </template>
    </home-layout>
    <back-top></back-top>
  </div>
</template>

<script>
import BackTop from "@/components/common/top/BackTop.vue"
import Scroll from "@/components/common/scroll/Scroll.vue"

import Navbar from "@/components/common/nav/Navbar"

import HomeLayout from "@/components/common/layout/HomeLayout.vue"


import Tag from "./child/Tag"
import HomeCenter from "./child/HomeCenter"
import HomeRight from "./child/HomeRight"

import Test from "./child/Test"

import {findAllNavTag} from "@/api/home.js"

import {searchByTag} from "@/api/search"

import {error} from "@/util/message"

export default {
  name: "首页",
  components: {
    Navbar,Scroll,
    Tag,HomeCenter,HomeRight,Test,HomeLayout,BackTop 
  },
  data() {
    return {
      // 是否加载博客完成,只有加载完成了滚动才会获取数据
      isLoadArticleDataFini: false,
      // 当前侧边栏选中的标签
      activeTag: "推荐",

      i: 0,
      // true 显示导航栏 false不显示导航栏
      isVisible: true,
      // 当前选择的分类下标
      activeSortIndex: 0,
      bannerList: [
      ],
      // 受欢迎的作者
      popularAuthorsList: [
        
      ],
      // 今日推荐，博文
      recomToday: [
        

      ],
      // 分类列表
      tagList: [
        {id: "1",name: "推荐"}
      ],

      // 第几页
      pageNum: 1,
      articleList: [],
      scollEnd: false,
    }
  },
  mounted() {
    /**
     * 初始化main
     * 传入一个对象，left right 属性表示左侧容器，右侧容器的高度
     */
    console.log(this.$refs.left.$el.offsetHeight);
    // this.findHomeArticleByPage(this.pageNum)
    this.searchArticle(this.pageNum,this.activeTag,true)
  },
  created() {
    console.log("查询标签");
    findAllNavTag().then(res => {
      if(res.code == 200) 
        console.log(res);
        // 合并两个数组
        this.tagList.push.apply(this.tagList,res.data)
    })
  },

  methods: {
    /**
     * 选中的标签
     */
    selectTag(name) {
      console.log("选中的标签");
      this.activeTag = name
      this.pageNum = 1
      this.articleList = []
      this.searchArticle(this.pageNum,this.activeTag,true)
    },
    
    onload() {
      if (this.isLoadArticleDataFini) this.searchArticle(this.pageNum++,this.activeTag,false)
      // this.findHomeArticleByPage(this.pageNum++)
    },

    /**
     * 搜索文章
     */
    searchArticle(pageNum,name,isReInitMain) {
      console.log("===================================");
      searchByTag(pageNum,name).then(res => {
        
        if (res.code == 200 ) {
          console.log(res);
          this.articleList.push.apply(this.articleList,res.data.list)
          if (res.data.lastPage) this.scollEnd = true
          this.isLoadArticleDataFini = true
          
        } else {
          error(this,res.msg)
        }
      }) 
    },
    searchQuery(query) {
      let { href } = this.$router.resolve({
        path: '/search',
        query: {
          q: query
        }
      });
      window.open(href);   
    },
    // 跳转路由 this.$store.commit("addCounter",counter)
    toAuthorPage(userId) {
      console.log("跳转路由");
      this.$store.commit("submitUserId",userId)
      // 开始跳转路由,这会到开一个新页面
      let { href } = this.$router.resolve({
        path: '/author',
        query: {
          userId: userId
        }
      });
      window.open(href);   
    },

    scrollEvent(scroll) {
      let scrollHeight = parseInt(scroll)
      // 下滑
      // this.scrollResult = scroll - this.i
      if(scrollHeight > 100) {
        if (scrollHeight < this.i) {
          this.isVisible = true
          // console.log("正在向上滑动 打开………………………………" + scrollTop );
        } else if(scrollHeight > this.i + 20) {
          this.isVisible = false
          // console.log("正在向下滑动 关闭————————————" + scrollTop );
        }
        this.i = scroll
      }
      
    }
  }
}
</script>

<style lang="less" scoped>
@import "@/assets/less/style.less";
@import "@/assets/less/navbar.less";

// 分类侧边栏宽度
@sortSide: 120px;
// 分类栏每个item高度
@sortItemHeight: 30px;

// ================================= 版心部分

.home {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
}

.main {
  // display: flex;
  transition: all .2s;
  // 设置宽度
  width: 1200px; 
  margin: 70px auto;
}

.home-layout {
  margin-top: 70px;
}


.left {
  // float: left;
  height: 600px;
  background-color: red;
}

.center {
  height: 3000px;
  background-color: pink;
}

.right {
  height: 1000px;
  background-color: pink;
}












span:hover {
  color: #66B1FF;
}


.sort-list li {
  width: @sortSide;
  height: @sortItemHeight;
  line-height: @sortItemHeight;
  margin: 5px auto;
  border-radius: 5%;
  cursor: pointer;
  padding-left: 5px;
  background-color: #fff;
}

.sort-list li:hover {
  background-color: #66B1FF;
}
// 分类栏

.article-sort-side-bottom {
  width: @sortSide;
  margin-right: 5px;
  padding: 5px;
}

.article-sort-side {
  position: fixed;
  transition: all .5s;
  top: 65px;
  background-color: #ffffff;
  z-index: 7000;
}



// 激活的分类样式
.active-sort {
  background-color: #66B1FF !important;
}


// 轮播图区域
.banner {
  height: 500px;
  margin-bottom: 20px;
  background-color: #ffffff;
}

// 文章列表
.m-article-list {
  width: 790px;
  padding: 5px;
  margin-right: 10px;
  background-color: #ffffff;
}

// 文章列表右侧部分
.right_box {
  width: 250px;
  padding-top: 5px;
}


// 热门作者
.popular-authors,
.recom-today {
  padding: 5px;
  background-color:#ffffff;
}

.recom-today {
  margin-top: 20px;
}



// 作者列表
.authors-list {
  display: flex;
  height: 50px;
  margin: 10px auto;
}

// 用户头像
.user-info-avatar {
  height: 48px;
  width: 48px;
  cursor: pointer;
}

.user-info-avatar img {
  height: 48px;
  width: 48px;
  background-color: #ffffff;
  border-radius: 50%;
  border: 2px solid #ffffff;
}

.home-right-user-info {
  flex: 1px;
  margin-left: 15px;
  background-color: #ffffff;
  cursor: pointer;
}

.home-right-user-info span {
  display: block; 
  height: 48px;
  line-height: 48px;
  font-weight: 550;
}



// 今日推荐 item
.recom-today-item {
  display: flex;
  height: 50px;
  margin: 10px auto;
  cursor: pointer;
}

.recom-today-item .images img{
  width: 50px;
  height: 50px;
}

.recom-today-item .images img {
  border-radius: 20%
}

.article-title {
  // 目的垂直居中h标签
  display:flex;
  align-items: center;
  justify-content: center;
  height: 50px;  
  margin-left: 5px;
  color: #738a94;
  font-size: 12px;
}
.article-title h3 a {
  
  color: #738a94;
}

.article-title h3 a:hover {
  color: #00bcd4;
}

.article-title h3{
  display:block;
  overflow : hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2 ;      /* 可以显示的行数，超出部分用...表示*/
  -webkit-box-orient: vertical;
}


</style>