<template>
  <!-- 文章列表 -->
  <div class="me">
    我是中间部分
    <!-- 轮播图区域 -->
    <!-- <my-swiper class="banner" :bannerList="bannerList"></my-swiper>  
    <article-list></article-list> -->
  </div>
</template>

<script>
import MySwiper from "@/components/common/swiper/MySwiper"
import ArticleList from "@/components/common/article/ArticleList"
export default {
  props: {
    bannerList: {
      type: Array,
      default: function() {
        return [
          {imageUrl: "https://p.upyun.com/docs/cloud/demo.jpg"},
          {imageUrl: "https://cdn.pixabay.com/photo/2020/08/21/16/05/squirrel-5506514_1280.jpg"},
          {imageUrl: "https://p.upyun.com/docs/cloud/demo.jpg"},
          {imageUrl: "https://cdn.pixabay.com/photo/2020/08/14/13/57/cat-5488070__340.jpg"},
          {imageUrl: "http://n.sinaimg.cn/sinacn20190803s/0/w2048h1152/20190803/fb63-iatixpk7883072.jpg"}
        ]
      }
    }
  },
  components: {
    MySwiper,ArticleList
  }
}
</script>

<style lang="less" scoped>

// 文章列表
.me {
  // width: 100%;
  // padding: 5px;
  height: 2000px;
  
  background-color:red;
}
</style>