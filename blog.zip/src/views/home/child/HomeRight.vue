<template>
  <div class="home-right"> 
    <!-- 展示热门推荐作者 -->
    <border-box class="popular-authors" title="热门作者推荐"> 
      <ul>
        <li v-for="(item , index) in popularAuthorsList" :key="index">  
          <div class="authors-list">
            <!-- 右侧头像 -->
            <div class="user-info-avatar">
              <router-link tag="a" target="_blank" :to="'/author/' + item.id" >
                <img :src="item.avatar" alt="">
              </router-link>
            </div>
            <!-- 右侧 -->
            <!-- 用户名以及其他 -->
            <div class="right-user-info">
              <span class="popular-authors-title" @click="toAuthorPage(item.id)">
                {{item.usernick}}
              </span>
            </div>
          </div>
          <divided v-if="index !== popularAuthorsList.length -1"></divided>
        </li>
      </ul>    
    </border-box>
    <!-- 展示今日推荐 -->
    <border-box class="recom-today" title="今日推荐">
      <ul>
        <li v-for="(item , index) in recomTodayList" :key="index"> 
          <div class="recom-today-item">
            <!-- 左侧文章配图 -->
            <div class="images">
              <router-link tag="a" target="_blank" to="#" >
                <img :src="item.imageUrl" alt="">
              </router-link>
            </div>
            <!-- 右侧文章标题 -->
            <div class="article-title">
              <h3><router-link tag="a"  target="_blank" :to="'/article/details/' + item.id" >{{item.title}}</router-link></h3>
            </div>
          </div>
        </li>
      </ul>
    </border-box>
    <!-- 备案信息框 -->
    <beian-box></beian-box>
  </div>
</template>

<script>
import Divided from "@/components/common/divided/Divided"
import BorderBox from "@/components/common/box/BorderBox.vue"

import BeianBox from "./BeianBox"
import {recommendUser} from "@/api/user"
import {recommendArticle} from "@/api/article"
export default {
  components: {
    BorderBox,Divided,BeianBox
  },
  props: {
  
  },
  created() {
    this.recommendUser()
    this.recommendArticle()
  },
  data() {
    return {
      popularAuthorsList: [
        // {id: "1" , avatar: "https://img.best73.com/20200205/13012486152631.jpg",usernick: "七喜先生"},
        // {id: "2" , avatar: "https://img.best73.com/20200205/13012486152631.jpg",usernick: "全幼儿园最可爱"},
      ],
      // 推荐的文章
      recomTodayList: [
        // {id: "",title: "表格中的数字表示支持该属性的第一个浏览器的版本号" , imageUrl: "https://static.veer.com/veer/static/resources/keyword/2020-02-19/533ed30de651499da1c463bca44b6d60.jpg"},
        // {id: "",title: "表格中的数字表示支持该属性的第一个浏览器的版本号" , imageUrl: "https://static.veer.com/veer/static/resources/keyword/2020-02-19/533ed30de651499da1c463bca44b6d60.jpg"},
        // {id: "",title: "表格中的数字表示支持该属性的第一个浏览器的版本号" , imageUrl: "https://static.veer.com/veer/static/resources/keyword/2020-02-19/533ed30de651499da1c463bca44b6d60.jpg"},
      ]
    }
  },
  methods: {
    // 跳转路由 this.$store.commit("addCounter",counter)
    toAuthorPage(userId) {
      // console.log("跳转路由");
      // 开始跳转路由,这会到开一个新页面
      let { href } = this.$router.resolve({
        path: '/author',
        query: {
          userId: userId
        }
      });
      window.open(href);   
    },
    /**
     * 获取推荐的作者
     */
    recommendUser() {
      recommendUser().then(res => {
        console.log(res);
        if (res.code != 200) {
          console.log("获取受欢迎的作者失败");
          return
        }
        this.popularAuthorsList = res.data
      })
    },
    /**
     * 获取推荐的文章
     */
    recommendArticle() {
      recommendArticle().then(res => {
        console.log(res);
        if (res.code != 200) {
          console.log("获取推荐的文章失败");
          return
        }
        this.recomTodayList = res.data
      })
    }
  }
  
}
</script>

<style lang="less" scoped>

a {
  text-decoration: none;
}
ul li ,
ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}
/* 当鼠标经过的时候显示颜色 */
// a:hover {
//   color: 
// }
span:hover {
  color: #00bcd4;
}

// 文章列表右侧部分
.home-right {
  width: 100%;
  padding-top: 5px;
}


// 热门作者
.popular-authors,
.recom-today {
  padding: 5px;
  background-color:#ffffff;
}

.recom-today {
  margin-top: 20px;
}

// 作者列表
.authors-list {
  display: flex;
  height: 50px;
  margin: 10px auto;
}

// 用户头像
.user-info-avatar {
  height: 48px;
  width: 48px;
  cursor: pointer;
}

.user-info-avatar img {
  height: 48px;
  width: 48px;
  background-color: #ffffff;
  border-radius: 50%;
  border: 2px solid #ffffff;
}

.right-user-info {
  flex: 1px;
  margin-left: 15px;
  background-color: #ffffff;
  cursor: pointer;
}

.right-user-info span {
  display: block; 
  height: 48px;
  line-height: 48px;
  font-weight: 550;
}



// 今日推荐 item
.recom-today-item {
  display: flex;
  height: 50px;
  margin: 10px auto;
  cursor: pointer;
}

.recom-today-item .images img{
  width: 50px;
  height: 50px;
}

.recom-today-item .images img {
  border-radius: 20%
}

.article-title {
  // 目的垂直居中h标签
  display:flex;
  align-items: center;
  justify-content: center;
  height: 50px;  
  margin-left: 5px;
  color: #1a1c20;
  font-size: 12px;
}
.article-title h3 a {
  
  color: #1a1c20;
}

.article-title h3 a:hover {
  color: #00bcd4;
}

.article-title h3{
  display:block;
  overflow : hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2 ;      /* 可以显示的行数，超出部分用...表示*/
  -webkit-box-orient: vertical;
}


</style>