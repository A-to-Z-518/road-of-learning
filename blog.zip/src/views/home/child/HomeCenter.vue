<template>
  <!-- 文章列表 -->
  <div class="me-article-list">
    <!-- 轮播图区域 -->
    <my-swiper class="banner" :bannerList="bannerList"></my-swiper>  
    <article-list 
      :articleList="articleList" 
      :scollEnd="scollEnd" 
      :pageNum="pageNum"
      @onload="onload"></article-list>
  </div>
</template>

<script>
import MySwiper from "@/components/common/swiper/MySwiper"
import ArticleList from "@/components/common/article/ArticleList"


export default {
  props: {
    scollEnd: {
      type: Boolean,
      default: false
    },
    // 第几页
    pageNum: {
      type: Number,
      default: 1
    },
    articleList: {
      type: Object,
      default: function() {
        return [
          {
            id: "1263012551591985152",
            title:"标题",
            content: " 摘要：针对于List的size比较大，使用多线程处理任务时，可以将List分割为一个一个比较小的任务单元进行处理。 例如集合大小：645，按照100分割，会将集合分割为6个size为100的集合和一个size为45的集合，方便配合多线程处理。 实现代码如下： 输出结果：",
            createTime: "2020-06-01",
            likes: 12312,
            views: 12312,
            usernick: "光阳",
            userAvatar: "https://s1.ax1x.com/2020/06/01/t87aeU.png"
          
          },
        ]
      }
    },
    bannerList: {
      type: Array,
      default: function() {
        return [
          {imageUrl: "https://p.upyun.com/docs/cloud/demo.jpg"},
          {imageUrl: "https://cdn.pixabay.com/photo/2020/08/21/16/05/squirrel-5506514_1280.jpg"},
          {imageUrl: "https://p.upyun.com/docs/cloud/demo.jpg"},
          {imageUrl: "https://cdn.pixabay.com/photo/2020/08/14/13/57/cat-5488070__340.jpg"},
          {imageUrl: "http://n.sinaimg.cn/sinacn20190803s/0/w2048h1152/20190803/fb63-iatixpk7883072.jpg"}
        ]
      }
    }
  },
  data() {
    return {
      articleList: []
    }
  },
  methods: {
    onload() {
      this.$emit("onload")
    }
  },
  components: {
    MySwiper,ArticleList
  }
}
</script>

<style lang="less" scoped>

// 文章列表
.me-article-list {
  // padding: 5px;
  background-color: #fff;
}
</style>