<template>
  <div class="sort">
    <nav>
      <ul class="sort-list">

        <li v-for="(item,index) in tagList" 
        :key="index" 
        :class="{'active-sort': index === activeSortIndex}"
        @click="activeTag(index,item)">
          <span>{{item.name}}</span>
        </li>
      </ul>
      <span class="more">
        <a href="javascript:;">更多标签</a>
      </span>
    </nav>
    
  </div>
</template>

<script>
export default {
  props: {
    // 分类列表
    tagList: {
      type: Array,
      default: function() {
        return [
          {id: "1",name: "推荐"},
          {id: "2",name: "后端"},
          {id: "3",name: "前端"},
          {id: "4",name: "大数据"},
          {id: "5",name: "操作系统"},
          {id: "6",name: "互联网工具"},
          {id: "7",name: "分布式框架技术"}
        ]
      }
    }
  },
  data(){
    return {
      activeSortIndex: 0
    }
  },
  methods: {
    activeTag(index,item) {
      console.log(item.name);
      this.activeSortIndex = index
      this.$emit('select-tag',item.name)
    }
  }
}
</script>

<style lang="less" scoped>

@import "@/assets/less/font.less";

// 分类栏每个item高度
@sortItemHeight: 30px;

a {
  text-decoration: none;
}
ul li ,
ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}


.more {
  display: block;
  padding-left: 0.2rem;
}

.more a {
  color: #3282b8;
}

a:hover {
  color: #8fcfd1;
}

.sort {
  padding: 0.2rem;
  padding-bottom: 0.5rem;
  background-color: #fff;
}

.sort-list li {
  width: 100%;
  line-height: @sortItemHeight;
  margin: 5px auto;
  border-radius: 5%;
  cursor: pointer;
  padding-right: -5px;
  border-radius: 4%;
  background-color: #fff;
}

.sort-list li span {
  display: block;
  padding-left: 5px;
}

.sort-list li:hover {
  background-color: #66B1FF;
}

// 激活的分类样式
.active-sort {
  background-color: #66B1FF !important;
}


</style>