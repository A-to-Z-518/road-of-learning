<template>
<!-- 备案信息框 -->
  <border-box class="beian" :isActiveTitle="false"> 
    <span>公安备案号 吉ICP备19007696号-2</span>
    <span>公安备案号</span>
  </border-box>
</template>

<script>
import BorderBox from "@/components/common/box/BorderBox.vue"
export default {
  components: {
    BorderBox
  }
}
</script>

<style lang="less" scoped>
.beian {
  padding: 0px 10px 5px 10px;
  margin-top: 10px !important;
  background-color: #fff !important;
}

span {
  color: #666;
  padding-bottom: 5px;
  display: block;
}
</style>