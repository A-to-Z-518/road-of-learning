<template>
  <div class="detail-center">
    <div class="detail-center-header">
      <div class="header-left">
        <router-link :to="goUserPageLink + '?userId=' +  article.userId" >
          <avatar :url="article.userAvatar" width="50px" height="50px"></avatar>
        </router-link>
        <!-- 用户info -->
        <div class="user-info">
          <span><router-link :to="goUserPageLink + '?userId=' + article.userId" >{{article.usernick}}</router-link></span>
          <span>发布于 {{article.createTime | dateFilter}}</span>
        </div>
      </div>
      <a :href="'/article/edit/' + article.id" target="_blank" v-if="article.isShowEdit" class="edit" >编辑</a>
    </div>

    
    <div class="font-color st" >
      <!-- 分类 -->
      <div class="st-item">
        <span class="font-h">分类</span> 
        <span class="sort-item">
          <a href="javascript:;" class="article-st">{{article.sortName}}</a>
        </span>
        
      </div>
      <!-- 标签 -->
      <div class="st-item">
        <span class="font-h">标签</span>
        <span class="tag-item" v-for="(item,index) in tagList" :key="index">
          <a href="javascript:;" class="article-st" >{{item}}</a>
        </span>
        
      </div>
    </div>
    
    <span class="title"><h1>{{article.title}}</h1></span>
  </div>
</template>

<script>


import {findArticleById} from "@/api/article"

import Avatar from "@/components/common/avatar/Avatar.vue"
export default {
  components: {
    Avatar
  },
  props: {
    tagList: {
      type: Array,
      default: function() {
        return []
      }
    },
    currentUserInfo: {
      type: Object,
      default: function() {
        return {}
      }
    },
    article: {
      type: Object
    }
  },
  data() {
    return {
      goUserPageLink: "/author/article",
    }
  },
  created() {
    
  },
  // destroyed () {
  //   this.clipboard.destroy()
  // },
  mounted() {

  },
  methods: {
    
  }
}
</script>

<style lang="less" scoped>

@import "@/assets/less/font.less";


.title {
  display: block;
  text-align: center;
}


a {
  text-decoration: none;
  color: #999;
}

/* 当鼠标经过的时候显示颜色 */
a:hover {
  color: #00bcd4;
}

.font-h {
  height: 2rem;
  line-height: 2rem;
  text-align: center !important;
}

ul li ,
ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}
.detail-center {
  background-color: #fff;
}
.detail-center-header {
  display: flex;
  justify-content: space-between;
  padding: 10px;
}

.avatar {
  cursor: pointer;
}

.st {
  display: flex !important;
}

.st-item {
  display: flex;
  align-self: center;
  margin-left: 20px;
  height: 30px;
  font-size: 14px;
}



.edit,
.article-st {
  display: block;
  border-radius: 0.25rem;
  margin: 2px;
  margin-left: 10px;
  line-height: 26px;
  font-size: 0.9rem;
  font-weight: 600px;
  background-color: #cffffe;
  color: #00bcd4  ;
}

.article-st .sort-item ,
.article-st .tag-item {
  display: block;
  margin: 0px 50px;
}

.edit:hover,
.article-st:hover {
  background-color: #7fdbda;
  color: #318fb5;
}

.detail-center-header span {
  display: block;
  margin-top: 2px;
  cursor: pointer;
  color: #999;
}

.header-left {
  display: flex;
}

.user-info {
  
  display: flex;
  flex-direction: column;
  margin-left: 10px;
  
}

</style>