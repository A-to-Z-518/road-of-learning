<template>
  <div class="detail-center-bottom">
    <div class="detail-bottom-info">
      <span>阅读 {{viewCount}}</span>
      <span>更新于 {{updateTime | dateFilter}}</span>
    </div>

    <div class="detail-bottom-btn">
      <ul>
        <!-- 点赞 -->
        <li :class="{'active-btn-like': likeEventMark}" @click="activeBtn('点赞')">
          <a href="javascript:;" class="bottom-item">
            <svg-icon icon-class="like" class="detail-svg"></svg-icon>
            <span>点赞</span>
            <span class="bottom-item-mark">{{likeCount}}</span>
          </a>
        </li>

        <!-- 收藏 -->
        <li :class="{'active-collect-btn': collectEventMark}" @click="activeBtn('收藏')">
          <a href="javascript:;" class="bottom-item">
            <svg-icon icon-class="favorites" class="detail-svg"></svg-icon>
            <span>收藏</span>
            <span class="bottom-item-mark">213</span>
          </a>
        </li>

        <!-- 赞赏 -->
        <li >
          <a href="javascript:;" class="bottom-item">
            <svg-icon icon-class="money" class="detail-svg"></svg-icon>
            <span>赞赏</span>
          </a>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import MeButton from "@/components/common/button/MeButton.vue"
export default {
  components: {
    MeButton
  },
  props: {
    // 点赞数量
    likeCount: {
      type: Number,
      default: 0
    },
    // 收藏数量
    collectCount: {
      type: Number,
      default: 0
    },
    // 访问数量
    viewCount: {
      type: Number,
      default: 0
    },
    // 更新于
    updateTime: {
      type: Number,
      default: 0
    },
    likeEventMark: {
      type: Boolean,
      default: false
    },
    collectEventMark: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      isCollect: false,
      isLike: false
    }
  },
  methods: {
    activeBtn(val) {
      console.log(val);
      this.$emit('activeBtn',val)
    }
  }
}
</script>

<style lang="less" scoped>

ul li ,
ul {
  display: flex;
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}

ul li {
  position: relative;
}

.bottom-item{
  display: block;
  display: flex;
  height: 35px;/*设置按钮高度*/
  color:#1b262c;/*字体颜色*/
  background-color:#eeeeee;/*按钮背景颜色*/
  border-radius: 3px;/*让按钮变得圆滑一点*/
  border-width: 0;/*消去按钮丑的边框*/
  margin: 0;
  outline: none;/*取消轮廓*/
  font-family: KaiTi;/*字体设置为楷体*/
  font-size: 18px;/*设置字体大小*/
  text-align: center;/*字体居中*/
  cursor: pointer;/*设置鼠标箭头手势*/
  padding: 2px 10px;
  margin-right: 10px;
}
.bottom-item:hover{/*鼠标移动时的颜色变化*/
  background-color: #2fc4b2;
}

a {
  text-align: center;
  height: 35px;/*设置按钮高度*/
  line-height: 35px;
  text-decoration: none;
}
a:hover {
  color:#1b262c;/*字体颜色*/
}

.bottom-item span {
  display: block;
  margin-left: 5px;
}

.bottom-item-mark {
  margin-top: -8px;
  color: #555666;
  // width: 20px;
  height: 20px;
  font-size: 14px;
}

.detail-center-bottom {
  display: flex;
  // justify-content:center;(内容水平居中)  
  justify-content: center;
  flex-wrap: wrap;
  margin: 20px auto;
  margin-left: 10px;
  margin-right: 10px;
  padding-bottom: 20px;
}

.detail-bottom-info {
  color: #999;
  width: 100%;
  span {
    padding-right: 1rem;
  }
}
// 按钮
.detail-bottom-btn {
  margin-top: 3rem;
  display: flex;
}

.el-button {
  padding: 0.6rem !important;
  font-size: 18px;
}

.detail-svg {
  margin: auto 0;
}

.active-btn {
  color: #ea907a;
}

.active-collect-btn,
.active-btn-like{
  a,span,.detail-svg{
    color: #e94560 !important;
  }
  
}
</style>