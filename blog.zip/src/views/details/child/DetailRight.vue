<template>
  <div class="detail-right">
    
  </div>
</template>

<script>

export default {

}
</script>

<style lang="less" scoped>
.detail-right {
  height: 500px;
  border-radius: 0.4em;
  background-color: red;
}
</style>