<template>
  <div class="detail-left" ref="detailLeftRef">
    <span class="like" @click="like"><svg-icon  :icon-class="isActiveLove ? 'loveActive' : 'love'" class-name="icon-like active" ></svg-icon></span>
    <span class="comment"><svg-icon icon-class="detailComment" class-name="icon-comment" ></svg-icon></span>
  </div>
</template>

<script>

export default {
  props: {
    isActiveLove: {
      // 是否激活爱心
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      
    }
  },
  methods: {

    like() {
      // 向上抛出点赞事件
      this.$emit('likeHandle')
    }
  }
}
</script>

<style lang="less" scoped>
.detail-left {
  padding-top: 130px;  
  border-radius: 0.4em;
  background-color: #F5F6F7;
  // background-color: red !important;
}
span {
  position: relative;
  width:40px;
  height:40px;
  left: 105px;
  display: block;
  border-radius: 50%;
  line-height: 50px;
  text-align:center;
  // 阴影
  box-shadow: rgba(0,0,0,0.3) 2px 3px 2px;  //让边框带有阴影
  cursor: pointer;
  background-color: #fff;
  
  
}

.svg-icon {
  margin: 2px;
}

.like {
  top: 20px;
  
  // background-color: pink;
}
.comment {
  top: 40px;
}

.like:hover {
  top: 15px;
  transition: all .8s;
}
.comment:hover {
  top: 35px;
  transition: all .8s;
}

.icon-comment {
  width: 1.4em !important;
  height: 1.4em !important;
  vertical-align: -0.2em !important;
}

.icon-like  {
  width: 1.2em !important;
  height: 1.2em !important;
  vertical-align: -0.1em !important;
}

.message {
  width: 50px !important;
}
</style>