<template>
  <me-dialog :isHide="isHide" title="收藏" :whetherShowLine="false" @clone="clone">
    <el-radio-group v-model="checkedCollect">
      <el-radio  v-for="item in collectList" :label="item.name" :key="item.id">{{item.name}}</el-radio>
    </el-radio-group>

    <el-input
      placeholder="创建收藏夹"
      v-model="createCollect.name"
      clearable>
      <el-button slot="append" type="success" @click="createCollectSumbit" :loading="ccSubmitLoading">新建</el-button>
    </el-input>
    <span class="collect-sumbit">
      <el-button  type="primary" round @click="startCollect">收藏</el-button>
    </span>
     
  </me-dialog>
    
</template>

<script>
import {userTokenName,userInfoName} from "@/util/const.js"
import MeDialog from "@/components/common/box/MeDialog.vue"
import {saveCollect,findUserCollectMgtList} from "@/api/collect"
import {error,success} from "@/util/message.js"
export default {
  components: {
    MeDialog
  },
  props: {
    isHide: {
      type: Boolean,
      default: false
    },
    // 选中的收藏夹
    checkedCollect: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      // 创建收藏夹提交中
      ccSubmitLoading:false,
      // 创建收藏夹所提交的数据
      createCollect: {
        name: ''
      },
      collectList: []
    }
  },
  created() {
    this.getAllCollectList()
  },
  watch: {
    
    // 修改收藏夹
    checkedCollect: function(val) {
      this.$emit('updateCollect',val)
    }
  },
  methods: {
    /**
     * 收藏成功
     */
    startCollect() {
      let selectCollect = {}
      // 查询到收藏夹对象
      console.log(this.checkedCollect);
      console.log(this.collectList);
      for (let i = 0; i < this.collectList.length;i++) {
        if (this.collectList[i].name == this.checkedCollect) {
          selectCollect = this.collectList[i]
          break
        }
      }
      this.$emit('startCollect',selectCollect)
    },
    clone() {
      this.$emit('clone')
    },
    /**
     * 获取全部收藏夹
     */
    getAllCollectList() {
      // 如果获取到的token为空就直接返回
      let token = this.getToken();
      if (token == null || token == undefined) 
        return
      findUserCollectMgtList().then(res => {
        if (res.code == 1004) return
        if (res.code != 200) {
          error(this,res.msg)
        } else {
          this.collectList = res.data
        }
      })
    },

     /**
     * 获取token
     */
    getToken() {
      let token = this.$cookies.get(userTokenName)
      return token
    },

    /**
     * 创建收藏夹提交
     */
    createCollectSumbit() {
      saveCollect(this.createCollect).then(res => {
        console.log(res);
        if (res.code != 200) {
          error(this,res.msg)
        } else {
          success(this,res.msg)
          this.collectList.push(res.data)
        }
        this.ccSubmitLoading = false
      })
      console.log("创建文件夹");
    }
  }
}
</script>

<style lang="less" scoped>
.el-select {
  width: 100%;
  margin-bottom: 50px;
}

.el-radio {
  width: 400px;
  font-size: 16px;
  margin: 10px;
}

.el-radio-group {
  margin-bottom: 20px;
}

.detail-collect-span {
  color: #290001;
  margin-right: 10px;
}

.collect-sumbit {
  display: block;
  margin-top: 20px;
  display: flex;
  justify-content: center;
}
</style>