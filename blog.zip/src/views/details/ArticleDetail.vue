<template>
<!-- 文章详情页面 -->
  <div class="article-detail">
    <!-- 头部 -->
    <scroll @scroll-event="scrollEvent">
      <navbar :isVisible="isVisible" @search-query="searchQuery" ref="navbar"></navbar>
    </scroll>
    <article-show-layout :article="article.contentMd" :tocTop="tocTop">
      <template v-slot:left> 
        <detail-left ref="leftRef" @likeHandle="leftLikeHandle" :isActiveLove="aroundInfo.likeEventMark" style="background-color: #F5F6F7;"></detail-left>
      </template>

      <!-- 中间 -->
      <template v-slot:center-header> 
        <detail-center :tagList="tagList" :currentUserInfo="currentUserInfo" :article="article" 
        @get-article-end="getArticleEnd"></detail-center>
      </template>
      <template v-slot:center-bottom> 
        <detail-center-bottom 
          :viewCount="article.viewCount" :updateTime="article.updateTime"
          :likeCount="article.likeCount"
          :likeEventMark="aroundInfo.likeEventMark" :collectEventMark="aroundInfo.collectEventMark"
          @activeBtn="activeBtn"></detail-center-bottom>
      </template>
    </article-show-layout>
    <!-- 返回顶部 -->
    <back-top></back-top> 

    <!-- 登录面板 -->
    <login-main :isHide="isHideLoginBox" @clone="lrbClone" @login="login"
      :loginLoading="loginLoading" :errorMeg="errorMeg">
    </login-main>

    <!-- 收藏面板 -->
    <detail-collect @clone="collectClone" :isHide="isHideCollect" 
    @startCollect="startCollect" :checkedCollect="checkedCollect" ref="DetailCollect"> </detail-collect>
  </div>
</template>

<script>
import Navbar from "@/components/common/nav/Navbar"
import Scroll from "@/components/common/scroll/Scroll.vue"

import MeMain from "@/components/common/layout/main/MeMain.vue"

import DetailLeft from "./child/DetailLeft"
import DetailRight from "./child/DetailRight"
import DetailCenter from "./child/DetailCenter"
import DetailCenterBottom from "./child/DetailCenterBottom"
import DetailCollect from "./child/DetailCollect"

import ArticleShowLayout from "@/components/common/layout/ArticleShow/ArticleShowLayout.vue"

import {findArticleById} from "@/api/article"

import BackTop from "@/components/common/top/BackTop.vue"
import LoginMain from "@/components/content/login/LoginMain.vue"

import {userTokenName,userInfoName} from "@/util/const.js"

import {login,getPublicKey} from "@/api/user.js"
import {like,likeStatus} from "@/api/article.js"
import {collectArticle,getUserArticleCollect} from "@/api/collect"

import {encryptedData} from "@/util/jsencrypt-util"
import {error,success} from "@/util/message.js"
export default {
  components: {
    Navbar,Scroll,MeMain,
    DetailLeft,DetailRight,DetailCenter,ArticleShowLayout,BackTop,DetailCenterBottom,
    LoginMain,DetailCollect
  },
  data() {
    return {
      // 选中的收藏夹
      checkedCollect: '',
      isHideCollect: true,
      // 是否隐藏登录box
      isHideLoginBox: true,
      // 目录吸顶距离
      tocTop: 70,
      i: 0,
      isVisible: true,
      // 登录是否加载中
      loginLoading: false,
      // 登录出错
      errorMeg: '',
      tagList: "",
      currentUserInfo: {},
      // 周围info
      aroundInfo: {
        activeBtn: '', // 激活的item
        // 是否激活爱心
        likeEventMark: false,
        // 收藏标志
        collectEventMark: false
      },
      blogUserCollect: {
        // 收藏夹id
        collectId: '',
        // 被收藏的id
        collectedId: '',
        // 被收藏的内容名字
        collectedName: ''
      },
      article: {
        userId: "",
        contentMd: "123123413412",
        createTime: ""  ,
        tags: "",
        title: "",
        usernick: "光阳",
        userAvatar: "http://s13.sinaimg.cn/orignal/4afe29760b5ca3465dfbc",
      }
    }
  },
  created() {
    // 设置过期时间为5天
    this.$cookies.config('2d')
  },
  mounted() {
    let id = this.$route.params.id;
    console.log(id);
    // 获取当前用户的id，无论有没有都要都要发送给后端
    let user = this.$cookies.get("blog-user-info")
    console.error("从cookie中取出的用户信息")
    console.log(user);
    let userId = "";
    if (user !== null && user !== undefined && user !== "") {
      userId = user.info.id
    }
    findArticleById(userId,id).then(res => {
      console.log(res);
      if (res.code == 200) {
        this.article = res.data
        // 将字符串变成数组
        this.tagList = this.article.tags.split(",")
        // 获取用户的点赞状态
        this.likeStatusApi()
        // 获取用户的收藏状态
        this.collectApi()
      }
    })

    
  },
  methods: {

    /**
     * 收藏成功
     */
    startCollect(selectCollect) {
      this.blogUserCollect.collectName = selectCollect.name
      this.blogUserCollect.collectId = selectCollect.id
      this.blogUserCollect.collectedId = this.article.id
      this.blogUserCollect.collectedName = this.article.title
      this.blogUserCollect.collectedUserId = this.article.userId
      // 开始收藏文章
      collectArticle(this.blogUserCollect).then(res => {
        if (res.code != 200) {
          error(this,res.msg)
        } else {
          this.isHideCollect = true
          this.aroundInfo.collectEventMark = true
        }
        this.checkedCollect = ''
      })
      
    },
    /**
     * 关闭收藏夹面板
     */
    collectClone() {
      this.isHideCollect = true
    },
    // 登录
    login(form) {
      getPublicKey().then(res => {
        return new Promise((resolve,reject) => {
          if(res.code == 200) {
            resolve(res)
          } else {
            reject(res.msg)
          }
        })
      }).then(data => {
        return new Promise((resolve,reject) => {
          let loginFrom = {
            username: form.username,
            password: form.password,
            code: form.code
          }
          // 对密码进行RSA加密
          loginFrom.password = encryptedData(data.data.pkey,loginFrom.password)
          // 用户登录时候向后端获取公钥，同时会返回一个code,登录提交的时候需要带上code,这样后端才会从缓存中获取到私钥
          loginFrom.code = data.data.code
          login(loginFrom).then(res => {
            console.log(loginFrom);
            if(res.code == 200) {
              this.errorMeg = ''
              // 将token保存到cookie中
              this.$cookies.set(userTokenName,res.data.token) 
              // 将登录面板关闭
              this.isHideLoginBox= true
              // 让导航栏显示头像等信息
              this.$refs.navbar.getUserInfo()
              // 获取用户点赞信息
              if (this.aroundInfo.activeBtn == '点赞')
                this.likeApi()
              else 
                this.likeStatusApi()

              // 获取收藏夹
              this.$refs.DetailCollect.getAllCollectList()

              // 获取用户收藏信息
              if (this.aroundInfo.activeBtn == '收藏') {
                this.isHideCollect = false
                this.aroundInfo.collectEventMark = true
              }
            } 
            // 关闭按钮的加载中
            this.loginLoading = false
            if(res.code !== 200) {
              reject(res.msg)
            }
          })   
        })
      }).catch(err => {
        this.errorMeg = err
      })
      this.loginLoading = true
    },
    /**
     * 左侧点赞事件
     */
    leftLikeHandle() {
      this.likeApi()
    },
    /**
     * 登录面板关闭事件
     */
    lrbClone() {
      this.isHideLoginBox= true
      this.loginLoading = false
    },
    /**
     * 点击文章底部item所触发的事件，回调参数是item名字
     */
    activeBtn(val) {
      if (val == "点赞") {
        this.likeApi(true)
      } else if (val == "收藏") {
        this.collectApi(true)
      }
    },
    /**
     * 访问后台获取点赞状态
     */
    likeStatusApi() {
      // 如果获取到的token为空就直接返回
      let token = this.getToken();
      if (token == null || token == undefined) 
        return
      likeStatus(token,this.article.id).then(res => {
        if (res.code == 200)this.aroundInfo.likeEventMark = res.data
        else this.aroundInfo.likeEventMark =false
      })
      
    },
    /**
     * 点赞
     */
    likeApi(likeBox) {
      this.aroundInfo.activeBtn = '点赞'
      let token = this.getToken();
      if (token == null || token == undefined) {
        this.isHideLoginBox= false 
        return
      }
      /**
       * 用户点赞 
       */
      like(this.article.userId,token,this.article.id,!this.aroundInfo.likeEventMark).then(res => {
        if(res.code == 1004) {
          if (likeBox) {
            this.isHideLoginBox= false
            this.$cookies.remove(userTokenName)
          }
          return
        }
        if (res.code != 200) {
          error(this,res.msg)
          return
        }
        this.aroundInfo.likeEventMark = !this.aroundInfo.likeEventMark
        // 根据点赞状态决定是加还是减  (给用户展示已经点赞或者取消点赞效果)
        if (this.aroundInfo.likeEventMark) {
          this.article.likeCount += 1
        } else {
          this.article.likeCount -= 1
        }
        
      })

      
    },
    /**
     * 收藏文件
     */
    collectApi(collectBox) {
      console.log("收藏");
      let token = this.getToken();
      if (token == null || token == undefined) {
        if (collectBox) this.isHideLoginBox= false
        return
      }
      
      // 查询用户收藏的文件夹
      getUserArticleCollect(this.article.id).then(res => {
        console.log(res);
        if (res.code == 1004) {
          console.log("登录过期请重新登录");
          if (collectBox) {
            this.isHideLoginBox= false
            this.$cookies.remove(userTokenName)
          }
          return
        } else if (res.code == 200) {
          if (collectBox) {
            this.isHideCollect = false
          }

          if (res.data == null)  return
          this.blogUserCollect.id = res.data.id
          this.checkedCollect = res.data.collectName
          console.log(res.data);
          if (res.data != null) this.aroundInfo.collectEventMark = true
        } else {
          console.log(res.msg);
        }
      })

      
    },
    /**
     * 获取token
     */
    getToken() {
      let token = this.$cookies.get(userTokenName)
      return token
    },
    searchQuery(query) {
      let { href } = this.$router.resolve({
        path: '/search',
        query: {
          q: query
        }
      });
      window.open(href);   
    },
    scrollEvent(scroll) {
      let scrollHeight = parseInt(scroll)
      // 下滑
      if(scrollHeight < 70) {
        this.isVisible = true
        this.tocTop = 70
      } else {
        this.isVisible = false
        this.tocTop = 10
      }
    }
  }
}
</script>

<style lang="less" scoped>
// .article-detail {
//   width: 900px;
// }
.detail {
  height: 1000px;
  
}

.main {
  // display: flex;
  transition: all .2s;
  // 设置宽度
  width: 1200px; 
  margin: 70px auto;
}

</style>