<template>
  <div class="search-right">
    右
  </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
.search-right {
  height: 600px;
  background-color: #fff;
}
</style>