<template>
  <div class="search-left">
    <ul>
      <li v-for="(item , index) in leftMenuList" 
        @click="activeIndex = index"
        :key="index" 
        :class="{'active': index == activeIndex}">
        {{item.name}}
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      leftMenuList: [
        {name: "全站"},
        {name: "博主"},
        {name: "用户"},
        {name: "问答"}
      ],
      activeIndex: 0
    }
  }
}
</script>

<style lang="less" scoped>
ul li ,
ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}


a {
  text-decoration: none;
}

.search-left {
  border-radius: 0.4em;
  background-color: #fff;
}
li {
  width: 100%;
  height: 30px;
  margin-top: 5px !important;
  text-align: center;
  line-height: 30px;
  border-radius: 4em;
  // background-color: red;
  cursor: pointer;
}

ul {
  display: flex;
  flex-wrap: wrap;
  
}


li:hover {
  background-color: #00bcd4;
}

.active {
  background-color: #00bcd4;
}
</style>