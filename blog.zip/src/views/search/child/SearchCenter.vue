<template>
  <div class="search-center">
    <!-- 头部 -->
    <div class="search-header">
      <span>为你找到约 {{resultCount}} 个结果</span>
    </div>

    <!-- 文章列表 -->
    <article-list
      :scollEnd="scollEnd"
      :isImage="false"
      :isDivided="false"
      :articleList="articleList"
    >

    </article-list> 
  </div>
</template>

<script>
import ArticleList from "@/components/common/article/ArticleList"
export default {
  props: {
    // 是否需要接着滚动加载
    scollEnd: {
      type: Boolean,
      default: false
    },
    resultCount: {
      type: String,
      default: "0"
    },
    articleList: {
      type: Object,
      default: function() {
        return [
          {
            id: "1263012551591985152",
            title:"标题12313",
            contentText: " 摘要：针对于List的size比较大，使用多线程处理任务时，可以将List分割为一个一个比较小的任务单元进行处理。 例如集合大小：645，按照100分割，会将集合分割为6个size为100的集合和一个size为45的集合，方便配合多线程处理。 实现代码如下： 输出结果：",
            createTime: "2020-06-01",
            likes: 12312,
            views: 12312,
            usernick: "光阳",
            userAvatar: "https://s1.ax1x.com/2020/06/01/t87aeU.png",
            imageUrl: ""
          },
        ]
      }
    }
  },
  components: {
    ArticleList
  }
}
</script>

<style lang="less" scoped>
// 文章列表
.search-center {
  // margin-right: 10px;
  
}

.article-list {
  border-radius: 0.4em;
  background-color: #fff;
}
.search-header {
  display: flex;
  flex-direction: row-reverse;
  height: 40px;
  border-radius: 0.4em;
  background-color: #fff;
  margin-bottom: 10px;
}

span {
  display: block;
  margin-right: 10px;
  line-height: 40px;
  color: #999;
}
</style>