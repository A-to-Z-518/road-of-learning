<template>
<!-- 搜索组件 -->
  <div>
    <navbar :isVisible="true" 
      @search-query="searchQuery" 
      :defaultSearchValue="$route.query.q" 
      ref="navbar">
    </navbar>
    <!-- 版心 -->
    <search-layout>
      <template v-slot:search-layout-left> 
        <search-left></search-left>
      </template>

      <template v-slot:search-layout-center> 
        <search-center :articleList="articleList" :resultCount="resultCount" :scollEnd="scollEnd"></search-center>  
      </template>

      <template v-slot:search-layout-right> 
        <search-right></search-right>
      </template>
    </search-layout>
    <back-top></back-top>
  </div>
</template>

<script>
import BackTop from "@/components/common/top/BackTop.vue"

import SearchLayout from "@/components/common/layout/search/SearchLayout.vue"

import Navbar from "@/components/common/nav/Navbar"

import SearchCenter from "./child/SearchCenter"
import SearchLeft from "./child/SearchLeft"
import SearchRight from "./child/SearchRight"

import {searchAllArticle} from "@/api/search.js"
export default {
  components: {
    Navbar,SearchLeft,SearchCenter,SearchRight,
    SearchLayout,BackTop
  },
  data() {
    return {
      // 是否需要接着滚动加载
      scollEnd: false,
      // 文章列表
      articleList: [],
      // 搜索到的结果数量
      resultCount: 0,
      searchParam: {
        q: "", // 关键字
        uid: "",// 用户id
        pageSize: 10,// 页大小
        pageNum: 1 // 第几页
      }
    }
  },
  mounted() {
    this.searchParam.q = this.$route.query.q
    this.searchQuery(this.searchParam.q)
    this.$refs.MeMain.init()
  },
  methods: {
    searchQuery(query) {
      this.searchParam.q = query
      searchAllArticle(this.searchParam).then(res => {
        console.log(res);
        if (res.code == 200) {
          this.resultCount = res.data.total
          this.articleList = res.data.list
          this.scollEnd = res.data.lastPage
        }
      })
      console.log("开始搜索啦!!! " + query);
    }
  }
}
</script>

<style lang="less" scoped>

.main {
  // display: flex;
  transition: all .2s;
  // 设置宽度
  width: 1200px; 
  margin: 70px auto;
}


.left ,
.center,
.right{
  width: 100%;
  height: 600px;
  background-color: pink;
}
</style>