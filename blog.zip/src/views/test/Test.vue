<template>
  <div>
    <select-tags @selected-tag="selectedTag"></select-tags>
  </div>
</template>

<script>
import SelectTags from "@/components/content/tag/SelectTags.vue"
export default {
  components: {
    SelectTags
  },
  data() {
    return {
      tags: []
    }
  },
  methods: {
    selectedTag(tags) {
      this.tags = tags
      console.log(this.tags);
    }
  }
}
</script>

<style>

</style>