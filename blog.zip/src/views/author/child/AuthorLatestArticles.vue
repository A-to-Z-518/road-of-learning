<template>
  <div class="author-lastest-articles">
    <ul>
      <li v-for="item in articleList" :key="item.id" class="one-line">
        <router-link tag="a"  class="author-color" target="_blank" :to="'/article/details/' + item.id" >{{item.title}}</router-link>
      </li>
    </ul>
  </div>
</template>

<script>
import {authorNewestArticle} from "@/api/search"
import {error} from "@/util/message"
export default {
  created() {
    authorNewestArticle().then(res => {
      console.log(res.data);
      if(res.code != 200) {
        error(this,res.msg)
        return
      }
      this.articleList = res.data
    })
  },
  data() {
    return {
      articleList: [
        
      ]
    }
  }
}
</script>
<style lang="less" scoped>
@import "@/assets/less/color.less";
.author-lastest-articles {
  margin-top: 5px;
}

ul li ,
ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}


a {
  text-decoration: none;
}

li {
  display: block;
  height: 35px;
  line-height: 35px;
  width: 100%;
}

.one-line {
  display:block;
  overflow : hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 1 ;      /* 可以显示的行数，超出部分用...表示*/
  -webkit-box-orient: vertical;
}
</style>