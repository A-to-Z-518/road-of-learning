<template>
  <div class="me-author-header">
    <!-- 头像 -->
    <div class="author-avatar">
      <div class="user-avatar">
        <img :src="avatar" alt="">
      </div>
    </div>
    <!-- 用户昵称 -->
    <div class="author-nick">
      <h3>{{usernick}}</h3>
    </div>
    <!-- 关注和聊天按钮 -->
    <div class="author-header-bottom">  
      
      <el-button class="button-size" size="medium" type="primary" plain>
        <svg-icon icon-class="attention" class-name="icon"></svg-icon> 关注
      </el-button>
      <el-button class="button-size" size="medium" type="success" plain>
        <svg-icon icon-class="chat" class-name="icon"></svg-icon> 聊天
      </el-button>
    </div>

  </div>
</template>   

<script>
export default {
  props: {
    avatar: {
      type: String,
      default: 'https://up.enterdesk.com/edpic_source/1f/8d/80/1f8d800f610fd0f0201bd95cadcd9933.jpg'
    },
    usernick: {
      type: String,
      default: '哦，我的皇帝陛下'
    }
  },
  data() {
    return {
      
    }
  }
}
</script>

<style lang="less" scoped>
.me-author-header {
  display: flex;
  width: 100%;
  height: 100%;
  flex-wrap: wrap;
  

}

.author-avatar {
  display: flex;
  justify-content: center;
  align-items: flex-end;
  width: 100%;
  height: 190px;
  // background-color: #fff;
}
.user-avatar img {

  width: 100px;
  height: 100px;
  border-radius: 50%;
}
.user-avatar {
  width: 100px;
  height: 100px;
  padding: 5px;
  border-radius: 50%;
  background: rgba(255,255,255,0.7);
}

img {
  
}

.author-nick {
  display: flex;
  justify-content: center;
  align-items: flex-end;
  width: 100%;
  height: 60px;
  // background-color: #fff;
  
}

.author-nick h3 {
  font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
  color: #fff;
}

.author-header-bottom {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100px;
  // background-color: #fff;
}

.button-size {
  height: 45px;
  width: 80px;
}

.icon {
  margin-right: 1px;
  margin-left: -5px !important;
}


</style>