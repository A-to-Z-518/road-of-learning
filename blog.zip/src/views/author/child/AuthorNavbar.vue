<template>
  <div class="author-navbar">
    <!-- 作者的导航栏 -->
    <ul class="nav">
      <li v-for="(item,index) in menuList" :key="index" @click="activeMenuIndex(index)">
        <router-link :to="item.link" :class="{'active': index == activeIndex}">{{item.name}}</router-link>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: {
    menuList: {
      type: Array,
      default: function() {
        return [
          {name: "文章" , link: "article"},
          {name: "分类" , link: "/home"},
          // {name: "标签" , link: "#"},
          // {name: "归档" , link: "/tag"},
          {name: "我的开源" , link: "#"},
          // {name: "在线工具" , link: "#"},
          {name: "关于我" , link: "#"},
        ]
      }
    }
  },
  data() {
    return {
      activeIndex: -1,
      storageName: "author_active_index"
    }
  },
  created() {
    // 如果传入了默认值就将其存入到本地的 storage
    let index = window.sessionStorage.getItem(this.storageName)
    if(index != null && index != "") this.activeIndex = index
    console.log("AuthorNavbar组件默认激活的下标: " + this.activeIndex);
  },
  methods: {
    activeMenuIndex(index) {
      console.log("当前激活的下标: " + index);
      this.activeIndex = index
      window.sessionStorage.setItem(this.storageName,index)
      this.$emit('active-index',index)
    }
  }
}
</script>

<style lang="less" scoped>
ul li ,
ul {
  padding: 0px;
  margin: 0px;
  // 去掉点
  list-style: none;
}


a {
  text-decoration: none;
}

// 导航栏部分
// .nav {
//   float: left;
//   margin-left: 40px;
// }
.nav {
  display: flex;
  height: 100%;
  width: 100%;
  justify-content: space-around;
  align-items: center;
}
.author-navbar {
  display: flex;
  height: 100%;
}
.nav li {
  // width: 80px;
  line-height: 50px;
  height: 50px;
}


.active {
  border-bottom: 4px solid #00bcd4 !important;
  color: #00bcd4 !important;
}
.nav li a {
  display: block;
  height: 48px;
  font-size: 18px;
  color: #999;
}
.nav li a:hover {
  border-bottom: 4px solid #00bcd4 !important;
  color: #00bcd4 !important;
}
</style>