<template>
  <!-- 作者的基本信息，粉丝 获赞 收藏  关注 -->
  <div class="author-border-info">
    <div>
      <span>{{userInfo.attentionedCount}}</span>
      <!-- 粉丝表示谁关注了我 -->
      <span>粉丝</span>
    </div>

    <div>
      <span>{{userInfo.likedCount}}</span>
      <!-- 粉丝表示谁关注了我 -->
      <span>获赞</span>
    </div>

    <div>
      <span>{{userInfo.collectedCount}}</span>
      <!-- 粉丝表示谁关注了我 -->
      <span>收藏</span>
    </div>

    <div>
      <span>{{userInfo.articleCount}}</span>
      <!-- 粉丝表示谁关注了我 -->
      <span>文章</span>
    </div>
    
  </div>
</template>

<script>
export default {
  props: {
    userInfo: {
      type: Object,
      default: function() {
        return {

        }
      }
    }
  },
  data() {
    return {

    }
  }
}
</script>

<style lang="less" scoped>
@import "~@/assets/less/color.less";
.author-border-info {
  display: flex;
  justify-content: space-around;
  padding: 5px;
}

span {
  display: block;
  text-align: center;
}
</style>>