<template>
  <div>
    <el-tag type="success" class="author-tag" v-for="item in tagList" :key="item.id">
      {{item.name}}
    </el-tag>
  </div>
</template>

<script>
export default {
  props: {
    tagList: {
      type: Array,
      default: function() {
        return [
          {id:"1",name: "springboot"},
          {id:"2",name: "mysql"},
          {id:"3",name: "java"},
          {id:"4",name: "docker"},
          {id:"5",name: "java8新特性"},
          {id:"6",name: "linux"},
          {id:"7",name: "elasticsearch"},
        ]
      }
    }
  }
}
</script>

<style lang="less" scoped>
.author-tag {
  margin-top: 5px;
  margin-right: 5px;
}
</style>