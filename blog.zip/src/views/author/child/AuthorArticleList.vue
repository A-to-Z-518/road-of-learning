<template>
  <me-scroll-loading class="article-item" :isLoading="isLoading" :scollEnd="scollEnd" @onload="onload"> 
    <div  v-for="(item,index) in articleList" :key="index">
      <div class="article">
        
        <!-- 展示文章列表 -->
        <div class="article-center-right">
          <router-link target="_blank" :to="`/article/details/` + item.id" class="title" @click.native="showArticle">{{item.title}}</router-link>
          <div class="content ">
            <span class="twoline">{{item.contentText}} </span>
            <div class="article-bottom" >
              <!-- 头像 -->
              <avatar :url="item.userAvatar"></avatar>
              <!-- 用户昵称 -->
              <span><a href="#">{{item.usernick}}</a></span>
              <!-- 创建时间 -->
              <span>{{item.createTime}}</span>

              <!-- 点赞数量 -->
              <span class="article-bottom-right-item">点赞 {{item.likeCount}}</span>
              <!-- 访问量 -->
              <span class="article-bottom-right-item">浏览 {{item.viewCount}}</span>
            </div>
          </div>
        </div>
    
        <!-- 展示文章配图 -->
        <!-- <div class="article-image" style="background-color: pink;">
          <img src="https://cdn.pixabay.com/photo/2020/05/13/17/38/foliage-5168308__340.jpg" alt="">
        </div> -->
      </div>
      <!-- 分割线 -->
      <!-- <divided v-if="index !== article.length -1"></divided> -->
    </div>
  </me-scroll-loading>
</template>

<script>
import MeScrollLoading from "@/components/common/loading/MeScrollLoading.vue"
import Avatar from "@/components/common/avatar/Avatar"
import Divided from "@/components/common/divided/Divided"
import {getAuthorArticle} from "@/api/search.js"
export default {
  components: {
    Avatar,Divided,MeScrollLoading
  },
  props: {
    userId: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      userId: '',
      isLoading: false,
      pageNum: 1,// 第几页
      // 文章列表
      articleList: [],
      // 是否滚动到底部
      scollEnd: false,
    
     
    }
  },
  created() {
    this.userId = this.$route.query.userId
    this.getArticleList()
  },
  methods: {
    /**
     * 请求后台数据
     */
    onload() {
      console.log("获取数据");
      this.pageNum++
      this.getArticleList()
    },
    /**
     * 获取文章数量
     */
    getArticleList() {
      if (this.scollEnd) return
      getAuthorArticle(this.userId,this.pageNum).then(res => {
        if (res.code != 200)  {
          console.log("获取文章数据出错")
          return
        }
        console.log(res);
        if (res.data.lastPage) {
          console.log("到底了");
          this.scollEnd = true
          this.isLoading = false
        }
        this.articleList.push.apply(this.articleList,res.data.list)
      })
    },

    /**
     * 展示文章事件
     */
    showArticle() {
      console.log("跳转路由");
      
      this.$emit("show-article")
    },
    // 当前页
    handleCurrentChange(num) {

    },

  }
}
</script>

<style lang="less" scoped>

.title {
  
  display: block;
  padding-top: 10px;
  margin-left: 10px;

}
a {
  text-decoration: none;
}
// 未访问链接 ,如 a:link {color:blue}
a:link {
  color: #404040;
}
// a:hover： 鼠标移到链接上时 ,如 a:hover {color:blue}
.article-item a:hover {
  color: #2D8CF0;
}
// 激活时(链接获得焦点时)链接的颜色 ,如 a:active{color:blue}
a:active {
  color: #2D8CF0;
}
//  已访问链接
a:visited {
  color: #404040;
}



.article {
  display: flex;
  width: 100%;
  // padding: 5px;
  height: 140px;
  margin: 0px;
  margin-bottom: 10px;
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 0.6em;
}


.article-image ,
.article-image img{
  width: 160px;
  height: 120px;
  margin-left: auto;
}

.article-image {
  margin: auto 10px;
}


.page {
  display: flex;
  margin: 10px auto;
  justify-content: center;
  margin-bottom: 50px;
}


.article-item a {
  // 去掉a标签的下划线
  text-decoration: none;
  padding-left: 5px;
  font-size: 20px;
  font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif
}

.article-center-right {
  flex: 1px;
  // padding-right: 5px;
}



// 文章内容
.content {
  display: flex;
  width: 880px;
  min-height: 60px;
  flex-wrap: wrap;
  padding-top: 5px;
  margin: 0px 10px;
  font-size: 16px;
  font-weight: 300;
  font-family: "微软雅黑";
  line-height: 1.5em;
  color: #666;
  
}

.content span {
  display: block;
}
.twoline {
  width: 880px;
  height: 48px;
}

span {
  display: block;
}

// 文章item底部
.article-bottom {
  display: flex;
  align-items: center;
  font-size: 14px;
  font-family: "微软雅黑";
  padding-top: 15px;
}


.article-bottom span ,
.article-bottom span a{
  display: block;
  margin: auto 5px;
  padding-bottom: 0px;
  font-size: 14px;
  cursor: pointer;
  font-family: "微软雅黑";
  // font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif
}



.content span{
  display:block;
  overflow : hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2 ;      /* 可以显示的行数，超出部分用...表示*/
  -webkit-box-orient: vertical;
}
</style>