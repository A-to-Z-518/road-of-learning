<template>
  <div class="author" ref="main">
    <div id="author-page" :style="{backgroundImage:'url('+ userInfo.backgroundImage +')',transform: 'none'}"></div>
    <!-- 头部 -->
    <scroll @scroll-event="scrollEvent">
      <navbar v-if="!isSwitchNav" :isVisible="isNavbarVisible" @search-query="searchQuery" ref="navbar"></navbar>
      <navbar v-else :menuList="authorMenuList" @active-index="activeIndex" @search-query="searchQuery" ref="navbar"></navbar>
    </scroll>

    <!-- 不要加单位，单位自动添加是px -->
    <div class="center-main w" >
      <!-- 页头 -->
      <author-header class="author-page-header" 
        :avatar="userInfo.avatar" 
        :usernick="userInfo.usernick"></author-header>
      <!-- 导航栏 -->
      <author-navbar 
        ref="authorNavbar"
        v-if="!isSwitchNav"
        :menuList="authorMenuList"
        class="author-header bc-br" 
        :class="{'nav-combine':isNavCombine}"
        @active-index="activeIndex"
        >
      </author-navbar>
      <author-layout>
        <template v-slot:author-layout-left> 
          <router-view class="left"/>
        </template>

        <template v-slot:author-layout-right> 
          <!-- 作者的基本信息，粉丝 获赞 收藏  关注 -->
          <author-border-info class="right-box bc-br" :userInfo="userInfo"></author-border-info>
          <!-- 标签 -->
          <!-- <border-box class="right-box-sort bc-br" title="标签">
            <author-tag :tagList="tagList"></author-tag>
          </border-box> -->

          <!-- 分类 -->
          <border-box class="right-box-sort bc-br" title="分类">
            <!-- 这块组件复用了 -->
            <author-tag :tagList="sortList"></author-tag>
          </border-box>

          <!-- 最新文章 -->
          <border-box class="right-box-sort bc-br" title="最新文章">
            <author-latest-articles></author-latest-articles>
          </border-box>
        
        </template>
      </author-layout>
    </div>
    <back-top></back-top>
</div>


</template>

<script>
import AuthorHeader from "./child/AuthorHeader"
import AuthorNavbar from "./child/AuthorNavbar"
// import AuthorArticleList from "@/components/content/article/AuthorArticleList.vue"
import BorderBox from "@/components/common/box/BorderBox.vue"
import Divided from "@/components/common/divided/Divided"
import Navbar from "@/components/common/nav/Navbar"
import Scroll from "@/components/common/scroll/Scroll.vue"

// 用户的基本信息
import AuthorBorderInfo from "./child/AuthorBorderInfo"
// 用户标签
import AuthorTag from "./child/AuthorTag"
// 最新文章
import AuthorLatestArticles from "./child/AuthorLatestArticles"

import BackTop from "@/components/common/top/BackTop.vue"

import AuthorLayout from "@/components/common/layout/AuthorLayout.vue"

import {getAuthorUserInfo} from "@/api/user"
import {error} from "@/util/message"
export default {
  components: {
    BorderBox,Scroll,Navbar,Divided,BorderBox,AuthorNavbar,AuthorHeader,
    AuthorBorderInfo,AuthorTag,AuthorLatestArticles,BackTop,AuthorLayout
  },
  data() {
    return {
      
      // 用户id
      userId: "",
      updateMounted: true,
      // 判断是否写如果浏览器本地存储，防止多次写入
      isWriteNavActiveIndex: true,
      isWriteNavActiveIndex1: true,
      // 个人主页导航栏和网站的导航栏是否结合
      isNavCombine: false,
      isNavbarVisible: true,
      // 是否切换个人导航栏到顶部并且增加搜索框以及头像等等组件
      isSwitchNav: false,

      userInfo: {
        backgroundImage: "https://s1.ax1x.com/2020/09/02/wpSxC4.jpg"
      },
      authorMenuList: [
        {name: "文章" , link: "article"},
        {name: "分类" , link: "sort"},
        // {name: "标签" , link: "tag"},
        // {name: "归档" , link: "/tag"},
        {name: "我的开源" , link: "#"},
        // {name: "在线工具" , link: "#"},
        {name: "友情链接" , link: "#"},
        {name: "关于我" , link: "#"},
      ],
      sortList: [
        {id:"1",name: "springboot"},
        {id:"2",name: "mysql"},
        {id:"3",name: "java"},
        {id:"4",name: "docker"},
        {id:"5",name: "java8新特性"},
        {id:"6",name: "linux"},
        {id:"7",name: "elasticsearch"},
        {id:"8",name: "vue"},{id:"9",name: "html"},{id:"10",name: "js"},{id:"11",name: "css"},
        {id:"12",name: "真机安装centos8"},{id:"13",name: "windows脚本bat"}
      ]
    }
    
  },
  created() {
    this.userId = this.$route.query.userId
    // 获取用户info
    getAuthorUserInfo(this.userId).then(res => {
      if (res.code != 200) {
        error(this,res.msg)
        return
      }
      this.userInfo = res.data
    }),
    setTimeout(() => {
      for(let i = 0; i < this.authorMenuList.length; i++) {
        this.authorMenuList[i].link = this.authorMenuList[i].link + "?userId=" + this.userId
      }
    },0)
  },
  mounted() {
    console.log("获取子组件的下标" + this.$refs.navbar.getActiveIndex());
  },
 
  methods: {
    // 当前激活的下标
    activeIndex(index) {
    },

    // 跳转到搜索页面
    searchQuery(query) {
      let { href } = this.$router.resolve({
        path: '/search',
        query: {
          q: query
        }
      });
      window.open(href);   
    },
    scrollEvent(scroll) {
      // 滚动大于600 收起导航栏并且将导航栏的菜单切换成博主的小导航栏菜单
      if (scroll > 600) {
        // console.log("scroll > 600");
        this.updateMounted = !this.updateMounted
        // 这两个在AuthorNavbar组件和MeNavMenu组件中写入的
        if(this.isWriteNavActiveIndex1) {
          
          // 博主的菜单栏下标赋值给头部的导航栏菜单下标
          this.$refs.navbar.setActiveIndex(window.sessionStorage.getItem("author_active_index"))
          this.isWriteNavActiveIndex = true
          this.isWriteNavActiveIndex1 = false
        }
        
        // 是否切换个人导航栏到顶部
        this.isSwitchNav = true

        // 博主的自己导航栏顶在网站导航栏的下面
        this.isNavCombine = true
        // 导航栏收起来
        this.isNavbarVisible = false
        
      } else if(scroll > 260) {
        // 导航栏和博主的导航栏进行吸附
        this.isNavCombine = true
        // console.log("scroll > 260");

      } else if(scroll < 260) {
        // console.log("scroll < 260");
        // 回归
        this.isSwitchNav = false
        this.isNavCombine = false
        this.isNavbarVisible = true
        

        // 将nav导航栏下标归位
        if (this.isWriteNavActiveIndex) {
          this.$refs.navbar.setActiveIndex(window.sessionStorage.getItem("nav_active_index"))

          this.isWriteNavActiveIndex = false
          this.isWriteNavActiveIndex1 = true
        }
      }  
      // console.log(scroll);  
    } 
  }
}
</script>

<style lang="less" scoped>
@import "@/assets/less/navbar.less";
@import "@/assets/less/style.less";



.author {
  height: 100%;
  /* 这里给app一个滚动效果 */
  overflow-y: scroll;
}

.tou-ming {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
}



.author-page-header {
  width: 100%;
  height: 350px;
}

.main {
  // display: flex;
  transition: all .2s;
  // 设置宽度
  width: 1200px; 
}


.center-main {
  display: flex;
  flex-wrap: wrap;

  // 设置全透明,必须设置如下属性
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  
  width: 1200px;
  margin-top: 70px;
  background: rgba(255, 255, 255, 0);

  filter:alpha(Opacity=100) !important;
  -moz-opacity:1.0 !important;
  opacity: 1.0 !important;
}

// 作者页面
#author-page {
  position: fixed;
  top: 0rem;
  bottom: 0rem;
  height: 100vh;
  width:100%;
  
  z-index: 0;
  background-repeat: no-repeat;
  background-position: top center;
  background-attachment: fixed;
  background-size: cover;
  // background-color: rgba(255, 255, 255, 0.8);
  overflow: auto;
}

.left,
.left-box-tag  {

  margin-bottom: 10px;
  // background-color: #fff;
}

.left-article-list {
  
}

// .fixed-top {
//   // width: 100%;
//   // position: fixed;
//   // z-index: 9999;
//   // left: 0px;
//   // right: 0px;
// }

.author-header {
  width: 100%;
  height: 50px;
  margin-bottom: 10px;
}




.content-right1,
.content-right2 {
  height: 3000px;
}

.right {
  height: 200px; 
  background-color: #fff;
}

.right-box-sort {
  padding: 5px;
}

.bc-br {
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 0.2em;
  margin-bottom: 10px;
}

// 个人主页的导航栏和网站的导航栏进行结合
.nav-combine {
  position: fixed;
  transition: all .6s;
  top: 60px;
  left: 0;
  right: 0;
  z-index: 8888;
}

</style>