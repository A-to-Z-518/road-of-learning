<template>
  <div>
    <author-article-list></author-article-list>
  </div>
</template>

<script>
import AuthorArticleList from "./child/AuthorArticleList"
export default {
  components: {
    AuthorArticleList
  },
  data() {
    return {
      search: {
        // 搜索的关键字
        query: "",
        // 标签id
        tagId: "",
        // 分类id
        sortId: ""
      }
    }
  },
  mounted() {
    console.log("=====");
    // 根据带过来的参数不同进行搜索条件判断
    let query = this.$route.query.query;
    console.log(query);
    // this.search.tagId = this.$route.query.tagId;
    // this.search.sortId = this.$route.query.sortId;
    
  }
}
</script>

<style>

</style>