<template>
  <div class="author-sort">
    <el-tag type="primary" class="sort" v-for="item in sortList" :key="item.id">
      <router-link :to="'sort/' + item.id">{{item.name}}  {{item.count}}</router-link>
    </el-tag>
  </div>
</template>

<script>
export default {
  data() {
    return {
      sortList: [
        {id:"1",name: "springboot",link:"#",count: 23423},
        {id:"2",name: "mysql",link:"#",count: 23423},
        {id:"3",name: "java",link:"#",count: 23423},
        {id:"4",name: "docker",link:"#",count: 23423},
        {id:"5",name: "java8新特性",link:"#",count: 23423},
        {id:"6",name: "linux",link:"#",count: 23423},
        {id:"7",name: "elasticsearch",link:"#",count: 23423},
        {id:"8",name: "springboot",link:"#",count: 23423},
        {id:"9",name: "mysql",link:"#",count: 23423},
        {id:"10",name: "java",link:"#",count: 23423},
        {id:"11",name: "docker",link:"#",count: 23423},
        {id:"12",name: "java8新特性",link:"#",count: 23423},
        {id:"13",name: "linux",link:"#",count: 23423},
        {id:"14",name: "elasticsearch",link:"#",count: 23423},
        {id:"15",name: "springboot",link:"#",count: 23423},
        {id:"16",name: "mysql",link:"#",count: 23423},
        {id:"17",name: "java",link:"#",count: 23423},
        {id:"18",name: "docker",link:"#",count: 23423},
        {id:"19",name: "java8新特性",link:"#",count: 23423},
        {id:"20",name: "linux",link:"#",count: 23423},
        {id:"21",name: "elasticsearch",link:"#",count: 23423}
      ]
    }
  }
}
</script>

<style lang="less" scoped>
a {
  text-decoration: none;
}

.author-sort {
  border-radius: 0.4em;
  background-color:rgba(255, 255, 255, 0.7);
}
.sort {
  background-color: #cffffe;
  margin: 10px;
}
</style>