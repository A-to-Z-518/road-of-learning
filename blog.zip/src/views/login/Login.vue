<template>
  <div :style="mLogin">
    <!-- <el-button type="primary" @click="onLogin"><router-link to="/sort">tag</router-link></el-button> -->
    <navbar @search-query="searchQuery"></navbar>
    <div class="m-login">
      <div class="title"><h2 align="center">登录</h2></div>
    
      <el-form ref="form" :model="form" label-width="40px">
        <el-form-item>
          <el-input v-model="form.username" placeholder="用户名/邮箱/手机号"></el-input>
        </el-form-item>

        <el-form-item>
          <el-input v-model="form.password" show-password placeholder="密码"></el-input>
        </el-form-item>

        <el-form-item>
          
          <el-button type="primary" @click="onLogin" :loading="loginLoading">
            登录
          </el-button>
          
        </el-form-item>
        

        
      </el-form>
      <div class="m-login-1">
        <div class="tis" v-if="!isUsernameAndPwd">用户名或者密码错误</div>
        <div class="m-pwd-reg">
          <a href="#">忘记密码 </a> &emsp; 
          <span @click="registerEvent">新用户注册</span>
        </div>  
      </div>


      <el-divider>第三方账号登录</el-divider>

      <div class="m-social-image">
        <div></div><div></div>
        <el-image
          style="width: 40px; height: 40px"
          :src="social.weibo.imageUrl"
          fit="cover">
        </el-image>

        <el-image
          style="width: 40px; height: 40px"
          :src="social.weixin.imageUrl"
          fit="cover">
        </el-image>

        <el-image
          style="width: 40px; height: 40px"
          :src="social.qq.imageUrl"
          fit="cover">
        </el-image>
        <div></div><div></div>
      </div>
      

    </div>
  </div>
</template>

<script>
import Navbar from "@/components/common/nav/Navbar"
import {login,getPublicKey} from "@/api/user.js"
import {userTokenName,userInfoName} from "@/util/const.js"
import {error} from "@/util/message.js"
import {encryptedData} from "@/util/jsencrypt-util"
export default {
  components: {
    Navbar
  },
  data() {
    return {
      // 社交
      social: {
        weibo: {
          imageUrl: require("../../assets/img/weibo.png"),
        },
        weixin: {
          imageUrl: require("../../assets/img/weixin.png"),
        },
        qq: {
          imageUrl: require("../../assets/img/qq.png"),
        }
      },
      form: {
        username: '',
        password: '',
        code: ''
      },
      // 登录加载中
      loginLoading: false,
      mLogin: {
        backgroundImage: "url(" + require("../../assets/img/login-bj.jpg") + ")",
        backgroundRepeat: "no-repeat",
        width: "100%",
        // height: "100%",
        minHeight:"800px"
      },
      // 用户名或者密码是否正确
      isUsernameAndPwd: true
    }
  },
  created() {
    // 设置过期时间为5天
    this.$cookies.config('5d')
  },
  methods: {
    onLogin() {
      // 打开按钮的加载中
      this.loginLoading = true
      // 获取公钥
      getPublicKey().then(res => {
        return new Promise((resolve,reject) => {
          if(res.code == 200) {
            resolve(res)
          } else {
            reject(res.msg)
          }
        })
      }).then(data => {
        return new Promise((resolve,reject) => {
          let loginFrom = {
            username: this.form.username,
            password: this.form.password,
            code: this.form.code
          }
          // 对密码进行RSA加密
          loginFrom.password = encryptedData(data.data.pkey,loginFrom.password)
          // 用户登录时候向后端获取公钥，同时会返回一个code,登录提交的时候需要带上code,这样后端才会从缓存中获取到私钥
          loginFrom.code = data.data.code
          login(loginFrom).then(res => {
            if(res.code == 200) {
              console.log(res.data);
  
              // 将token保存到cookie中
              this.$cookies.set(userTokenName,res.data.token) 

              // 从哪来回哪去
              let callbackUrl = this.$store.getters.getCallbackUrl
              console.log("回调地址 = " + callbackUrl);
              if(callbackUrl == undefined || callbackUrl == null || callbackUrl == '') {
                this.$router.push("/")
                return
              }
              this.$router.push(callbackUrl)
              
            } 

            if(res.code !== 200) {
              reject(res.msg)
            }
            // 关闭按钮的加载中
            this.loginLoading = false
          })
        })
      }).catch(err => {
        error(this,err)
      })
      
    },
    registerEvent() {
      console.log("注册事件");
      this.$emit("register-event")
    }
  }
}
</script>

<style lang="less" scoped>


.m-login {
  /* 这样当你按下F12后，页面不会发生变化 */
  position: relative;
  top: 140px;
	left: 0;  
	right: 0;
  bottom: 0;
  margin: auto;

  display: flex;
  flex-wrap: wrap;
  align-content: flex-start;  

  border-radius: 20px;
  height: 460px;
  width: 400px;
  background-color: #ffffff;
  padding: 20px;
  z-index: 10px;
}

.el-form {
  width: 360px;
}

.title {
  width: 400px;
}

.el-divider {
  top: 30px;
  margin: 40px;
}
.el-button {
  width: 100%;
}

.tis {
  color: red;
  margin-left: 40px;
}
.m-login-1 {
  display: flex;
  width: 400px;
}
.m-pwd-reg {
  margin-left: auto;
  margin-right: 40px;
  a {
    // 去掉a标签的下划线
    text-decoration: none;
  }
}

span {
  cursor: pointer;
}

span:hover {
  color: #00bcd4;
}

.el-image {
  cursor: pointer;
  border-radius: 4px;
}

.m-social-image {
  padding-top: 20px;
  height: 40px;
  width: 400px;
  display: flex;
  justify-content: space-around;
}

h2 {
  padding-top: 0px;
  font-size: 24px;
  font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
}
</style>