<template>
  <div>
    <navbar @search-query="searchQuery"></navbar>
    <login v-if="!isRegister" @register-event="registerEvent"></login>
    <register v-else @login-event="loginEvent"></register>
  </div>
</template>

<script>
import Navbar from "@/components/common/nav/Navbar"
import Login from "./Login"
import Register from "./Register"
export default {
  components: {
    Navbar,Login,Register
  },
  data() {
    return {
      // 是否是注册
      isRegister: false
    }
  },
  methods: {
    searchQuery(query) {

    },
    // 去注册事件
    registerEvent() {
      this.isRegister = true
    },
    // 去登录事件
    loginEvent() {
      this.isRegister = false
    }
  }
}
</script>

<style>

</style>