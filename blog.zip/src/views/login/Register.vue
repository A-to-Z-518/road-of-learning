<template>
  <div :style="mLogin">
    <!-- <el-button type="primary" @click="onLogin"><router-link to="/sort">tag</router-link></el-button> -->
    <navbar @search-query="searchQuery"></navbar>
    <div class="m-login">
      <div class="title"><h2 align="center">注册</h2></div>
      
      <el-form ref="form"  :model="form"  :rules="rules">
        <el-form-item label="用户名" label-width="68px" prop="username">
          <el-input v-model="form.username" placeholder="用户名"></el-input>
        </el-form-item>

        <el-form-item label="邮箱" label-width="68px" prop="email">
          <el-input v-model="form.email" placeholder="邮箱"></el-input>
        </el-form-item>

        <el-form-item label="密码" label-width="68px" prop="password">
          <el-input v-model="form.password" show-password placeholder="密码"></el-input>
        </el-form-item>

        <el-form-item label="确认密码"  label-width="68px" prop="checkPass">
          <el-input type="password" v-model="form.checkPass" placeholder="确认密码" 
            autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="验证码" label-width="68px" prop="validCode" :error="errorMsg">
          <div class="valid-code">
            <el-input  v-model="form.validCode" placeholder="验证码" 
              autocomplete="off"></el-input>
            <valid-code></valid-code>
          </div>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" :loading="registerLoading" @click="submitForm('form')">注册</el-button>
        </el-form-item>
        
        
      </el-form>
      <div class="m-login-1">
        <div class="tis" v-if="!isUsernameAndPwd">用户名或者密码错误</div>
        <div class="m-pwd-reg">
          <span>已有账号? </span>&emsp; 
          <span class="go-login" @click="loginEvent">去登录 </span>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import ValidCode from "@/components/common/valid/ValidCode.vue"
import Navbar from "@/components/common/nav/Navbar"
import {register} from "@/api/user.js"
export default {
  components: {
    Navbar,ValidCode
  },
  data() {
    let validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'));
        } else {
          if (this.form.checkPass !== '') {
            this.$refs.form.validateField('checkPass');
          }
          callback();
        }
      };
    let validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'));
      } else if (value !== this.form.password) {
        callback(new Error('两次输入密码不一致!'));
      } else {
        callback();
      }
    };
    return {
      // 验证码错误消息
      errorMsg: null,
      form: {
        username: '',
        email: '',
        password: '',
        checkPass: '',
        // 校验码
        validCode: ''
      },
      mLogin: {
        backgroundImage: "url(" + require("../../assets/img/login-bj.jpg") + ")",
        backgroundRepeat: "no-repeat",
        width: "100%",
        // height: "100%",
        minHeight:"800px"
      },
      // 用户名或者密码是否正确
      isUsernameAndPwd: true,
      // 注册按钮加载中
      registerLoading: false,
      rules: {
        password: [
          { validator: validatePass, trigger: 'blur' }
        ],
        checkPass: [
          { validator: validatePass2, trigger: 'blur' }
        ],
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 6, max: 20, message: '长度在 6 到 20 个字符', trigger: 'blur' }
        ],
        email: [
          { required: true, message: '请输入邮箱地址', trigger: 'blur' },
          { type: 'email', message: '请输入正确的邮箱地址', trigger: ['blur', 'change'] }
        ],
        validCode: [
          { required: true, message: '请输入校验码', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    onLogin() {

    },
    loginEvent() {
      this.$emit("login-event")
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.registerLoading = true
          register(this.form).then(res => {
            if (res.code === 1000) {

              this.errorMsg =  Math.random()
                this.$nextTick(() => {
                this.errorMsg = res.msg
              }) 
            } else if(res.code !== 200) {
              this.$message({
                message: res.msg,
                center: true,
                offset: 70,
                customClass: 'message',
                type: 'error'
              })
            } else {
              // 去登录
              this.$emit("login-event")
            }

            this.registerLoading = false
            
            
          })
          
          
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    }
  }
}
</script>

<style lang="less" scoped>

.valid-code {
  display: flex;
  .el-input {
    width: 200px;
    padding-right: 20px;
  }
}

.m-login {
  /* 这样当你按下F12后，页面不会发生变化 */
  position: relative;
  top: 140px;
	left: 0;  
	right: 0;
  bottom: 0;
  margin: auto;

  display: flex;
  flex-wrap: wrap;
  align-content: flex-start;  
  justify-content: center;
  border-radius: 20px;
  height: 500px;
  width: 500px;
  background-color: #ffffff;
  // padding: 20px;
  z-index: 10px;
}

.el-form {
  width: 400px;
}


.title {
  width: 400px;
}

.el-divider {
  top: 30px;
  margin: 40px;
}
.el-button {
  width: 100%;
}

.tis {
  color: red;
  margin-left: 40px;
}
.m-login-1 {
  display: flex;
  width: 400px;
}
.m-pwd-reg {
  margin-left: auto;
  a {
    // 去掉a标签的下划线
    text-decoration: none;
  }
}

.el-image {
  cursor: pointer;
  border-radius: 4px;
}

.m-social-image {
  padding-top: 20px;
  height: 40px;
  width: 400px;
  display: flex;
  justify-content: space-around;
}

h2 {
  padding-top: 0px;
  font-size: 24px;
  font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
}

.go-login {
  cursor: pointer;
}

.go-login:hover {
  color: #00bcd4;
}
</style>