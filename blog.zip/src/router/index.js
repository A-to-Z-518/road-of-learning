import Vue from 'vue'
import VueRouter from 'vue-router'
import store from '@/store'

// 主页
const Home = () => import("@/views/home/Home.vue")
// 标签页面
const Tag = () => import("@/views/tag/Tag.vue")

// 个人博客中心
const Author = () => import("@/views/author/Author.vue")
// 个人博客中心文章列表
const AuthorArticleList = () => import("@/views/author/child/AuthorArticleList.vue")
const AuthorTag = () => import("@/views/author/AuthorTag.vue")
const AuthorSort = () => import("@/views/author/AuthorSort.vue")
const Search = () => import("@/views/search/Search.vue")
// 测试页面
const Test = () => import("@/components/test/HomeLayout.vue")

// 文章详情页面
const ArticleDetail = () => import("@/views/details/ArticleDetail.vue")
const ArticleWrite = () => import("@/views/article/ArticleWrite.vue")

// 登录
const Login = () => import("@/views/login/Index.vue")
// 注册
// const Register =() => import("@/views/login/Register")

// 个人中心
const Uc = () => import("@/views/uc/Uc.vue")
const UcArticle = () => import("@/views/uc/article/ArticleList.vue")
const UcSort = () => import("@/views/uc/sort/UcSort.vue")
const UcSortEdit = () => import("@/views/uc/sort/UcSortEdit.vue")
const UcCollect =() => import("@/views/uc/collect/UcCollect")
const UcProfile = () => import("@/views/uc/profile/UcProfile")

// Vue.use(VueRouter)
if (!window.VueRouter) Vue.use(VueRouter)

  const routes = [
  {
    path: '/',
    name: "首页",
    redirect: '/home'
  },
  {
    path: '/test',
    name: 'test',
    component: Test
  },
  {
    path: "/login",
    name: "Login",
    meta: {
      title: '登录'
    },
    component: Login
  },
  {
    path: '/home',
    name: 'Home',
    meta: {
      title: '首页'
    },
    component: Home
  },
  {
    path: '/tag',
    name: 'Tag',
    meta: {
      title: '标签'
    },
    component: Tag
  },
  // 创造文章
  {
    path: '/article/write',
    name: 'ArticleWrite',
    meta: {
      title: '创作'
    },
    component: ArticleWrite
  },
  // 写文章
  {
    path: '/article/edit/:id',
    name: 'ArticleWrite',
    meta: {
      title: '编辑'
    },
    component: ArticleWrite
  },
  {
    path: '/author',
    name: 'Author',
    meta: {
      title: '个人'
    },
    component: Author,
    children: [
      {
        path: '',
        redirect: "article"// 默认展示文章列表
      },
      {
        path: 'article',
        name: 'AuthorArticleList',
        component: AuthorArticleList,
      }, 
      {
        path: 'tag',
        name: 'AuthorTag',
        component: AuthorTag
      },
      {
        path: 'sort',
        name: 'AuthorSort',
        component: AuthorSort
      }
      
    ]
  },
  { 
    path: '/search',
    name: 'Search',
    meta: {
      title: '搜索'
    },
    component: Search
  },
  // 文章详情页面
  {
    path: '/article/details/:id',
    name: 'ArticleDetail',
    meta: {
      title: '详情'
    },
    component: ArticleDetail
  },
  {
    path: '/uc',
    name: 'Uc',
    meta: {
      title: '个人中心'
    },
    component: Uc,
    children: [
      {
        path: '',
        redirect: "article"// 默认展示文章列表
      },
      // 个人资料
      {
        path: 'profile',
        name: 'UcProfile',
        component: UcProfile,
        meta: {
          title: '资料'
        }
      },
      {
        path: 'article',
        name: 'UcArticle',
        component: UcArticle,
        meta: {
          title: '文章'
        }
      },
      {
        path: 'collect',
        name: 'UcCollect',
        component: UcCollect,
        meta: {
          title: '收藏'
        }
      },
      {
        path: 'sort',
        name: 'UcSort',
        component: UcSort,
        meta: {
          title: '分类'
        }
      },
      {
        path: 'sort/edit',
        name: 'UcSortEdit',
        component: UcSortEdit,
        meta: {
          title: '编辑'
        }
      }
    ]
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to,from,next) => {
  // to：将要访问的路径
  // from：从哪个路径跳转过来
  // next: 放行
  //    next() 直接放行 next("/login")强制跳转

  // 将路径保存到vuex中，当用户登录后跳回到这个地址中
  console.log("全局路由");
  console.log("from.path = " + from.path);
  let fromPath = from.path
  if (to.path == "/login") {
    console.log("去登录页面");
    store.commit({
      type: 'submitCallbackUrl',
      callbackUrl: fromPath
    })
  }
  window.document.title = to.matched[0].meta.title
  next()
})

export default router
